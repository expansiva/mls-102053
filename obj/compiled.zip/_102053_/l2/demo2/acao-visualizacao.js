var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo2/acao-visualizacao.ts" enhancement="_102020_/l2/enhancementAura"/>
// GERADO a partir de todo/.demo-fragments/acao-visualizacao.frag.ts — base comparável demo1/demo2/demo3.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal';
import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress-brutal';
import '/_102054_/l2/molecules/groupviewcard/ml-profile-card-brutal';
import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal';
import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal';
import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal';
let Demo2AcaoVisualizacao = class Demo2AcaoVisualizacao extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`demo2--acao-visualizacao-102053 {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
demo2--acao-visualizacao-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo2--acao-visualizacao-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo2--acao-visualizacao-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo2--acao-visualizacao-102053 .brand {
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  margin-bottom: 0.5rem;
}
demo2--acao-visualizacao-102053 .title {
  font-size: 1.625rem;
  font-weight: 900;
  text-transform: uppercase;
  margin-bottom: 0.25rem;
}
demo2--acao-visualizacao-102053 .subtitle {
  font-size: 0.8125rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
demo2--acao-visualizacao-102053 .block {
  margin-bottom: 2rem;
  padding: 1.5rem;
}
demo2--acao-visualizacao-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  margin-bottom: 0.75rem;
  border-bottom: 2px solid #000;
  padding-bottom: 0.5rem;
}
demo2--acao-visualizacao-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo2--acao-visualizacao-102053 .page {
  background: #f5f5f5;
}
demo2--acao-visualizacao-102053 .brand {
  color: #000;
}
demo2--acao-visualizacao-102053 .title {
  color: #000;
}
demo2--acao-visualizacao-102053 .subtitle {
  color: #666;
}
demo2--acao-visualizacao-102053 .block {
  background: #ffffff;
  border: 3px solid #000;
  box-shadow: 6px 6px 0 #000;
}
demo2--acao-visualizacao-102053 .block-title {
  color: #000;
}
`);
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">&#9632; collab · 102054</div>
            <h1 class="title">Ação & Visualização — brutalism (102054)</h1>
            <p class="subtitle">button · icon · split · progress · cards · metrics</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupTriggerAction — button / icon / split</h2>
            <div class="grid">
              <grouptriggeraction--ml-button-standard-brutal data-variant="primary"><Label>Primary</Label></grouptriggeraction--ml-button-standard-brutal>
              <grouptriggeraction--ml-button-standard-brutal data-variant="secondary"><Label>Secondary</Label></grouptriggeraction--ml-button-standard-brutal>
              <grouptriggeraction--ml-button-standard-brutal data-variant="danger"><Label>Danger</Label></grouptriggeraction--ml-button-standard-brutal>
              <grouptriggeraction--ml-icon-button-brutal data-variant="primary"><Icon>★</Icon><Label>Favoritar</Label></grouptriggeraction--ml-icon-button-brutal>
              <grouptriggeraction--ml-split-button-brutal data-variant="primary"><Label>Salvar</Label></grouptriggeraction--ml-split-button-brutal>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupShowProgress — linear / circular</h2>
            <div class="grid">
              <groupshowprogress--ml-linear-progress-brutal value="72" show-value label="Upload"></groupshowprogress--ml-linear-progress-brutal>
              <groupshowprogress--ml-linear-progress-brutal value="40" variant="success" size="sm" show-value></groupshowprogress--ml-linear-progress-brutal>
              <groupshowprogress--ml-circular-progress-brutal value="68" size="lg" show-value></groupshowprogress--ml-circular-progress-brutal>
              <groupshowprogress--ml-circular-progress-brutal value="33" size="lg" show-value></groupshowprogress--ml-circular-progress-brutal>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupViewCard — profile / vertical</h2>
            <div class="grid">
              <groupviewcard--ml-profile-card-brutal clickable="true">
                <CardTitle>Ada Lovelace</CardTitle>
                <CardDescription>Engenheira de software</CardDescription>
                <CardContent>Card de perfil clicável.</CardContent>
              </groupviewcard--ml-profile-card-brutal>
              <groupviewcard--ml-vertical-card-brutal>
                <CardTitle>Plano Pro</CardTitle>
                <CardDescription>R$ 49/mês</CardDescription>
                <CardContent>Card vertical com ação.</CardContent>
                <CardAction>
                  <grouptriggeraction--ml-button-standard-brutal data-variant="primary"><Label>Assinar</Label></grouptriggeraction--ml-button-standard-brutal>
                </CardAction>
              </groupviewcard--ml-vertical-card-brutal>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupViewMetric — metric-card / big-number</h2>
            <div class="grid">
              <groupviewmetric--ml-metric-card-brutal>
                <Icon>📈</Icon>
                <Label>Receita mensal</Label>
                <Value>R$ 128.430</Value>
                <Trend direction="up">+12,5%</Trend>
                <Helper>vs. mês anterior</Helper>
              </groupviewmetric--ml-metric-card-brutal>
              <groupviewmetric--ml-metric-card-brutal>
                <Icon>👥</Icon>
                <Label>Churn</Label>
                <Value>3,2%</Value>
                <Trend direction="down">-0,8%</Trend>
                <Helper>últimos 30 dias</Helper>
              </groupviewmetric--ml-metric-card-brutal>
              <groupviewmetric--ml-metric-big-number-brutal>
                <Label>Usuários ativos</Label>
                <Value>24.918</Value>
                <Trend direction="up">▲ 8,1%</Trend>
                <Helper>Atualizado há 5 min</Helper>
              </groupviewmetric--ml-metric-big-number-brutal>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
Demo2AcaoVisualizacao = __decorate([
    customElement('demo2--acao-visualizacao-102053')
], Demo2AcaoVisualizacao);
export { Demo2AcaoVisualizacao };
