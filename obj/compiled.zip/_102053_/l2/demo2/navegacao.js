var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo2/navegacao.ts" enhancement="_102020_/l2/enhancementAura"/>
// GERADO a partir de todo/.demo-fragments/navegacao.frag.ts — base comparável demo1/demo2/demo3.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal';
import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal';
import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-brutal';
import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal';
import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps-brutal';
import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav-brutal';
let Demo2Navegacao = class Demo2Navegacao extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo2--navegacao-102053 {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
demo2--navegacao-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo2--navegacao-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo2--navegacao-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo2--navegacao-102053 .brand {
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  margin-bottom: 0.5rem;
}
demo2--navegacao-102053 .title {
  font-size: 1.625rem;
  font-weight: 900;
  text-transform: uppercase;
  margin-bottom: 0.25rem;
}
demo2--navegacao-102053 .subtitle {
  font-size: 0.8125rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
demo2--navegacao-102053 .block {
  margin-bottom: 2rem;
  padding: 1.5rem;
}
demo2--navegacao-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  margin-bottom: 0.75rem;
  border-bottom: 2px solid #000;
  padding-bottom: 0.5rem;
}
demo2--navegacao-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo2--navegacao-102053 .page {
  background: #f5f5f5;
}
demo2--navegacao-102053 .brand {
  color: #000;
}
demo2--navegacao-102053 .title {
  color: #000;
}
demo2--navegacao-102053 .subtitle {
  color: #666;
}
demo2--navegacao-102053 .block {
  background: #ffffff;
  border: 3px solid #000;
  box-shadow: 6px 6px 0 #000;
}
demo2--navegacao-102053 .block-title {
  color: #000;
}
`);
        this.main = 'dashboard';
        this.tab = 'details';
        this.pill = 'overview';
        this.step = 1;
        this.wiz = 1;
    }
    upd(key) {
        return (e) => {
            this[key] = e.detail?.value;
        };
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">&#9632; collab · 102054</div>
            <h1 class="title">Navegação — brutalism (102054)</h1>
            <p class="subtitle">tabs · pills · breadcrumb · stepper · wizard · sidebar</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupNavigateSection — tabs / pills / breadcrumb</h2>
            <div class="grid">
              <groupnavigatesection--ml-tabs-brutal .value=${this.tab} @change=${this.upd('tab')}>
                <Label>Produto</Label>
                <Tab value="details" title="Detalhes">Descrição do produto.</Tab>
                <Tab value="reviews" title="Avaliações">Comentários dos clientes.</Tab>
              </groupnavigatesection--ml-tabs-brutal>
              <groupnavigatesection--ml-navigate-pills-brutal .value=${this.pill} @change=${this.upd('pill')}>
                <Label>Seções</Label>
                <Tab value="overview" title="Visão geral">Resumo.</Tab>
                <Tab value="team" title="Equipe">Pessoas.</Tab>
              </groupnavigatesection--ml-navigate-pills-brutal>
              <groupnavigatesection--ml-breadcrumb-trail-brutal value="produto">
                <Tab value="home" title="Início">Home.</Tab>
                <Tab value="catalogo" title="Catálogo">Catálogo.</Tab>
                <Tab value="produto" title="Notebook Pro">Produto atual.</Tab>
              </groupnavigatesection--ml-breadcrumb-trail-brutal>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupNavigateSteps — horizontal / wizard</h2>
            <div class="grid">
              <groupnavigatesteps--ml-horizontal-stepper-brutal .value=${this.step} @change=${this.upd('step')}>
                <Label>Cadastro (etapa ${this.step})</Label>
                <Step title="Conta" description="Acesso"></Step>
                <Step title="Perfil" description="Dados"></Step>
                <Step title="Pagamento" description="Plano"></Step>
                <Step title="Pronto" description="Revisão"></Step>
              </groupnavigatesteps--ml-horizontal-stepper-brutal>
              <groupnavigatesteps--ml-wizard-steps-brutal .value=${this.wiz} linear="false" @change=${this.upd('wiz')}>
                <Label>Onboarding (etapa ${this.wiz})</Label>
                <Step title="Conta" description="Acesso" completed></Step>
                <Step title="Perfil" description="Dados pessoais"></Step>
                <Step title="Plano" description="Escolha"></Step>
              </groupnavigatesteps--ml-wizard-steps-brutal>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupNavigateMain — sidebar-nav</h2>
            <div class="grid">
              <div style="height:22rem; overflow:hidden; display:flex; border:2px solid #000;">
                <groupnavigatemain--ml-sidebar-nav-brutal .value=${this.main} @change=${this.upd('main')}>
                  <Label>Aurora</Label>
                  <Item value="dashboard" icon="▦">Dashboard</Item>
                  <Item value="projects" icon="▤" badge="3">Projetos</Item>
                  <Group label="Workspace">
                    <Item value="tasks" icon="✓">Tarefas</Item>
                    <Item value="calendar" icon="▣">Calendário</Item>
                  </Group>
                  <Footer>
                    <Item value="settings" icon="⚙">Configurações</Item>
                  </Footer>
                </groupnavigatemain--ml-sidebar-nav-brutal>
              </div>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], Demo2Navegacao.prototype, "main", void 0);
__decorate([
    state()
], Demo2Navegacao.prototype, "tab", void 0);
__decorate([
    state()
], Demo2Navegacao.prototype, "pill", void 0);
__decorate([
    state()
], Demo2Navegacao.prototype, "step", void 0);
__decorate([
    state()
], Demo2Navegacao.prototype, "wiz", void 0);
Demo2Navegacao = __decorate([
    customElement('demo2--navegacao-102053')
], Demo2Navegacao);
export { Demo2Navegacao };
