var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/checkout.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — CHECKOUT (Pagamento)
// =============================================================================
// Form controlado (campos mascarados + toggles). Accordion com conteúdo ESTÁTICO
// (resumo do pedido) → não precisa de delegação. Confirmar com loading.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
let GlassShowcaseCheckout = class GlassShowcaseCheckout extends StateLitElement {
    constructor() {
        super(...arguments);
        this.cardName = '';
        this.cardNumber = '';
        this.expiry = '';
        this.cpf = '';
        this.saveCard = true;
        this.diffAddress = false;
        this.loading = false;
    }
    onCardName(e) {
        this.cardName = e.detail.value;
    }
    onCardNumber(e) {
        this.cardNumber = e.detail.value;
    }
    onExpiry(e) {
        this.expiry = e.detail.value;
    }
    onCpf(e) {
        this.cpf = e.detail.value;
    }
    onSaveCard(e) {
        this.saveCard = e.detail.value;
    }
    onDiffAddress(e) {
        this.diffAddress = e.detail.value;
    }
    onConfirm() {
        this.loading = true;
        setTimeout(() => {
            this.loading = false;
        }, 1800);
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora</div>
            <h1 class="title">Finalizar pagamento</h1>
          </header>

          <div class="grid">
            <!-- Formulário -->
            <section class="panel">
              <h2 class="panel-title">Dados do cartão</h2>
              <div class="fields">
                <groupentertext--ml-floating-text-input
                  name="cardName"
                  .value=${this.cardName}
                  .isEditing=${true}
                  @input=${this.onCardName}
                >
                  <Label>Nome impresso no cartão</Label>
                </groupentertext--ml-floating-text-input>

                <groupentertext--ml-floating-text-input
                  name="cardNumber"
                  mask="#### #### #### ####"
                  .value=${this.cardNumber}
                  .isEditing=${true}
                  @input=${this.onCardNumber}
                >
                  <Label>Número do cartão</Label>
                </groupentertext--ml-floating-text-input>

                <div class="two-col">
                  <groupentertext--ml-floating-text-input
                    name="expiry"
                    mask="##/##"
                    .value=${this.expiry}
                    .isEditing=${true}
                    @input=${this.onExpiry}
                  >
                    <Label>Validade</Label>
                  </groupentertext--ml-floating-text-input>
                  <groupentertext--ml-floating-text-input
                    name="cpf"
                    mask="###.###.###-##"
                    .value=${this.cpf}
                    .isEditing=${true}
                    @input=${this.onCpf}
                  >
                    <Label>CPF do titular</Label>
                  </groupentertext--ml-floating-text-input>
                </div>
              </div>

              <div class="toggles">
                <groupenterboolean--ml-toggle-switch
                  name="saveCard"
                  .value=${this.saveCard}
                  .isEditing=${true}
                  @change=${this.onSaveCard}
                >
                  <Label>Salvar cartão para a próxima compra</Label>
                </groupenterboolean--ml-toggle-switch>
                <groupenterboolean--ml-toggle-switch
                  name="diffAddress"
                  .value=${this.diffAddress}
                  .isEditing=${true}
                  @change=${this.onDiffAddress}
                >
                  <Label>Usar endereço de cobrança diferente</Label>
                </groupenterboolean--ml-toggle-switch>
              </div>
            </section>

            <!-- Resumo -->
            <aside class="panel">
              <h2 class="panel-title">Resumo</h2>
              <groupexpandcontent--ml-accordion multiple="true">
                <Section title="Itens (3)" expanded>
                  Plano Aurora Pro — R$ 49,00<br />
                  Armazenamento extra — R$ 19,00<br />
                  Suporte prioritário — R$ 12,00
                </Section>
                <Section title="Cupom / desconto">Nenhum cupom aplicado.</Section>
                <Section title="Total">
                  Subtotal: R$ 80,00<br />
                  Impostos: R$ 6,40<br />
                  <strong>Total: R$ 86,40</strong>
                </Section>
              </groupexpandcontent--ml-accordion>

              <div class="actions">
                <grouptriggeraction--ml-button-standard
                  data-variant="primary"
                  .loading=${this.loading}
                  @action=${this.onConfirm}
                >
                  <Label>Confirmar pagamento</Label>
                </grouptriggeraction--ml-button-standard>
                <grouptriggeraction--ml-button-standard data-variant="ghost">
                  <Label>Cancelar</Label>
                </grouptriggeraction--ml-button-standard>
              </div>
            </aside>
          </div>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseCheckout.prototype, "cardName", void 0);
__decorate([
    state()
], GlassShowcaseCheckout.prototype, "cardNumber", void 0);
__decorate([
    state()
], GlassShowcaseCheckout.prototype, "expiry", void 0);
__decorate([
    state()
], GlassShowcaseCheckout.prototype, "cpf", void 0);
__decorate([
    state()
], GlassShowcaseCheckout.prototype, "saveCard", void 0);
__decorate([
    state()
], GlassShowcaseCheckout.prototype, "diffAddress", void 0);
__decorate([
    state()
], GlassShowcaseCheckout.prototype, "loading", void 0);
GlassShowcaseCheckout = __decorate([
    customElement('glassshowcase--checkout')
], GlassShowcaseCheckout);
export { GlassShowcaseCheckout };
