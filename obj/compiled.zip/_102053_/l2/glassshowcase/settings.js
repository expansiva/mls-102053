var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/settings.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — SETTINGS (Configurações)
// =============================================================================
// Moléculas DENTRO do accordion são renderizadas via unsafeHTML (string), então
// não aceitam bindings lit (.value/@change). Padrão: não-controladas + DELEGAÇÃO
// por `name` (listener @change/@input no accordion). Conteúdo das Section deve ser
// ESTÁVEL para o cache do unsafeHTML preservar o estado interno ao expandir/colapsar.
//
// Valores iniciais: usar value="true" para ligado e OMITIR value para desligado
// (evita ambiguidade do conversor Boolean de atributo).
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
let GlassShowcaseSettings = class GlassShowcaseSettings extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase--settings-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase--settings-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 80% 10%, #3730a3 0%, transparent 50%), radial-gradient(circle at 10% 90%, #6d28d9 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #131a33 100%);
  background-attachment: fixed;
}
glassshowcase--settings-102053 .shell {
  max-width: 42rem;
  margin: 0 auto;
}
glassshowcase--settings-102053 .head {
  margin-bottom: 2rem;
}
glassshowcase--settings-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase--settings-102053 .title {
  color: #fff;
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase--settings-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
}
glassshowcase--settings-102053 .panel {
  padding: 1.75rem;
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.16);
  background: rgba(255, 255, 255, 0.07);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3), inset 0 1px 1px rgba(255, 255, 255, 0.2);
}
glassshowcase--settings-102053 .section-body {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}
glassshowcase--settings-102053 .actions {
  margin-top: 1.5rem;
  display: flex;
  gap: 0.75rem;
  justify-content: flex-end;
}
`);
        // Estado observado via delegação (não realimenta as moléculas — apenas registra).
        this.dirty = false;
        this.loading = false;
        this.values = {
            'profile-name': 'Ada Lovelace',
            'profile-email': 'ada@aurora.dev',
            'notif-weekly': true,
            'notif-product': false,
            'priv-2fa': true,
            'priv-profile-public': false,
        };
        // ── Delegação por name ──────────────────────────────────────────────────────
        this.onFieldChange = (e) => {
            const el = e.target;
            const name = el?.getAttribute?.('name');
            if (!name)
                return;
            this.values[name] = e.detail?.value;
            if (!this.dirty)
                this.dirty = true;
        };
    }
    onSave() {
        this.loading = true;
        setTimeout(() => {
            this.loading = false;
            this.dirty = false;
        }, 1500);
    }
    onCancel() {
        // Limitação conhecida: não reseta visualmente as moléculas não-controladas
        // (resetar exigiria mudar a string da Section e quebraria o cache do unsafeHTML).
        this.dirty = false;
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora</div>
            <h1 class="title">Configurações</h1>
            <p class="subtitle">Gerencie sua conta e preferências</p>
          </header>

          <div class="panel">
            <!-- Delegação: eventos das moléculas aninhadas borbulham até o accordion -->
            <groupexpandcontent--ml-accordion
              multiple="true"
              @change=${this.onFieldChange}
              @input=${this.onFieldChange}
            >
              <Label>Conta</Label>
              <Section title="Perfil" expanded>
                <div class="section-body">
                  <groupentertext--ml-floating-text-input name="profile-name" value="Ada Lovelace" is-editing="true">
                    <Label>Nome</Label>
                  </groupentertext--ml-floating-text-input>
                  <groupentertext--ml-floating-text-input
                    name="profile-email"
                    value="ada@aurora.dev"
                    input-type="email"
                    is-editing="true"
                  >
                    <Label>E-mail</Label>
                  </groupentertext--ml-floating-text-input>
                </div>
              </Section>
              <Section title="Notificações">
                <div class="section-body">
                  <groupenterboolean--ml-toggle-switch name="notif-weekly" value="true" is-editing="true">
                    <Label>Resumo semanal por e-mail</Label>
                  </groupenterboolean--ml-toggle-switch>
                  <groupenterboolean--ml-toggle-switch name="notif-product" is-editing="true">
                    <Label>Novidades do produto</Label>
                  </groupenterboolean--ml-toggle-switch>
                </div>
              </Section>
              <Section title="Privacidade">
                <div class="section-body">
                  <groupenterboolean--ml-toggle-switch name="priv-2fa" value="true" is-editing="true">
                    <Label>Autenticação em duas etapas</Label>
                  </groupenterboolean--ml-toggle-switch>
                  <groupenterboolean--ml-toggle-switch name="priv-profile-public" is-editing="true">
                    <Label>Tornar perfil público</Label>
                  </groupenterboolean--ml-toggle-switch>
                </div>
              </Section>
              <Section title="Faturamento (bloqueado)" disabled>
                Contate um administrador para alterar dados de faturamento.
              </Section>
            </groupexpandcontent--ml-accordion>

            <div class="actions">
              <grouptriggeraction--ml-button-standard
                data-variant="primary"
                .loading=${this.loading}
                .disabled=${!this.dirty}
                @action=${this.onSave}
              >
                <Label>Salvar alterações</Label>
              </grouptriggeraction--ml-button-standard>
              <grouptriggeraction--ml-button-standard data-variant="ghost" @action=${this.onCancel}>
                <Label>Cancelar</Label>
              </grouptriggeraction--ml-button-standard>
            </div>
          </div>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseSettings.prototype, "dirty", void 0);
__decorate([
    state()
], GlassShowcaseSettings.prototype, "loading", void 0);
GlassShowcaseSettings = __decorate([
    customElement('glassshowcase--settings-102053')
], GlassShowcaseSettings);
export { GlassShowcaseSettings };
