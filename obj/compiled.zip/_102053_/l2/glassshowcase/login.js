var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/login.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — LOGIN
// =============================================================================
// Página real usando as moléculas glass do mls-102054 (import cross-project).
// Padrão controlado: .value + .isEditing + @input/@change realimentando o @state.
// A página É o contrato de container (fundo escuro rico) — ver login.less.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
// Moléculas glass (mls-102054)
import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
let GlassShowcaseLogin = class GlassShowcaseLogin extends StateLitElement {
    constructor() {
        super(...arguments);
        // ── Estado controlado ──────────────────────────────────────────────────────
        this.email = '';
        this.password = '';
        this.remember = false;
        this.emailError = '';
        this.loading = false;
    }
    // ── Handlers ─────────────────────────────────────────────────────────────--
    onEmailInput(e) {
        this.email = e.detail.value;
        if (this.emailError)
            this.emailError = '';
    }
    onPasswordInput(e) {
        this.password = e.detail.value;
    }
    onRememberChange(e) {
        this.remember = e.detail.value;
    }
    isEmailValid() {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email);
    }
    onSubmit() {
        if (!this.isEmailValid()) {
            this.emailError = 'Informe um e-mail válido';
            return;
        }
        this.loading = true;
        // simula request
        setTimeout(() => {
            this.loading = false;
        }, 1500);
    }
    goToSignup() {
        // Navegação entre páginas é responsabilidade do app host (router).
        this.dispatchEvent(new CustomEvent('navigate', { bubbles: true, composed: true, detail: { to: 'signup' } }));
    }
    render() {
        return html `
      <div class="page">
        <div class="card">
          <div class="brand">◆ Aurora</div>
          <h1 class="title">Bem-vindo de volta</h1>
          <p class="subtitle">Entre para continuar</p>

          <div class="fields">
            <groupentertext--ml-floating-text-input
              name="email"
              input-type="email"
              .value=${this.email}
              .isEditing=${true}
              .error=${this.emailError}
              @input=${this.onEmailInput}
            >
              <Label>E-mail</Label>
            </groupentertext--ml-floating-text-input>

            <groupentertext--ml-floating-text-input
              name="password"
              input-type="password"
              .value=${this.password}
              .isEditing=${true}
              @input=${this.onPasswordInput}
            >
              <Label>Senha</Label>
            </groupentertext--ml-floating-text-input>
          </div>

          <div class="row-between">
            <groupenterboolean--ml-toggle-switch
              name="remember"
              .value=${this.remember}
              .isEditing=${true}
              @change=${this.onRememberChange}
            >
              <Label>Manter conectado</Label>
            </groupenterboolean--ml-toggle-switch>
            <grouptriggeraction--ml-button-standard data-variant="link" size="sm">
              <Label>Esqueci a senha</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

          <div class="submit">
            <grouptriggeraction--ml-button-standard
              data-variant="primary"
              .loading=${this.loading}
              @action=${this.onSubmit}
            >
              <Label>Entrar</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

          <p class="footer">
            Não tem conta?
            <grouptriggeraction--ml-button-standard data-variant="link" size="sm" @action=${this.goToSignup}>
              <Label>Criar conta</Label>
            </grouptriggeraction--ml-button-standard>
          </p>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseLogin.prototype, "email", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "password", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "remember", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "emailError", void 0);
__decorate([
    state()
], GlassShowcaseLogin.prototype, "loading", void 0);
GlassShowcaseLogin = __decorate([
    customElement('glassshowcase--login-102053')
], GlassShowcaseLogin);
export { GlassShowcaseLogin };
