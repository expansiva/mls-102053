var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/index.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — HUB
// =============================================================================
// Navega entre as 4 páginas. Renderiza a página escolhida e escuta o evento
// 'navigate' que login/signup emitem para alternar entre si.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102053_/l2/glassshowcase/login';
import '/_102053_/l2/glassshowcase/signup';
import '/_102053_/l2/glassshowcase/checkout';
import '/_102053_/l2/glassshowcase/settings';
let GlassShowcaseIndex = class GlassShowcaseIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        this.page = 'home';
        // login/signup emitem 'navigate' { to } — capturamos por delegação
        this.onNavigate = (e) => {
            const to = e.detail?.to;
            if (to)
                this.page = to;
        };
    }
    go(page) {
        this.page = page;
    }
    connectedCallback() {
        super.connectedCallback();
        this.addEventListener('navigate', this.onNavigate);
    }
    disconnectedCallback() {
        this.removeEventListener('navigate', this.onNavigate);
        super.disconnectedCallback();
    }
    renderHome() {
        const cards = [
            { id: 'login', title: 'Login', desc: 'Entrar na conta' },
            { id: 'signup', title: 'Cadastro', desc: 'Criar conta com máscara de telefone' },
            { id: 'checkout', title: 'Checkout', desc: 'Pagamento com máscaras e resumo' },
            { id: 'settings', title: 'Configurações', desc: 'Accordion + preferências' },
        ];
        return html `
      <div class="hub">
        <header class="hub-head">
          <div class="brand">◆ Aurora</div>
          <h1 class="title">Glass Showcase</h1>
          <p class="subtitle">Páginas montadas com as moléculas glassmorphism (mls-102054)</p>
        </header>
        <div class="cards">
          ${cards.map((c) => html `
              <button class="nav-card" @click=${() => this.go(c.id)}>
                <span class="nav-card-title">${c.title}</span>
                <span class="nav-card-desc">${c.desc}</span>
              </button>
            `)}
        </div>
      </div>
    `;
    }
    renderPage() {
        const view = this.page === 'login'
            ? html `<glassshowcase--login></glassshowcase--login>`
            : this.page === 'signup'
                ? html `<glassshowcase--signup></glassshowcase--signup>`
                : this.page === 'checkout'
                    ? html `<glassshowcase--checkout></glassshowcase--checkout>`
                    : html `<glassshowcase--settings></glassshowcase--settings>`;
        return html `
      <div class="page-wrap">
        <button class="back" @click=${() => this.go('home')}>← Voltar</button>
        ${view}
      </div>
    `;
    }
    render() {
        return html ` <div class="root">${this.page === 'home' ? this.renderHome() : this.renderPage()}</div> `;
    }
};
__decorate([
    state()
], GlassShowcaseIndex.prototype, "page", void 0);
GlassShowcaseIndex = __decorate([
    customElement('glassshowcase--index')
], GlassShowcaseIndex);
export { GlassShowcaseIndex };
