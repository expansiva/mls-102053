var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/signup.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — SIGNUP (Cadastro)
// =============================================================================
// Padrão controlado (.value + .isEditing + @input/@change). Telefone com máscara.
// "Criar conta" desabilitado até aceitar os termos. A página é o container glass.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
let GlassShowcaseSignup = class GlassShowcaseSignup extends StateLitElement {
    constructor() {
        super(...arguments);
        this.name = '';
        this.email = '';
        this.phone = '';
        this.password = '';
        this.acceptedTerms = false;
        this.loading = false;
    }
    onName(e) {
        this.name = e.detail.value;
    }
    onEmail(e) {
        this.email = e.detail.value;
    }
    onPhone(e) {
        this.phone = e.detail.value;
    }
    onPassword(e) {
        this.password = e.detail.value;
    }
    onTerms(e) {
        this.acceptedTerms = e.detail.value;
    }
    onSubmit() {
        if (!this.acceptedTerms)
            return;
        this.loading = true;
        setTimeout(() => {
            this.loading = false;
        }, 1500);
    }
    goToLogin() {
        this.dispatchEvent(new CustomEvent('navigate', { bubbles: true, composed: true, detail: { to: 'login' } }));
    }
    render() {
        return html `
      <div class="page">
        <div class="card">
          <div class="brand">◆ Aurora</div>
          <h1 class="title">Crie sua conta</h1>
          <p class="subtitle">Leva menos de um minuto</p>

          <div class="fields">
            <groupentertext--ml-floating-text-input
              name="name"
              .value=${this.name}
              .isEditing=${true}
              @input=${this.onName}
            >
              <Label>Nome completo</Label>
            </groupentertext--ml-floating-text-input>

            <groupentertext--ml-floating-text-input
              name="email"
              input-type="email"
              .value=${this.email}
              .isEditing=${true}
              @input=${this.onEmail}
            >
              <Label>E-mail</Label>
            </groupentertext--ml-floating-text-input>

            <groupentertext--ml-floating-text-input
              name="phone"
              input-type="tel"
              mask="(##) #####-####"
              .value=${this.phone}
              .isEditing=${true}
              @input=${this.onPhone}
            >
              <Label>Telefone</Label>
            </groupentertext--ml-floating-text-input>

            <groupentertext--ml-floating-text-input
              name="password"
              input-type="password"
              .value=${this.password}
              .isEditing=${true}
              @input=${this.onPassword}
            >
              <Label>Senha</Label>
            </groupentertext--ml-floating-text-input>
          </div>

          <div class="terms">
            <groupenterboolean--ml-toggle-switch
              name="terms"
              .value=${this.acceptedTerms}
              .isEditing=${true}
              @change=${this.onTerms}
            >
              <Label>Aceito os termos de uso</Label>
            </groupenterboolean--ml-toggle-switch>
          </div>

          <div class="submit">
            <grouptriggeraction--ml-button-standard
              data-variant="primary"
              .loading=${this.loading}
              .disabled=${!this.acceptedTerms}
              @action=${this.onSubmit}
            >
              <Label>Criar conta</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

          <p class="footer">
            Já tem conta?
            <grouptriggeraction--ml-button-standard data-variant="link" size="sm" @action=${this.goToLogin}>
              <Label>Entrar</Label>
            </grouptriggeraction--ml-button-standard>
          </p>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseSignup.prototype, "name", void 0);
__decorate([
    state()
], GlassShowcaseSignup.prototype, "email", void 0);
__decorate([
    state()
], GlassShowcaseSignup.prototype, "phone", void 0);
__decorate([
    state()
], GlassShowcaseSignup.prototype, "password", void 0);
__decorate([
    state()
], GlassShowcaseSignup.prototype, "acceptedTerms", void 0);
__decorate([
    state()
], GlassShowcaseSignup.prototype, "loading", void 0);
GlassShowcaseSignup = __decorate([
    customElement('glassshowcase--signup-102053')
], GlassShowcaseSignup);
export { GlassShowcaseSignup };
