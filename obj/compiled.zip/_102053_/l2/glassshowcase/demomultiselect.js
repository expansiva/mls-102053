var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase/demomultiselect.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE — DEMO MULTI SELECT
// =============================================================================
// Exemplo enxuto do ml-multi-select-dropdown (glass, mls-102054). Controlado:
// .value (CSV) + .isEditing + @change. A página é o contrato de container.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
let GlassShowcaseDemoMultiSelect = class GlassShowcaseDemoMultiSelect extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase--demomultiselect-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase--demomultiselect-102053 .page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background: radial-gradient(circle at 20% 20%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 80% 70%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase--demomultiselect-102053 .card {
  width: 100%;
  max-width: 26rem;
  padding: 2.5rem 2rem;
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 16px 50px rgba(0, 0, 0, 0.35), inset 0 1px 1px rgba(255, 255, 255, 0.25);
}
glassshowcase--demomultiselect-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 1.5rem;
}
glassshowcase--demomultiselect-102053 .title {
  color: #fff;
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase--demomultiselect-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.875rem;
  margin-bottom: 2rem;
}
glassshowcase--demomultiselect-102053 .subtitle code {
  color: #c7d2fe;
}
glassshowcase--demomultiselect-102053 .fields {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}
glassshowcase--demomultiselect-102053 .result {
  margin-top: 1.75rem;
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.75);
}
glassshowcase--demomultiselect-102053 .result strong {
  color: #fff;
}
`);
        this.skills = 'ts,js';
        this.teams = '';
    }
    onSkills(e) {
        this.skills = e.detail.value;
    }
    onTeams(e) {
        this.teams = e.detail.value;
    }
    render() {
        return html `
      <div class="page">
        <div class="card">
          <div class="brand">◆ Aurora</div>
          <h1 class="title">Multi Select</h1>
          <p class="subtitle">Exemplo glass do <code>ml-multi-select-dropdown</code></p>

          <div class="fields">
            <groupselectmany--ml-multi-select-dropdown
              name="skills"
              searchable="true"
              max-selection="3"
              .value=${this.skills}
              .isEditing=${true}
              @change=${this.onSkills}
            >
              <Label>Tecnologias</Label>
              <Helper>Até 3 — use a busca</Helper>
              <Item value="ts">TypeScript</Item>
              <Item value="js">JavaScript</Item>
              <Item value="py">Python</Item>
              <Item value="go">Go</Item>
              <Item value="rs">Rust</Item>
            </groupselectmany--ml-multi-select-dropdown>

            <groupselectmany--ml-multi-select-dropdown
              name="teams"
              .value=${this.teams}
              .isEditing=${true}
              @change=${this.onTeams}
            >
              <Label>Times</Label>
              <Group label="Engenharia">
                <Item value="fe">Front-end</Item>
                <Item value="be">Back-end</Item>
              </Group>
              <Group label="Produto">
                <Item value="pm">PM</Item>
                <Item value="ux">UX</Item>
              </Group>
            </groupselectmany--ml-multi-select-dropdown>
          </div>

          <p class="result">Skills: <strong>${this.skills || '—'}</strong> · Times: <strong>${this.teams || '—'}</strong></p>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcaseDemoMultiSelect.prototype, "skills", void 0);
__decorate([
    state()
], GlassShowcaseDemoMultiSelect.prototype, "teams", void 0);
GlassShowcaseDemoMultiSelect = __decorate([
    customElement('glassshowcase--demomultiselect-102053')
], GlassShowcaseDemoMultiSelect);
export { GlassShowcaseDemoMultiSelect };
