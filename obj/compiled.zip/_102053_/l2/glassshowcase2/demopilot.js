var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase2/demopilot.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE 2 (mls-102055 por herança) — DEMO PILOTO
// =============================================================================
// Demonstra as moléculas glass do mls-102055 (herdadas do 102040, tag -glass).
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
let GlassShowcase2DemoPilot = class GlassShowcase2DemoPilot extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase2--demopilot-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase2--demopilot-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase2--demopilot-102053 .shell {
  max-width: 34rem;
  margin: 0 auto;
}
glassshowcase2--demopilot-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase2--demopilot-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase2--demopilot-102053 .title {
  color: #fff;
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase2--demopilot-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.8125rem;
}
glassshowcase2--demopilot-102053 .subtitle code {
  background: rgba(255, 255, 255, 0.12);
  padding: 0.05rem 0.35rem;
  border-radius: 6px;
}
glassshowcase2--demopilot-102053 .block {
  margin-bottom: 2rem;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  padding: 1.5rem;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
glassshowcase2--demopilot-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
`);
        this.notif = false;
        this.terms = true;
        this.date = '2026-06-18';
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora · 102055</div>
            <h1 class="title">Glass por Herança — Piloto</h1>
            <p class="subtitle">moléculas do mls-102055 (herdam o 102040, tag <code>-glass</code>)</p>
          </header>

          <section class="block">
            <h2 class="block-title">Toggle Switch (simples)</h2>
            <div style="display:flex; flex-direction:column; gap:1.25rem;">
              <groupenterboolean--ml-toggle-switch-glass
                .value=${this.notif}
                @change=${(e) => {
            this.notif = e.detail.value;
        }}
              >
                <Label>Notificações (${this.notif ? 'on' : 'off'})</Label>
                <Helper>Receber alertas por e-mail</Helper>
              </groupenterboolean--ml-toggle-switch-glass>

              <groupenterboolean--ml-toggle-switch-glass
                .value=${this.terms}
                @change=${(e) => {
            this.terms = e.detail.value;
        }}
              >
                <Label>Aceito os termos (${this.terms ? 'sim' : 'não'})</Label>
              </groupenterboolean--ml-toggle-switch-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">Date Picker (pesada de lógica)</h2>
            <groupenterdate--ml-date-picker-glass
              .value=${this.date}
              locale="pt-BR"
              first-day-of-week="1"
              @change=${(e) => {
            this.date = e.detail.value;
        }}
            >
              <Label>Data de início</Label>
              <Helper>Selecionada: ${this.date ?? '—'}</Helper>
            </groupenterdate--ml-date-picker-glass>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcase2DemoPilot.prototype, "notif", void 0);
__decorate([
    state()
], GlassShowcase2DemoPilot.prototype, "terms", void 0);
__decorate([
    state()
], GlassShowcase2DemoPilot.prototype, "date", void 0);
GlassShowcase2DemoPilot = __decorate([
    customElement('glassshowcase2--demopilot-102053')
], GlassShowcase2DemoPilot);
export { GlassShowcase2DemoPilot };
