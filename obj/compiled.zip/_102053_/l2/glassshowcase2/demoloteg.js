var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase2/demoloteg.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE 2 (mls-102055 por herança) — DEMO LOTE G (métricas / progresso / rating)
// =============================================================================
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
let GlassShowcase2DemoLoteG = class GlassShowcase2DemoLoteG extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase2--demoloteg-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase2--demoloteg-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase2--demoloteg-102053 .shell {
  max-width: 48rem;
  margin: 0 auto;
}
glassshowcase2--demoloteg-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase2--demoloteg-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase2--demoloteg-102053 .title {
  color: #fff;
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase2--demoloteg-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.8125rem;
}
glassshowcase2--demoloteg-102053 .block {
  margin-bottom: 2rem;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  padding: 1.5rem;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
glassshowcase2--demoloteg-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
glassshowcase2--demoloteg-102053 .grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1.25rem;
}
`);
        this.stars = 3;
        this.mood = 4;
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora · 102055</div>
            <h1 class="title">Lote G — Métricas, Progresso e Rating (por herança)</h1>
            <p class="subtitle">metric-card · big-number · linear · circular · stars · mood</p>
          </header>

          <section class="block">
            <h2 class="block-title">Métricas</h2>
            <div class="grid">
              <groupviewmetric--ml-metric-card-glass>
                <Icon>📈</Icon>
                <Label>Receita mensal</Label>
                <Value>R$ 128.430</Value>
                <Trend direction="up">+12,5%</Trend>
                <Helper>vs. mês anterior</Helper>
              </groupviewmetric--ml-metric-card-glass>
              <groupviewmetric--ml-metric-card-glass>
                <Icon>👥</Icon>
                <Label>Churn</Label>
                <Value>3,2%</Value>
                <Trend direction="down">-0,8%</Trend>
                <Helper>últimos 30 dias</Helper>
              </groupviewmetric--ml-metric-card-glass>
              <groupviewmetric--ml-metric-big-number-glass>
                <Label>Usuários ativos</Label>
                <Value>24.918</Value>
                <Trend direction="up">▲ 8,1%</Trend>
                <Helper>há 5 min</Helper>
              </groupviewmetric--ml-metric-big-number-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">Progresso</h2>
            <div style="display:flex; flex-direction:column; gap:1.25rem;">
              <groupshowprogress--ml-linear-progress-glass value="72" show-value label="Upload"></groupshowprogress--ml-linear-progress-glass>
              <groupshowprogress--ml-linear-progress-glass value="40" variant="success" size="sm" show-value></groupshowprogress--ml-linear-progress-glass>
              <groupshowprogress--ml-linear-progress-glass value="88" variant="warning" size="lg" show-value></groupshowprogress--ml-linear-progress-glass>
              <div style="display:flex; align-items:center; gap:2rem; justify-content:center; margin-top:0.5rem;">
                <groupshowprogress--ml-circular-progress-glass value="68" size="lg" show-value></groupshowprogress--ml-circular-progress-glass>
                <groupshowprogress--ml-circular-progress-glass value="33" size="lg" show-value></groupshowprogress--ml-circular-progress-glass>
                <groupshowprogress--ml-circular-progress-glass size="lg"></groupshowprogress--ml-circular-progress-glass>
              </div>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">Star Rating</h2>
            <grouprateitem--ml-star-rating-glass
              .value=${this.stars}
              min="1"
              max="5"
              @change=${(e) => {
            this.stars = e.detail.value;
        }}
            >
              <Label>Avaliação (${this.stars} ★)</Label>
              <Helper>Clique ou use as setas</Helper>
            </grouprateitem--ml-star-rating-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Emoji Mood Scale</h2>
            <grouprateitem--ml-emoji-mood-scale-glass
              .value=${this.mood}
              @change=${(e) => {
            this.mood = e.detail.value;
        }}
            >
              <Label>Como foi sua experiência? (${this.mood})</Label>
              <Item value="1">😡</Item>
              <Item value="2">🙁</Item>
              <Item value="3">😐</Item>
              <Item value="4">🙂</Item>
              <Item value="5">😍</Item>
            </grouprateitem--ml-emoji-mood-scale-glass>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcase2DemoLoteG.prototype, "stars", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteG.prototype, "mood", void 0);
GlassShowcase2DemoLoteG = __decorate([
    customElement('glassshowcase2--demoloteg-102053')
], GlassShowcase2DemoLoteG);
export { GlassShowcase2DemoLoteG };
