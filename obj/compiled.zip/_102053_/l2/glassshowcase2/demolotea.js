var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/glassshowcase2/demolotea.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GLASS SHOWCASE 2 (mls-102055 por herança) — DEMO LOTE A (entrada)
// =============================================================================
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
let GlassShowcase2DemoLoteA = class GlassShowcase2DemoLoteA extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuI6fMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZg.ttf) format('truetype');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/inter/v20/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZg.ttf) format('truetype');
}
glassshowcase2--demolotea-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
glassshowcase2--demolotea-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
glassshowcase2--demolotea-102053 .shell {
  max-width: 40rem;
  margin: 0 auto;
}
glassshowcase2--demolotea-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
glassshowcase2--demolotea-102053 .brand {
  color: #c7d2fe;
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
glassshowcase2--demolotea-102053 .title {
  color: #fff;
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
glassshowcase2--demolotea-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
  font-size: 0.8125rem;
}
glassshowcase2--demolotea-102053 .block {
  margin-bottom: 2rem;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  padding: 1.5rem;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
glassshowcase2--demolotea-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
`);
        this.fullName = '';
        this.password = 'Senha1!';
        this.tags = 'design, glass, lit';
        this.price = 129.9;
        this.qty = 2;
        this.priceLow = 200;
        this.priceHigh = 800;
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ Aurora · 102055</div>
            <h1 class="title">Lote A — Entrada (por herança)</h1>
            <p class="subtitle">texto · senha · tags · moeda · stepper · range</p>
          </header>

          <section class="block">
            <h2 class="block-title">Texto / Senha / Tags</h2>
            <div style="display:flex; flex-direction:column; gap:1.5rem;">
              <groupentertext--ml-floating-text-input-glass
                .value=${this.fullName}
                @input=${(e) => { this.fullName = e.detail.value; }}
              >
                <Label>Full name</Label>
                <Helper>As shown on your document</Helper>
              </groupentertext--ml-floating-text-input-glass>

              <groupentertext--ml-password-strength-input-glass
                .value=${this.password}
                min-length="8"
                required
                @input=${(e) => { this.password = e.detail.value; }}
              >
                <Label>Senha</Label>
                <Helper>Use letras, números e símbolos</Helper>
              </groupentertext--ml-password-strength-input-glass>

              <groupentertext--ml-tag-input-glass
                .value=${this.tags}
                @input=${(e) => { this.tags = e.detail.value; }}
              >
                <Label>Tags</Label>
                <Helper>Enter ou vírgula para adicionar</Helper>
              </groupentertext--ml-tag-input-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">Moeda</h2>
            <groupentermoney--ml-currency-input-glass
              .value=${this.price}
              currency="BRL"
              locale="pt-BR"
              @input=${(e) => { this.price = e.detail.value; }}
            >
              <Label>Preço</Label>
              <Helper>Digite o valor em centavos</Helper>
            </groupentermoney--ml-currency-input-glass>
          </section>

          <section class="block">
            <h2 class="block-title">Número / Range</h2>
            <div style="display:flex; flex-direction:column; gap:1.5rem;">
              <groupenternumber--ml-number-stepper-glass
                .value=${this.qty}
                min="0"
                max="10"
                step="1"
                @input=${(e) => { this.qty = e.detail.value; }}
              >
                <Label>Quantidade (${this.qty})</Label>
              </groupenternumber--ml-number-stepper-glass>

              <groupenternumber--ml-range-slider-glass
                .value=${this.priceLow}
                .valueHigh=${this.priceHigh}
                min="0"
                max="1000"
                step="50"
                locale="pt-BR"
                @input=${(e) => { this.priceLow = e.detail.value.min; this.priceHigh = e.detail.value.max; }}
              >
                <Label>Faixa de preço</Label>
                <Helper>${this.priceLow} – ${this.priceHigh}</Helper>
                <Prefix>R$</Prefix>
              </groupenternumber--ml-range-slider-glass>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], GlassShowcase2DemoLoteA.prototype, "fullName", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteA.prototype, "password", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteA.prototype, "tags", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteA.prototype, "price", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteA.prototype, "qty", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteA.prototype, "priceLow", void 0);
__decorate([
    state()
], GlassShowcase2DemoLoteA.prototype, "priceHigh", void 0);
GlassShowcase2DemoLoteA = __decorate([
    customElement('glassshowcase2--demolotea-102053')
], GlassShowcase2DemoLoteA);
export { GlassShowcase2DemoLoteA };
