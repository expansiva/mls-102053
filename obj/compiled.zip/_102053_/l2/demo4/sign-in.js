/// <mls fileReference="_102053_/l2/demo4/sign-in.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DEMO 4 — SIGN IN: pagina real usando componentes com DS
// =============================================================================
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
let Demo4SignIn = class Demo4SignIn extends StateLitElement {
    constructor() {
        super(...arguments);
        this.email = '';
        this.password = '';
        this.remember = false;
        this.loading = false;
        this.error = '';
    }
    handleSubmit() {
        if (!this.email || !this.password) {
            this.error = 'Preencha todos os campos';
            return;
        }
        this.error = '';
        this.loading = true;
        setTimeout(() => {
            this.loading = false;
        }, 2000);
    }
    render() {
        return html `
      <div class="sign-in-page">
        <div class="sign-in-card">

          <div class="sign-in-header">
            <h1 class="sign-in-title">Entrar</h1>
            <p class="sign-in-subtitle">Acesse sua conta para continuar</p>
          </div>

          ${this.error ? html `
            <div class="sign-in-error">${this.error}</div>
          ` : html ``}

          <div class="sign-in-form">
            <groupentertext--ml-floating-text-input
              .value=${this.email}
              input-type="email"
              placeholder="seu@email.com"
              .isEditing=${true}
              ?disabled=${this.loading}
              @input=${(e) => { this.email = e.detail?.value; }}>
              <Label>E-mail</Label>
            </groupentertext--ml-floating-text-input>

            <groupentertext--ml-floating-text-input
              class-name="mt-4"
              .value=${this.password}
              input-type="password"
              placeholder="********"
              .isEditing=${true}
              ?disabled=${this.loading}
              @input=${(e) => { this.password = e.detail?.value; }}>
              <Label>Senha</Label>
            </groupentertext--ml-floating-text-input>

            <div class="sign-in-options">
              <groupenterboolean--ml-toggle-switch
                .value=${this.remember}
                ?disabled=${this.loading}
                @change=${(e) => { this.remember = e.detail?.value; }}>
                <Label class="text-xs">Lembrar de mim</Label>
              </groupenterboolean--ml-toggle-switch>

              <grouptriggeraction--ml-button-standard data-variant="link" size="sm">
                <Label class="text-xs">Esqueci minha senha</Label>
              </grouptriggeraction--ml-button-standard>
            </div>

            <grouptriggeraction--ml-button-standard
              class-name="w-full"
              data-variant="primary"
              size="lg"
              ?loading=${this.loading}
              @action=${this.handleSubmit}>
              <Label>Entrar</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

          <div class="sign-in-footer">
            <span class="sign-in-footer-text">Nao tem uma conta?</span>
            <grouptriggeraction--ml-button-standard data-variant="link" size="sm">
              <Label>Criar conta</Label>
            </grouptriggeraction--ml-button-standard>
          </div>

        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], Demo4SignIn.prototype, "email", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "password", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "remember", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "loading", void 0);
__decorate([
    state()
], Demo4SignIn.prototype, "error", void 0);
Demo4SignIn = __decorate([
    customElement('demo4--sign-in-102053')
], Demo4SignIn);
export { Demo4SignIn };
