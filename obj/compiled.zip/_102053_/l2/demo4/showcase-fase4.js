/// <mls fileReference="_102053_/l2/demo4/showcase-fase4.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DEMO 4 — SHOWCASE FASE 4: Dark mode via tokens
// =============================================================================
// Os componentes nao mudam. O .less desta pagina define tokens dark que
// sobrescrevem os defaults quando a classe .dark esta no container.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
import '/_102053_/l2/molecules/groupexpandcontent/ml-accordion';
let Demo4ShowcaseFase4 = class Demo4ShowcaseFase4 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo4--showcase-fase4-102053 .showcase-container {
  padding: 2rem;
  min-height: 100vh;
  transition: background 300ms ease, color 300ms ease;
}
demo4--showcase-fase4-102053 .showcase-topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
}
demo4--showcase-fase4-102053 .showcase-toggle {
  padding: 0.5rem 1rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  background: #f5f5f5;
  color: #1c1b1f;
}
demo4--showcase-fase4-102053 .dark {
  background: #1c1b1f;
  color: #e6e1e5;
  --ml-surface: #2b2930;
  --ml-surface-dim: #1c1b1f;
  --ml-on-surface: #e6e1e5;
  --ml-on-surface-muted: #cac4d0;
  --ml-on-surface-faint: #938f99;
  --ml-primary: #93c5fd;
  --ml-on-primary: #1e3a5f;
  --ml-error: #f87171;
  --ml-on-error: #450a0a;
  --ml-success: #4ade80;
  --ml-outline-variant: #49454f;
  --ml-outline-focus: #93c5fd;
  --ml-outline-error: #f87171;
  --ml-shadow-1: 0 1px 3px rgba(0, 0, 0, 0.4);
  --ml-shadow-2: 0 4px 6px rgba(0, 0, 0, 0.4);
  --ml-focus-ring-color: rgba(147, 197, 253, 0.4);
}
demo4--showcase-fase4-102053 .dark .showcase-toggle {
  background: #49454f;
  color: #e6e1e5;
  border-color: #938f99;
}
`);
        this.darkMode = false;
        this.toggleVal = true;
        this.toggleOff = false;
    }
    toggleDarkMode() {
        this.darkMode = !this.darkMode;
    }
    render() {
        return html `
      <div class="showcase-container ${this.darkMode ? 'dark' : ''}">

        <div class="showcase-topbar">
          <div>
            <h1>Showcase Fase 4 — Dark Mode</h1>
            <p>Mesmos componentes, zero alteracao. Apenas tokens trocados via classe .dark</p>
          </div>
          <button class="showcase-toggle" @click=${this.toggleDarkMode}>
            ${this.darkMode ? 'Light Mode' : 'Dark Mode'}
          </button>
        </div>

        <hr>

        <h2>Button Standard</h2>
        <div>
          <grouptriggeraction--ml-button-standard data-variant="primary">
            <Label>Primary</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="secondary">
            <Label>Secondary</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="danger">
            <Label>Danger</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="ghost">
            <Label>Ghost</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="link">
            <Label>Link</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <h3>States</h3>
        <div>
          <grouptriggeraction--ml-button-standard data-variant="primary" disabled>
            <Label>Disabled</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="primary" loading>
            <Label>Loading</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <hr>

        <h2>Floating Text Input</h2>
        <div>
          <groupentertext--ml-floating-text-input
            .value=${''}
            placeholder="Digite algo..."
            .isEditing=${true}>
            <Label>Campo normal</Label>
            <Helper>Texto de ajuda</Helper>
          </groupentertext--ml-floating-text-input>
        </div>

        <div>
          <groupentertext--ml-floating-text-input
            .value=${'maria@'}
            error="E-mail invalido"
            .isEditing=${true}>
            <Label>Com erro</Label>
          </groupentertext--ml-floating-text-input>
        </div>

        <div>
          <groupentertext--ml-floating-text-input
            .value=${'Valor fixo'}
            disabled
            .isEditing=${true}>
            <Label>Desabilitado</Label>
          </groupentertext--ml-floating-text-input>
        </div>

        <hr>

        <h2>Toggle Switch</h2>
        <div>
          <groupenterboolean--ml-toggle-switch
            .value=${this.toggleVal}
            @change=${(e) => { this.toggleVal = e.detail?.value; }}>
            <Label>Ativo</Label>
            <Helper>Toggle ligado</Helper>
          </groupenterboolean--ml-toggle-switch>
        </div>

        <div>
          <groupenterboolean--ml-toggle-switch
            .value=${this.toggleOff}
            @change=${(e) => { this.toggleOff = e.detail?.value; }}>
            <Label>Inativo</Label>
          </groupenterboolean--ml-toggle-switch>
        </div>

        <div>
          <groupenterboolean--ml-toggle-switch
            .value=${false}
            error="Obrigatorio">
            <Label>Com erro</Label>
          </groupenterboolean--ml-toggle-switch>
        </div>

        <hr>

        <h2>Accordion</h2>
        <div>
          <groupexpandcontent--ml-accordion multiple>
            <Section title="Secao 1">Conteudo da primeira secao.</Section>
            <Section title="Secao 2">Conteudo da segunda secao.</Section>
            <Section title="Secao 3">Conteudo da terceira secao.</Section>
          </groupexpandcontent--ml-accordion>
        </div>

      </div>
    `;
    }
};
__decorate([
    state()
], Demo4ShowcaseFase4.prototype, "darkMode", void 0);
__decorate([
    state()
], Demo4ShowcaseFase4.prototype, "toggleVal", void 0);
__decorate([
    state()
], Demo4ShowcaseFase4.prototype, "toggleOff", void 0);
Demo4ShowcaseFase4 = __decorate([
    customElement('demo4--showcase-fase4-102053')
], Demo4ShowcaseFase4);
export { Demo4ShowcaseFase4 };
