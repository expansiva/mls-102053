/// <mls fileReference="_102053_/l2/demo4/showcase-fase1-ds.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DEMO 4 — SHOWCASE FASE 1 DS: mesmos componentes, com design system customizado
// =============================================================================
// Mesma pagina que showcase-fase1, mas com tokens --ml-* sobrescritos via .less.
// Demonstra que os componentes se adaptam ao design do projeto consumidor.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
import '/_102053_/l2/molecules/groupexpandcontent/ml-accordion';
let Demo4ShowcaseFase1Ds = class Demo4ShowcaseFase1Ds extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo4--showcase-fase1-ds-102053 {
  --ml-primary: #7c3aed;
  --ml-on-primary: #ffffff;
  --ml-error: #dc2626;
  --ml-on-error: #ffffff;
  --ml-success: #16a34a;
  --ml-surface: #fafafa;
  --ml-surface-dim: #f0f0f0;
  --ml-on-surface: #18181b;
  --ml-on-surface-muted: #52525b;
  --ml-on-surface-faint: #a1a1aa;
  --ml-outline-variant: #d4d4d8;
  --ml-outline-focus: #7c3aed;
  --ml-outline-error: #dc2626;
  --ml-radius-sm: 10px;
  --ml-radius-md: 14px;
  --ml-radius-lg: 20px;
  --ml-radius-full: 9999px;
  --ml-shadow-0: none;
  --ml-shadow-1: 0 2px 8px rgba(0, 0, 0, 0.08);
  --ml-shadow-2: 0 8px 24px rgba(0, 0, 0, 0.12);
  --ml-font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-border-width: 1.5px;
  --ml-transition: 250ms cubic-bezier(0.4, 0, 0.2, 1);
  --ml-focus-ring-color: rgba(124, 58, 237, 0.35);
  --ml-focus-ring-width: 3px;
}
`);
        this.toggleOn = true;
        this.toggleOff = false;
    }
    handleInput(key) {
        return (e) => {
            this[key] = e.detail?.value;
        };
    }
    render() {
        return html `
      <div>
        <h1>Showcase Fase 1 DS — Design customizado via tokens</h1>
        <p>Mesmos componentes, mas com tokens --ml-* sobrescritos no .less desta pagina.</p>

        <hr>

        <h2>Button Standard</h2>
        <div>
          <grouptriggeraction--ml-button-standard data-variant="primary">
            <Label>Primary</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="secondary">
            <Label>Secondary</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="danger">
            <Label>Danger</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="ghost">
            <Label>Ghost</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="link">
            <Label>Link</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <h3>Sizes</h3>
        <div>
          <grouptriggeraction--ml-button-standard data-variant="primary" size="xs">
            <Label>XS</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="primary" size="sm">
            <Label>SM</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="primary" size="md">
            <Label>MD</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="primary" size="lg">
            <Label>LG</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <h3>States</h3>
        <div>
          <grouptriggeraction--ml-button-standard data-variant="primary" disabled>
            <Label>Disabled</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="primary" loading>
            <Label>Loading</Label>
          </grouptriggeraction--ml-button-standard>

          <grouptriggeraction--ml-button-standard data-variant="primary">
            <Icon><svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></Icon>
            <Label>Com icone</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <hr>

        <h2>Floating Text Input</h2>
        <div>
          <groupentertext--ml-floating-text-input
            .value=${''}
            placeholder="Digite algo..."
            .isEditing=${true}>
            <Label>Campo normal</Label>
            <Helper>Texto de ajuda</Helper>
          </groupentertext--ml-floating-text-input>
        </div>

        <div>
          <groupentertext--ml-floating-text-input
            .value=${'João da Silva'}
            .isEditing=${true}>
            <Label>Preenchido</Label>
          </groupentertext--ml-floating-text-input>
        </div>

        <div>
          <groupentertext--ml-floating-text-input
            .value=${'maria@'}
            error="E-mail invalido"
            .isEditing=${true}>
            <Label>Com erro</Label>
          </groupentertext--ml-floating-text-input>
        </div>

        <div>
          <groupentertext--ml-floating-text-input
            .value=${'Valor fixo'}
            disabled
            .isEditing=${true}>
            <Label>Desabilitado</Label>
          </groupentertext--ml-floating-text-input>
        </div>

        <hr>

        <h2>Toggle Switch</h2>
        <div>
          <groupenterboolean--ml-toggle-switch
            .value=${this.toggleOn}
            @change=${this.handleInput('toggleOn')}>
            <Label>Ativo</Label>
            <Helper>Toggle ligado</Helper>
          </groupenterboolean--ml-toggle-switch>
        </div>

        <div>
          <groupenterboolean--ml-toggle-switch
            .value=${this.toggleOff}
            @change=${this.handleInput('toggleOff')}>
            <Label>Inativo</Label>
          </groupenterboolean--ml-toggle-switch>
        </div>

        <div>
          <groupenterboolean--ml-toggle-switch
            .value=${false}
            error="Obrigatorio">
            <Label>Com erro</Label>
          </groupenterboolean--ml-toggle-switch>
        </div>

        <hr>

        <h2>Accordion</h2>
        <div>
          <groupexpandcontent--ml-accordion multiple>
            <Section title="Secao 1">Conteudo da primeira secao. Texto livre para demonstrar o expand/collapse.</Section>
            <Section title="Secao 2">Conteudo da segunda secao. Mais texto para testar a altura variavel.</Section>
            <Section title="Secao 3">Conteudo da terceira secao.</Section>
          </groupexpandcontent--ml-accordion>
        </div>

      </div>
    `;
    }
};
__decorate([
    state()
], Demo4ShowcaseFase1Ds.prototype, "toggleOn", void 0);
__decorate([
    state()
], Demo4ShowcaseFase1Ds.prototype, "toggleOff", void 0);
Demo4ShowcaseFase1Ds = __decorate([
    customElement('demo4--showcase-fase1-ds-102053')
], Demo4ShowcaseFase1Ds);
export { Demo4ShowcaseFase1Ds };
