var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/clientessaldo.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página C2 do todo/analise-paginas-demonstracao-com-table.md.
//
// Tabela simples de propósito — o interesse está no CONTEÚDO DA CÉLULA. A coluna Localização
// junta bandeira e nome do país, e a de saldo muda de cor conforme o sinal. É a demonstração de
// que a célula aceita markup do consumidor, não só texto.
//
// Bandeira como EMOJI e não imagem: a página do harness é autocontida, sem rede nem arquivo.
//
// Ordenação: a molécula ordena pelo TEXTO da célula. Em Localização isso ordena pelo país, porque
// o emoji vem antes e é igual para o mesmo país. No Saldo, o texto é a moeda formatada — e aí
// `numeric: true` do comparador dá conta dos milhares, mas o sinal negativo vem antes. É um bom
// gancho para falar de ordenação por texto versus por dado com a equipe.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
import { CLIENTES, formatarMoeda } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = ['groupviewtable--ml-data-table'];
let DemoTableClientesSaldo = class DemoTableClientesSaldo extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`demotable--clientessaldo-102053 {
  display: block;
}
demotable--clientessaldo-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--clientessaldo-102053 .head {
  margin-bottom: 2rem;
}
demotable--clientessaldo-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--clientessaldo-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--clientessaldo-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--clientessaldo-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--clientessaldo-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--clientessaldo-102053 .controles {
  display: flex;
  flex-wrap: wrap;
  gap: 1.75rem;
  padding: 0.9rem 1.25rem;
  margin-bottom: 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--clientessaldo-102053 .controle {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
  cursor: pointer;
}
demotable--clientessaldo-102053 .nome {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: 600;
}
demotable--clientessaldo-102053 .email {
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--clientessaldo-102053 .local {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}
demotable--clientessaldo-102053 .bandeira {
  font-size: 1.15rem;
  line-height: 1;
}
demotable--clientessaldo-102053 .saldo {
  font-variant-numeric: tabular-nums;
  font-weight: 600;
  color: var(--ml-primary, #3b82f6);
}
demotable--clientessaldo-102053 .saldo.negativo {
  color: var(--ml-error, #ef4444);
}
demotable--clientessaldo-102053 .saldo.zerado {
  color: var(--ml-on-surface-faint, #79747e);
  font-weight: 400;
}
demotable--clientessaldo-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Financeiro</p>
          <h1 class="title">Saldo por cliente</h1>
          <p class="subtitle">
            Tabela simples, com conteúdo rico na célula: a localização traz bandeira e país, e o
            saldo muda de cor conforme o sinal. Todas as colunas são ordenáveis.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <groupviewtable--ml-data-table>
          <Caption>Clientes ativos e saldo em conta</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="nome" sortable>Name</TableHead>
              <TableHead key="email" sortable>Email</TableHead>
              <TableHead key="local" sortable>Location</TableHead>
              <TableHead key="saldo" sortable>Balance ($)</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${CLIENTES.map((c) => html `
                <TableRow>
                  <TableCell><strong class="nome">${c.nome}</strong></TableCell>
                  <TableCell><span class="email">${c.email}</span></TableCell>
                  <TableCell>
                    <span class="local">
                      <span class="bandeira" aria-hidden="true">${c.bandeira}</span>
                      <span>${c.pais}</span>
                    </span>
                  </TableCell>
                  <TableCell data-class="text-right" sort-value=${c.saldo}>
                    <span class="saldo ${c.saldo < 0 ? 'negativo' : c.saldo === 0 ? 'zerado' : ''}">
                      ${formatarMoeda(c.saldo)}
                    </span>
                  </TableCell>
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-data-table>
      </div>
    `;
    }
};
DemoTableClientesSaldo = __decorate([
    customElement('demotable--clientessaldo-102053')
], DemoTableClientesSaldo);
export { DemoTableClientesSaldo };
