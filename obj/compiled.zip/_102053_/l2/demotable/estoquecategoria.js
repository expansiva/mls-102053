var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/estoquecategoria.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página E2 do todo/analise-paginas-demonstracao-com-table.md.
//
// Demonstra o AGRUPAMENTO, que só existe na ml-grouping-table: o consumidor marca as colunas
// agrupáveis com `groupable` e a própria molécula desenha o seletor "Agrupar por", monta os
// cabeçalhos de grupo e permite recolher cada um.
//
// SEM PAGINAÇÃO: agrupar e paginar não combinam — um grupo ficaria partido entre páginas. A
// molécula, aliás, não fatia (nenhum `slice`), então a decisão aqui é a mesma da vendasmensal:
// conjunto fechado, recorte de 40 itens para a tela caber numa apresentação.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-grouping-table';
import { ESTOQUE, formatarMoeda } from '/_102053_/l2/demotable/dados.js';
const RECORTE = ESTOQUE.slice(0, 40);
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = ['groupviewtable--ml-grouping-table'];
let DemoTableEstoqueCategoria = class DemoTableEstoqueCategoria extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`demotable--estoquecategoria-102053 {
  display: block;
}
demotable--estoquecategoria-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--estoquecategoria-102053 .head {
  margin-bottom: 2rem;
}
demotable--estoquecategoria-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--estoquecategoria-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--estoquecategoria-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--estoquecategoria-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--estoquecategoria-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--estoquecategoria-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Estoque</p>
          <h1 class="title">Posição por categoria e fornecedor</h1>
          <p class="subtitle">
            ${RECORTE.length} itens. Use o seletor <strong>Agrupar por</strong> da própria tabela
            para alternar entre Categoria, Fornecedor e Depósito — e clique no cabeçalho de um
            grupo para recolhê-lo.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <groupviewtable--ml-grouping-table>
          <Caption>Itens em estoque com valor imobilizado</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="codigo" sortable>Código</TableHead>
              <TableHead key="descricao" sortable>Descrição</TableHead>
              <TableHead key="categoria" sortable groupable>Categoria</TableHead>
              <TableHead key="fornecedor" sortable groupable>Fornecedor</TableHead>
              <TableHead key="deposito" groupable>Depósito</TableHead>
              <TableHead key="quantidade" sortable>Quantidade</TableHead>
              <TableHead key="valor" sortable>Valor imobilizado</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${RECORTE.map((item) => html `
                <TableRow>
                  <TableCell>${item.codigo}</TableCell>
                  <TableCell>${item.descricao}</TableCell>
                  <TableCell>${item.categoria}</TableCell>
                  <TableCell>${item.fornecedor}</TableCell>
                  <TableCell>${item.deposito}</TableCell>
                  <TableCell data-class="text-right">${item.quantidade}</TableCell>
                  <TableCell data-class="text-right">
                    ${formatarMoeda(item.quantidade * item.precoUnitario)}
                  </TableCell>
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-grouping-table>
      </div>
    `;
    }
};
DemoTableEstoqueCategoria = __decorate([
    customElement('demotable--estoquecategoria-102053')
], DemoTableEstoqueCategoria);
export { DemoTableEstoqueCategoria };
