var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/funcionariosficha.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página B3b de `todo/ajuste-contrato-view-table/plano-fechamento-groupviewtable-2.md` §4.5,
// adaptada para a `ml-record-form-table`. É o contraste direto da `funcionariosficha2`: mesmo
// dado, mesma ficha de cinco campos, e aqui é a PÁGINA quem é dona do modo de EDIÇÃO.
//
// A abertura da ficha continua sendo da molécula — não existe propriedade externa para forçar
// "ficha aberta" (só o `RowAction action="open"` abre), e por isso o `RowActions` de cada linha
// ainda declara `open` e `delete`. O que muda é a EDIÇÃO dentro da ficha aberta: a página passa
// `editing-rows` com a matrícula que ela decidiu abrir, e os botões "Editar" / "Salvar" / "Cancelar"
// são botões COMUNS desta página dentro do `<Detail>` — não `<RowAction>`. Se fossem `<RowAction
// action="edit">`, a receita MODO×VALOR vira via única: com `editing-rows` presente, o clique nesse
// botão só emitiria `edit` e a ficha nunca entraria em edição de verdade (é o aviso do próprio
// `usage.ts` do grupo — "pick ONE per instance").
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-record-form-table';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import { FUNCIONARIOS } from '/_102053_/l2/demotable/dados.js';
const COMPONENTES = [
    'groupviewtable--ml-record-form-table',
    'groupentertext--ml-enter-text',
    'grouptriggeraction--ml-button-standard',
];
const EQUIPE = FUNCIONARIOS.slice(0, 6);
function editaveisDe(f) {
    return {
        nome: f.nome,
        departamento: f.departamento,
        cargo: f.cargo,
        admissao: f.admissao,
        salario: f.salario.toFixed(2),
    };
}
let DemoTableFuncionariosFicha = class DemoTableFuncionariosFicha extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--funcionariosficha-102053 {
  display: block;
}
demotable--funcionariosficha-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--funcionariosficha-102053 .head {
  margin-bottom: 2rem;
}
demotable--funcionariosficha-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--funcionariosficha-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--funcionariosficha-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--funcionariosficha-102053 .subtitle code,
demotable--funcionariosficha-102053 .nota code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  padding: 0.1rem 0.3rem;
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosficha-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--funcionariosficha-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosficha-102053 .resultado {
  margin-bottom: 1rem;
  padding: 0.75rem 1rem;
  border-left: 4px solid var(--ml-primary, #3b82f6);
  border-radius: 0.25rem;
  background: var(--ml-primary-container, #e8f0fe);
}
demotable--funcionariosficha-102053 .ficha {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  max-width: 28rem;
}
demotable--funcionariosficha-102053 .ficha-situacao {
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.25rem;
}
demotable--funcionariosficha-102053 .ficha-campo {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}
demotable--funcionariosficha-102053 .ficha-campo label {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--ml-on-surface-faint, #79747e);
}
demotable--funcionariosficha-102053 .ficha-acoes {
  display: flex;
  gap: 0.6rem;
  margin-top: 0.25rem;
}
demotable--funcionariosficha-102053 .registro {
  margin-top: 1.75rem;
  padding: 1rem 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface, #ffffff);
}
demotable--funcionariosficha-102053 .registro-titulo {
  font-size: 1rem;
  font-weight: 600;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.35rem;
}
demotable--funcionariosficha-102053 .registro-vazio {
  font-size: 0.875rem;
  color: var(--ml-on-surface-faint, #79747e);
}
demotable--funcionariosficha-102053 .registro-lista {
  margin: 0.75rem 0 0;
  padding-left: 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}
demotable--funcionariosficha-102053 .registro-lista li {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  color: var(--ml-on-surface, #1c1b1f);
  word-break: break-word;
}
demotable--funcionariosficha-102053 .registro-lista li:first-child {
  font-weight: 600;
  color: var(--ml-primary, #3b82f6);
}
demotable--funcionariosficha-102053 .nota {
  margin-top: 0.5rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        this.equipe = EQUIPE;
        this.situacoes = Object.fromEntries(EQUIPE.map((f) => [f.matricula, f.situacao]));
        this.registros = Object.fromEntries(EQUIPE.map((f) => [f.matricula, editaveisDe(f)]));
        /**
         * Fonte de verdade do modo — vai para o markup como `editing-rows`. Vazio = nenhuma ficha em
         * edição (mas pode haver uma aberta em modo leitura).
         */
        this.matriculaEmEdicao = '';
        /** Rascunho isolado até salvar. */
        this.rascunho = { nome: '', departamento: '', cargo: '', admissao: '', salario: '' };
        this.ultimoSalvo = '';
        this.registro = [];
    }
    anotar(evento, detalhe) {
        const linha = `${evento} — ${JSON.stringify(detalhe)}`;
        this.registro = [linha, ...this.registro].slice(0, 14);
    }
    digitar(campo, valor) {
        this.rascunho = { ...this.rascunho, [campo]: valor };
    }
    // ---- decisões de modo, tomadas pela PÁGINA ---------------------------------
    editar(matricula) {
        this.matriculaEmEdicao = matricula;
        this.rascunho = this.registros[matricula];
        this.ultimoSalvo = '';
    }
    cancelar() {
        this.matriculaEmEdicao = '';
    }
    salvar(matricula) {
        this.registros = { ...this.registros, [matricula]: this.rascunho };
        this.ultimoSalvo = this.equipe.find((f) => f.matricula === matricula)?.nome ?? matricula;
        this.matriculaEmEdicao = '';
    }
    // ---- eventos da molécula ---------------------------------------------------
    /** `delete` continua roteado pela molécula — o eixo em teste aqui é só a edição. */
    onDelete(e) {
        this.anotar('delete', e.detail);
    }
    onRowAction(e) {
        this.anotar('rowAction', e.detail);
    }
    onRowClick(e) {
        this.anotar('rowClick', e.detail);
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Pessoas</p>
          <h1 class="title">Ficha de funcionário — a página é dona do modo</h1>
          <p class="subtitle">
            Abrir a ficha continua sendo ação da tabela (<code>RowAction action="open"</code>): não
            há como forçar isso de fora. Mas <strong>quem decide qual ficha está em edição é esta
            página</strong>, por <code>editing-rows</code> — os botões Editar/Salvar/Cancelar, dentro
            da ficha, são botões comuns desta tela, não <code>&lt;RowAction&gt;</code>.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        ${this.ultimoSalvo
            ? html `<p class="resultado">Ficha atualizada — ${this.ultimoSalvo}</p>`
            : html ``}

        <groupviewtable--ml-record-form-table
          editing-rows=${this.matriculaEmEdicao}
          @delete=${this.onDelete}
          @rowAction=${this.onRowAction}
          @rowClick=${this.onRowClick}
        >
          <Caption>Equipe — cadastro completo</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="matricula" sortable>Matrícula</TableHead>
              <TableHead key="nome" sortable>Nome</TableHead>
              <TableHead key="departamento" sortable>Departamento</TableHead>
              <TableHead key="cargo" sortable>Cargo</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${this.equipe.map((f) => this.renderLinha(f.matricula))}
          </TableBody>
        </groupviewtable--ml-record-form-table>

        <section class="registro">
          <h2 class="registro-titulo">Eventos emitidos pela tabela</h2>
          <p class="nota">
            Sem <code>@edit</code>/<code>@save</code>/<code>@cancel</code> aqui: quem move o modo de
            edição é esta página, diretamente — a molécula só reflete <code>editing-rows</code>.
          </p>
          ${this.registro.length === 0
            ? html `<p class="registro-vazio">Nenhum evento ainda.</p>`
            : html `<ol class="registro-lista">
                ${this.registro.map((linha) => html `<li>${linha}</li>`)}
              </ol>`}
        </section>
      </div>
    `;
    }
    renderLinha(matricula) {
        const valores = this.registros[matricula];
        return html `
      <TableRow key=${matricula}>
        <TableCell>${matricula}</TableCell>
        <TableCell>${valores.nome}</TableCell>
        <TableCell>${valores.departamento}</TableCell>
        <TableCell>${valores.cargo}</TableCell>

        <Detail label=${`Ficha de ${valores.nome}`}>${this.renderFicha(matricula)}</Detail>

        <RowActions>
          <RowAction action="open">
            <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs">
              <Label>Abrir</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="delete">
            <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
              <Label>Excluir</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
        </RowActions>
      </TableRow>
    `;
    }
    /**
     * O conteúdo da ficha. Os campos recebem `is-editing` da MOLÉCULA (via `editing-rows`), como em
     * qualquer outro modo — o que muda é só quem decide a matrícula que entra nesse estado: aqui, os
     * botões Editar/Salvar/Cancelar são desta página, comuns, fora do vocabulário de `RowAction`.
     */
    renderFicha(matricula) {
        const persistido = this.registros[matricula];
        const editando = this.matriculaEmEdicao === matricula;
        const valor = (campo) => (editando ? this.rascunho[campo] : persistido[campo]);
        return html `
      <div class="ficha">
        <p class="ficha-situacao">Situação: <strong>${this.situacoes[matricula]}</strong></p>
        <div class="ficha-campo">
          <label>Nome</label>
          <groupentertext--ml-enter-text
            .value=${valor('nome')}
            @change=${(e) => this.digitar('nome', e.target.value)}
            @input=${(e) => this.digitar('nome', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Departamento</label>
          <groupentertext--ml-enter-text
            .value=${valor('departamento')}
            @change=${(e) => this.digitar('departamento', e.target.value)}
            @input=${(e) => this.digitar('departamento', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Cargo</label>
          <groupentertext--ml-enter-text
            .value=${valor('cargo')}
            @change=${(e) => this.digitar('cargo', e.target.value)}
            @input=${(e) => this.digitar('cargo', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Admissão</label>
          <groupentertext--ml-enter-text
            .value=${valor('admissao')}
            @change=${(e) => this.digitar('admissao', e.target.value)}
            @input=${(e) => this.digitar('admissao', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Salário</label>
          <groupentertext--ml-enter-text
            .value=${valor('salario')}
            @change=${(e) => this.digitar('salario', e.target.value)}
            @input=${(e) => this.digitar('salario', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>

        <div class="ficha-acoes">
          ${editando
            ? html `
                <grouptriggeraction--ml-button-standard
                  data-variant="primary"
                  size="xs"
                  @action=${() => this.salvar(matricula)}
                >
                  <Label>Salvar</Label>
                </grouptriggeraction--ml-button-standard>
                <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs" @action=${this.cancelar}>
                  <Label>Cancelar</Label>
                </grouptriggeraction--ml-button-standard>
              `
            : html `
                <grouptriggeraction--ml-button-standard
                  data-variant="secondary"
                  size="xs"
                  @action=${() => this.editar(matricula)}
                >
                  <Label>Editar</Label>
                </grouptriggeraction--ml-button-standard>
              `}
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], DemoTableFuncionariosFicha.prototype, "registros", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha.prototype, "matriculaEmEdicao", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha.prototype, "rascunho", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha.prototype, "ultimoSalvo", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha.prototype, "registro", void 0);
DemoTableFuncionariosFicha = __decorate([
    customElement('demotable--funcionariosficha-102053')
], DemoTableFuncionariosFicha);
export { DemoTableFuncionariosFicha };
