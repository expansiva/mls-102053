var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/vendasmensal.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página E1 do todo/analise-paginas-demonstracao-com-table.md — prova de conceito do
// GroupViewTable para a equipe de desenvolvimento.
//
// Demonstra, numa tela só, os seis recursos pedidos: listagem, ordenação, somatória por linha,
// somatória por coluna, reordenação de colunas (arrastando o cabeçalho) e — por ausência — a
// razão de NÃO paginar aqui.
//
// SEM PAGINAÇÃO, de propósito: a molécula calcula o total de coluna sobre as linhas que recebeu
// (ml-advanced-data-table.ts, `renderColumnTotalFooter`), então numa tela paginada o rodapé
// mostraria o total da PÁGINA. Num relatório isso é número errado. Relatório mensal é conjunto
// fechado; a paginação se demonstra nas páginas de listagem, onde ela é natural.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-advanced-data-table';
import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
import { CANAIS, MES_REFERENCIA, VENDAS_DO_MES, formatarMoeda } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-advanced-data-table',
    'groupenterboolean--ml-toggle-switch',
];
let DemoTableVendasMensal = class DemoTableVendasMensal extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--vendasmensal-102053 {
  display: block;
}
demotable--vendasmensal-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--vendasmensal-102053 .head {
  margin-bottom: 2rem;
}
demotable--vendasmensal-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--vendasmensal-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--vendasmensal-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--vendasmensal-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--vendasmensal-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--vendasmensal-102053 .controles {
  display: flex;
  flex-wrap: wrap;
  gap: 1.75rem;
  padding: 0.9rem 1.25rem;
  margin-bottom: 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--vendasmensal-102053 .controle {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
  cursor: pointer;
}
demotable--vendasmensal-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        this.totalPorLinha = true;
        this.totalPorColuna = true;
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Relatório</p>
          <h1 class="title">Vendas por canal — ${MES_REFERENCIA}</h1>
          <p class="subtitle">
            ${VENDAS_DO_MES.length} produtos · ${CANAIS.length} canais · valores em reais.
            Clique num cabeçalho para ordenar; arraste um cabeçalho para reordenar a coluna.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <section class="controles">
          <label class="controle">
            <groupenterboolean--ml-toggle-switch
              .value=${this.totalPorLinha}
              @change=${(e) => (this.totalPorLinha = !!e.detail?.value)}
            ></groupenterboolean--ml-toggle-switch>
            <span>Total por linha</span>
          </label>
          <label class="controle">
            <groupenterboolean--ml-toggle-switch
              .value=${this.totalPorColuna}
              @change=${(e) => (this.totalPorColuna = !!e.detail?.value)}
            ></groupenterboolean--ml-toggle-switch>
            <span>Total por coluna</span>
          </label>
        </section>

        <groupviewtable--ml-advanced-data-table
          ?show-row-total=${this.totalPorLinha}
          ?show-column-total=${this.totalPorColuna}
        >
          <Caption>Faturamento por produto e canal de venda</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="produto" sortable>Produto</TableHead>
              <TableHead key="categoria" sortable>Categoria</TableHead>
              ${CANAIS.map((canal) => html `<TableHead key=${canal.toLowerCase()} sortable>${canal}</TableHead>`)}
            </TableRow>
          </TableHeader>

          <TableBody>
            ${VENDAS_DO_MES.map((linha) => html `
                <TableRow>
                  <TableCell>${linha.produto}</TableCell>
                  <TableCell>${linha.categoria}</TableCell>
                  ${CANAIS.map((canal) => html `
                      <TableCell data-class="text-right">
                        ${formatarMoeda(linha.porCanal[canal])}
                      </TableCell>
                    `)}
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-advanced-data-table>

        <p class="nota">
          A coluna <strong>Total da linha</strong> e a linha de totais no rodapé são calculadas pela
          própria molécula, a partir do texto das células — inclusive com a máscara de moeda.
        </p>
      </div>
    `;
    }
};
__decorate([
    state()
], DemoTableVendasMensal.prototype, "totalPorLinha", void 0);
__decorate([
    state()
], DemoTableVendasMensal.prototype, "totalPorColuna", void 0);
DemoTableVendasMensal = __decorate([
    customElement('demotable--vendasmensal-102053')
], DemoTableVendasMensal);
export { DemoTableVendasMensal };
