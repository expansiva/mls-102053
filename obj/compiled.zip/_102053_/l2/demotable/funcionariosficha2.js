var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/funcionariosficha2.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página B3a de `todo/ajuste-contrato-view-table/plano-fechamento-groupviewtable-2.md` §4.3,
// adaptada para a `ml-record-form-table` — a molécula nova cujo "editar" não acontece na própria
// linha (como a `ml-inline-edit-table` de `funcionariosedicao2`), e sim numa FICHA que substitui a
// lista inteira. É o par funcional de `funcionariosficha` (B3b): mesmo dado, mesma tabela, e aqui é
// a MOLÉCULA quem é dona do modo — de abertura da ficha e de edição dentro dela.
//
// Nenhum `editing-rows` no markup: quem decide qual linha abriu e se está editando é a própria
// `ml-record-form-table`, a partir dos `RowAction` que cada linha declara (`open`, `delete`,
// `edit`, `save`, `cancel`). A página só guarda o VALOR — é isso que faz "cancelar não altera nada"
// funcionar: o rascunho vive aqui, e no `cancel` é descartado sem nunca ter sido gravado.
//
// A ficha tem cinco campos (nome, departamento, cargo, admissão, salário) — mais do que cabe numa
// linha de tabela, de propósito: é o motivo de essa molécula existir (`prompt` original: "manutenção
// de registros com muitos campos"). `situação` fica só de leitura, para não sobrecarregar o teste
// com um editor de opções.
//
// O registro de eventos é o instrumento do teste. Vale conferir, em particular: `open` também emite
// `rowAction` (com `action: "open"`), além de abrir a ficha — não é um bug, é o contrato descrevendo
// duas coisas ao mesmo tempo.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-record-form-table';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import { FUNCIONARIOS } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-record-form-table',
    'groupentertext--ml-enter-text',
    'grouptriggeraction--ml-button-standard',
];
const EQUIPE = FUNCIONARIOS.slice(0, 6);
function editaveisDe(f) {
    return {
        nome: f.nome,
        departamento: f.departamento,
        cargo: f.cargo,
        admissao: f.admissao,
        salario: f.salario.toFixed(2),
    };
}
const VAZIO = { nome: '', departamento: '', cargo: '', admissao: '', salario: '' };
const NOVO_VAZIO = { matricula: '', nome: '', departamento: '', cargo: '' };
let DemoTableFuncionariosFicha2 = class DemoTableFuncionariosFicha2 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--funcionariosficha2-102053 {
  display: block;
}
demotable--funcionariosficha2-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--funcionariosficha2-102053 .head {
  margin-bottom: 2rem;
}
demotable--funcionariosficha2-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--funcionariosficha2-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--funcionariosficha2-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--funcionariosficha2-102053 .subtitle code,
demotable--funcionariosficha2-102053 .nota code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  padding: 0.1rem 0.3rem;
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosficha2-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--funcionariosficha2-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosficha2-102053 .barra {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.75rem;
  padding: 0.85rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--funcionariosficha2-102053 .ficha {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  max-width: 28rem;
}
demotable--funcionariosficha2-102053 .ficha-situacao {
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.25rem;
}
demotable--funcionariosficha2-102053 .ficha-campo {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}
demotable--funcionariosficha2-102053 .ficha-campo label {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--ml-on-surface-faint, #79747e);
}
demotable--funcionariosficha2-102053 .registro {
  margin-top: 1.75rem;
  padding: 1rem 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface, #ffffff);
}
demotable--funcionariosficha2-102053 .registro-titulo {
  font-size: 1rem;
  font-weight: 600;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.35rem;
}
demotable--funcionariosficha2-102053 .registro-vazio {
  font-size: 0.875rem;
  color: var(--ml-on-surface-faint, #79747e);
}
demotable--funcionariosficha2-102053 .registro-lista {
  margin: 0.75rem 0 0;
  padding-left: 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}
demotable--funcionariosficha2-102053 .registro-lista li {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  color: var(--ml-on-surface, #1c1b1f);
  word-break: break-word;
}
demotable--funcionariosficha2-102053 .registro-lista li:first-child {
  font-weight: 600;
  color: var(--ml-primary, #3b82f6);
}
demotable--funcionariosficha2-102053 .nota {
  margin-top: 0.5rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        /** Matrículas vivas na tabela. `delete` remove daqui. */
        this.matriculas = EQUIPE.map((f) => f.matricula);
        /** Situação de cada um, só para exibição — não faz parte da ficha editável. */
        this.situacoes = Object.fromEntries(EQUIPE.map((f) => [f.matricula, f.situacao]));
        /** Os cinco campos, por matrícula. O valor é da PÁGINA; a molécula não guarda valor. */
        this.registros = Object.fromEntries(EQUIPE.map((f) => [f.matricula, editaveisDe(f)]));
        /**
         * Espelho de qual ficha a MOLÉCULA abriu para edição, mantido só pelos eventos `edit`/`save`/
         * `cancel`. Não vai para o markup como `editing-rows` — existe só para esta página saber se
         * mostra o valor persistido ou o rascunho.
         */
        this.matriculaEmEdicao = '';
        /** Rascunho em digitação, isolado até salvar — permite cancelar sem alterar nada. */
        this.rascunho = VAZIO;
        this.novo = NOVO_VAZIO;
        this.criados = 0;
        this.carregando = false;
        this.registro = [];
    }
    anotar(evento, detalhe) {
        const linha = `${evento} — ${JSON.stringify(detalhe)}`;
        this.registro = [linha, ...this.registro].slice(0, 14);
    }
    digitar(campo, valor) {
        this.rascunho = { ...this.rascunho, [campo]: valor };
    }
    digitarNovo(campo, valor) {
        this.novo = { ...this.novo, [campo]: valor };
    }
    // ---- eventos da molécula ---------------------------------------------------
    onEdit(e) {
        const { key } = e.detail;
        this.anotar('edit', e.detail);
        this.matriculaEmEdicao = key;
        this.rascunho = this.registros[key] ?? VAZIO;
    }
    onSave(e) {
        const detalhe = e.detail;
        this.anotar('save', detalhe);
        if (detalhe.isNew) {
            this.criados += 1;
            const matricula = this.novo.matricula.trim() || `NOVO-${this.criados}`;
            this.registros = {
                ...this.registros,
                [matricula]: { ...VAZIO, nome: this.novo.nome, departamento: this.novo.departamento, cargo: this.novo.cargo },
            };
            this.matriculas = [...this.matriculas, matricula];
            this.novo = NOVO_VAZIO;
            return;
        }
        this.registros = { ...this.registros, [detalhe.key]: this.rascunho };
        this.matriculaEmEdicao = '';
        this.rascunho = VAZIO;
    }
    onCancel(e) {
        const detalhe = e.detail;
        this.anotar('cancel', detalhe);
        if (detalhe.isNew) {
            this.novo = NOVO_VAZIO;
            return;
        }
        this.matriculaEmEdicao = '';
        this.rascunho = VAZIO;
    }
    onDelete(e) {
        const { key } = e.detail;
        this.anotar('delete', e.detail);
        this.matriculas = this.matriculas.filter((m) => m !== key);
    }
    /** `open` cai aqui TAMBÉM — a molécula emite `rowAction` com `action: "open"` além de abrir a ficha. */
    onRowAction(e) {
        this.anotar('rowAction', e.detail);
    }
    onNewRecord(e) {
        this.anotar('newRecord', e.detail);
        this.novo = NOVO_VAZIO;
    }
    onRowClick(e) {
        this.anotar('rowClick', e.detail);
    }
    // ---- controles da página --------------------------------------------------
    restaurar() {
        this.matriculas = EQUIPE.map((f) => f.matricula);
        this.registros = Object.fromEntries(EQUIPE.map((f) => [f.matricula, editaveisDe(f)]));
        this.matriculaEmEdicao = '';
        this.rascunho = VAZIO;
        this.novo = NOVO_VAZIO;
        this.criados = 0;
        this.registro = [];
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Pessoas</p>
          <h1 class="title">Ficha de funcionário — a molécula é dona do modo</h1>
          <p class="subtitle">
            Clique em <strong>Abrir</strong> numa linha: a ficha substitui a lista inteira no mesmo
            espaço, com cinco campos (nome, departamento, cargo, admissão e salário) — mais do que
            cabe na tabela. <strong>Editar</strong> torna os campos editáveis; <strong>Salvar</strong>
            e <strong>Cancelar</strong> fecham a edição; o controle de voltar para a lista é da
            própria molécula. Não existe <code>editing-rows</code> no markup: quem decide o que está
            aberto e o que está em edição é a <code>ml-record-form-table</code>.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <div class="barra">
          <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs" @action=${this.restaurar}>
            <Label>Restaurar dados</Label>
          </grouptriggeraction--ml-button-standard>
          <grouptriggeraction--ml-button-standard
            data-variant="ghost"
            size="xs"
            @action=${() => (this.carregando = !this.carregando)}
          >
            <Label>${this.carregando ? 'Parar carregamento' : 'Simular carregamento'}</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <groupviewtable--ml-record-form-table
          .loading=${this.carregando}
          @edit=${this.onEdit}
          @save=${this.onSave}
          @cancel=${this.onCancel}
          @delete=${this.onDelete}
          @rowAction=${this.onRowAction}
          @newRecord=${this.onNewRecord}
          @rowClick=${this.onRowClick}
        >
          <Caption>Equipe — cadastro completo</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="matricula" sortable>Matrícula</TableHead>
              <TableHead key="nome" sortable>Nome</TableHead>
              <TableHead key="departamento" sortable>Departamento</TableHead>
              <TableHead key="cargo" sortable>Cargo</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${this.matriculas.map((matricula) => this.renderLinha(matricula))}
          </TableBody>

          <NewRecordRow key="novo">
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.matricula}
                @change=${(e) => this.digitarNovo('matricula', e.target.value)}
                @input=${(e) => this.digitarNovo('matricula', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.nome}
                @change=${(e) => this.digitarNovo('nome', e.target.value)}
                @input=${(e) => this.digitarNovo('nome', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.departamento}
                @change=${(e) => this.digitarNovo('departamento', e.target.value)}
                @input=${(e) => this.digitarNovo('departamento', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.cargo}
                @change=${(e) => this.digitarNovo('cargo', e.target.value)}
                @input=${(e) => this.digitarNovo('cargo', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>

            <RowActions>
              <RowAction action="save">
                <grouptriggeraction--ml-button-standard data-variant="primary" size="xs">
                  <Label>Salvar</Label>
                </grouptriggeraction--ml-button-standard>
              </RowAction>
              <RowAction action="cancel">
                <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
                  <Label>Cancelar</Label>
                </grouptriggeraction--ml-button-standard>
              </RowAction>
            </RowActions>
          </NewRecordRow>

          <TableFooter>
            <RowAction action="new">
              <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs">
                <Label>Novo funcionário</Label>
              </grouptriggeraction--ml-button-standard>
            </RowAction>
          </TableFooter>

          <Empty>Nenhum funcionário na lista. Use "Restaurar dados".</Empty>
          <Loading>Buscando funcionários...</Loading>
        </groupviewtable--ml-record-form-table>

        <section class="registro">
          <h2 class="registro-titulo">Eventos emitidos pela tabela</h2>
          <p class="nota">
            <code>delete</code> não deve fechar a ficha nem mudar o modo. Ao abrir (<code>open</code>),
            repare que <code>rowAction</code> também dispara, com <code>action: "open"</code>.
          </p>
          ${this.registro.length === 0
            ? html `<p class="registro-vazio">Nenhum evento ainda.</p>`
            : html `<ol class="registro-lista">
                ${this.registro.map((linha) => html `<li>${linha}</li>`)}
              </ol>`}
        </section>
      </div>
    `;
    }
    renderLinha(matricula) {
        const valores = this.registros[matricula];
        if (!valores)
            return html ``;
        return html `
      <TableRow key=${matricula}>
        <TableCell>${matricula}</TableCell>
        <TableCell>${valores.nome}</TableCell>
        <TableCell>${valores.departamento}</TableCell>
        <TableCell>${valores.cargo}</TableCell>

        <Detail label=${`Ficha de ${valores.nome}`}>${this.renderFicha(matricula)}</Detail>

        <RowActions>
          <RowAction action="open">
            <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs">
              <Label>Abrir</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="delete">
            <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
              <Label>Excluir</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="edit">
            <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs">
              <Label>Editar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="save">
            <grouptriggeraction--ml-button-standard data-variant="primary" size="xs">
              <Label>Salvar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="cancel">
            <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
              <Label>Cancelar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
        </RowActions>
      </TableRow>
    `;
    }
    /**
     * O conteúdo da ficha — cinco campos vivos. Quem alterna entre leitura e edição é a MOLÉCULA,
     * carimbando `is-editing` em cada um; esta página só escolhe se o valor exibido é o persistido
     * ou o rascunho, exatamente como faria numa célula comum.
     */
    renderFicha(matricula) {
        const persistido = this.registros[matricula];
        const editando = this.matriculaEmEdicao === matricula;
        const valor = (campo) => (editando ? this.rascunho[campo] : persistido[campo]);
        return html `
      <div class="ficha">
        <p class="ficha-situacao">Situação: <strong>${this.situacoes[matricula]}</strong></p>
        <div class="ficha-campo">
          <label>Nome</label>
          <groupentertext--ml-enter-text
            .value=${valor('nome')}
            @change=${(e) => this.digitar('nome', e.target.value)}
            @input=${(e) => this.digitar('nome', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Departamento</label>
          <groupentertext--ml-enter-text
            .value=${valor('departamento')}
            @change=${(e) => this.digitar('departamento', e.target.value)}
            @input=${(e) => this.digitar('departamento', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Cargo</label>
          <groupentertext--ml-enter-text
            .value=${valor('cargo')}
            @change=${(e) => this.digitar('cargo', e.target.value)}
            @input=${(e) => this.digitar('cargo', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Admissão</label>
          <groupentertext--ml-enter-text
            .value=${valor('admissao')}
            @change=${(e) => this.digitar('admissao', e.target.value)}
            @input=${(e) => this.digitar('admissao', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
        <div class="ficha-campo">
          <label>Salário</label>
          <groupentertext--ml-enter-text
            .value=${valor('salario')}
            @change=${(e) => this.digitar('salario', e.target.value)}
            @input=${(e) => this.digitar('salario', e.target.value)}
          ></groupentertext--ml-enter-text>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "matriculas", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "registros", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "matriculaEmEdicao", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "rascunho", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "novo", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "criados", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "carregando", void 0);
__decorate([
    state()
], DemoTableFuncionariosFicha2.prototype, "registro", void 0);
DemoTableFuncionariosFicha2 = __decorate([
    customElement('demotable--funcionariosficha2-102053')
], DemoTableFuncionariosFicha2);
export { DemoTableFuncionariosFicha2 };
