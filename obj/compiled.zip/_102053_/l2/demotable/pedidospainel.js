var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/pedidospainel.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página B2 de `todo/ajuste-contrato-view-table/plano-fechamento-groupviewtable-2.md` §4.6,
// adaptada para a `ml-side-detail-table` — é literalmente o cenário dela: tabela ordenável e
// paginada, com o detalhe do registro ao lado ao clicar na linha.
//
// Modo EXTERNO, de propósito: `pedidosdetalhe` (a página de referência da `ml-lazy-record-detail-
// table`) já cobre o modo INTERNO, e `consultarPagina()` — pensado desde `dados.ts` para o modo
// externo — nunca tinha sido exercitado por nenhuma página. Aqui a PÁGINA ordena e pagina (10 por
// página); a tabela recebe só a página atual e `total-items` com o total real, e só reage a `sort`
// e `pageChange`.
//
// Os itens do checklist do B2:
//   1. `sort-value` nas células de valor (número) e data (ordinal) — o texto formatado não ordena
//      como o dado (R$ e dd/mm/aaaa);
//   2. um modo só, coerente: aqui é EXTERNO — todas as linhas da página, e `total-items` com o total
//      real, nunca as duas coisas ao mesmo tempo;
//   3. `<Detail>` como filho direto do `<TableRow>` — aqui vem cheio desde o início: a molécula não
//      precisa de carregamento sob demanda, ela só decide qual detalhe já presente mostrar;
//   4. `fit-height` no host, dentro de um contêiner com altura definida;
//   5. nenhum `data-class` de cor, fundo, sombra ou peso de fonte em slot tag — só alinhamento
//      (`text-right`), que é layout e continua permitido.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-side-detail-table';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
import { PEDIDOS_PAINEL, formatarMoeda, consultarPagina, itensDoPedido, totalDoPedido, } from '/_102053_/l2/demotable/dados.js';
const COMPONENTES = ['groupviewtable--ml-side-detail-table', 'groupviewtable--ml-data-table'];
const TAMANHO_PAGINA = 10;
const MAPA_ORDEM = { numero: 'id', cliente: 'cliente', valor: 'total', data: 'dataOrdinal' };
const LINHAS = PEDIDOS_PAINEL.map((pedido) => ({ ...pedido, total: totalDoPedido(pedido) }));
let DemoTablePedidosPainel = class DemoTablePedidosPainel extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--pedidospainel-102053 {
  display: block;
}
demotable--pedidospainel-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--pedidospainel-102053 .head {
  margin-bottom: 2rem;
}
demotable--pedidospainel-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--pedidospainel-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--pedidospainel-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--pedidospainel-102053 .subtitle code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  padding: 0.1rem 0.3rem;
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--pedidospainel-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--pedidospainel-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--pedidospainel-102053 .quadro {
  height: 32rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  overflow: hidden;
}
demotable--pedidospainel-102053 .quadro groupviewtable--ml-side-detail-table {
  height: 100%;
}
demotable--pedidospainel-102053 .detalhe-titulo {
  font-size: 0.9375rem;
  font-weight: 600;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.15rem;
}
demotable--pedidospainel-102053 .detalhe-cliente {
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.9rem;
}
`);
        this.pagina = 1;
        this.ordem = '';
        this.direcao = 'asc';
    }
    /** A PÁGINA ordena e fatia — modo externo. A tabela só recebe a fatia e o total. */
    paginaAtual() {
        return consultarPagina(LINHAS, {
            pagina: this.pagina,
            tamanho: TAMANHO_PAGINA,
            ordem: this.ordem || undefined,
            direcao: this.direcao,
        });
    }
    onSort(e) {
        const { key, direction } = e.detail;
        const campo = MAPA_ORDEM[key];
        if (!campo)
            return;
        this.ordem = campo;
        this.direcao = direction;
        this.pagina = 1;
    }
    onPageChange(e) {
        this.pagina = e.detail.page;
    }
    render() {
        const { linhas, total } = this.paginaAtual();
        const paginas = Math.max(1, Math.ceil(total / TAMANHO_PAGINA));
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Comercial</p>
          <h1 class="title">Pedidos com painel de detalhe</h1>
          <p class="subtitle">
            Ordenável por número, cliente e valor — clique num cabeçalho. ${TAMANHO_PAGINA} por
            página, em modo <strong>EXTERNO</strong>: esta página ordena e fatia
            (<code>consultarPagina</code>), a tabela só recebe a página atual e
            <code>total-items</code> com o total real. Clique numa linha para ver os itens do pedido
            no painel ao lado — o conteúdo já está pronto desde o início, sem carregamento.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <div class="quadro">
          <groupviewtable--ml-side-detail-table
            fit-height
            page=${this.pagina}
            page-size=${TAMANHO_PAGINA}
            total-items=${total}
            @sort=${this.onSort}
            @pageChange=${this.onPageChange}
          >
            <Caption>Pedidos — página ${this.pagina} de ${paginas}</Caption>

            <TableHeader>
              <TableRow>
                <TableHead key="numero" sortable>Número</TableHead>
                <TableHead key="cliente" sortable>Cliente</TableHead>
                <TableHead key="valor" sortable>Valor</TableHead>
                <TableHead key="data" sortable>Data</TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              ${linhas.map((linha) => this.renderLinha(linha))}
            </TableBody>
          </groupviewtable--ml-side-detail-table>
        </div>
      </div>
    `;
    }
    renderLinha(linha) {
        return html `
      <TableRow key=${linha.id}>
        <TableCell>${linha.id}</TableCell>
        <TableCell>${linha.cliente}</TableCell>
        <TableCell data-class="text-right" sort-value=${linha.total}>${formatarMoeda(linha.total)}</TableCell>
        <TableCell data-class="text-right" sort-value=${linha.dataOrdinal}>${linha.data}</TableCell>

        <Detail label=${`Pedido ${linha.id}`}>${this.renderDetalhe(linha)}</Detail>
      </TableRow>
    `;
    }
    renderDetalhe(linha) {
        return html `
      <div class="detalhe">
        <p class="detalhe-titulo">Itens do pedido ${linha.id}</p>
        <p class="detalhe-cliente">${linha.cliente} · ${itensDoPedido(linha)} itens · ${linha.data}</p>
        <groupviewtable--ml-data-table>
          <TableHeader>
            <TableRow>
              <TableHead key="produto" sortable>Produto</TableHead>
              <TableHead key="preco" sortable>Preço</TableHead>
              <TableHead key="qtd" sortable>Qtd.</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            ${linha.itens.map((item) => html `
                <TableRow>
                  <TableCell>${item.produto}</TableCell>
                  <TableCell data-class="text-right" sort-value=${item.preco}>${formatarMoeda(item.preco)}</TableCell>
                  <TableCell data-class="text-right" sort-value=${item.quantidade}>${item.quantidade}</TableCell>
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-data-table>
      </div>
    `;
    }
};
__decorate([
    state()
], DemoTablePedidosPainel.prototype, "pagina", void 0);
__decorate([
    state()
], DemoTablePedidosPainel.prototype, "ordem", void 0);
__decorate([
    state()
], DemoTablePedidosPainel.prototype, "direcao", void 0);
DemoTablePedidosPainel = __decorate([
    customElement('demotable--pedidospainel-102053')
], DemoTablePedidosPainel);
export { DemoTablePedidosPainel };
