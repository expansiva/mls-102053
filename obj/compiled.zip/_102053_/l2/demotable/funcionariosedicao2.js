var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/funcionariosedicao2.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página de aceite da Fase 3 do `todo/todo-ajustes-crud-ml-inline-edit-table.md`.
//
// É o contraste direto da `funcionariosedicao`: mesmo dado, mesma tabela, e a coluna de ações
// invertida de lado.
//
//   funcionariosedicao   — a PÁGINA é dona do modo. Passa `editing-rows`, escreve a própria coluna
//                          "Ação" num `<TableCell>` e condiciona os botões num ternário.
//   funcionariosedicao2  — a MOLÉCULA é dona do modo. Nenhum `editing-rows` no markup, nenhum
//                          ternário: os botões vão num `<RowActions>` e cada `<RowAction>` declara
//                          o que é. Quem decide o que aparece em cada modo é a tabela.
//
// A página continua dona do VALOR, e é isso que faz "cancelar sem modificar nada" funcionar: o
// `rascunho` é daqui, e no `cancel` ele é descartado sem nunca ter sido gravado em `registros`.
//
// `linhaEmEdicao` aqui é ESPELHO, não fonte: quem sabe qual linha está aberta é a molécula, e esta
// página descobre pelos eventos `edit` / `save` / `cancel`. É de propósito — se o espelho acompanha
// só com os eventos, a superfície de eventos está completa.
//
// O registro de eventos na tela é o instrumento do teste: mostra o que a molécula emitiu, com o
// detail e na ordem. É onde se vê que `delete` NÃO fecha a linha e que clicar numa ação NÃO emite
// `rowClick`.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-inline-edit-table';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import { FUNCIONARIOS } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-inline-edit-table',
    'groupentertext--ml-enter-text',
    'grouptriggeraction--ml-button-standard',
];
const EQUIPE = FUNCIONARIOS.slice(0, 6);
function editaveisDe(f) {
    return { nome: f.nome, departamento: f.departamento, cargo: f.cargo };
}
const VAZIO = { nome: '', departamento: '', cargo: '' };
const NOVO_VAZIO = { matricula: '', nome: '', departamento: '', cargo: '' };
let DemoTableFuncionariosEdicao2 = class DemoTableFuncionariosEdicao2 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--funcionariosedicao2-102053 {
  display: block;
}
demotable--funcionariosedicao2-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--funcionariosedicao2-102053 .head {
  margin-bottom: 2rem;
}
demotable--funcionariosedicao2-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--funcionariosedicao2-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--funcionariosedicao2-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--funcionariosedicao2-102053 .subtitle code,
demotable--funcionariosedicao2-102053 .nota code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  padding: 0.1rem 0.3rem;
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosedicao2-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--funcionariosedicao2-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosedicao2-102053 .barra {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.75rem;
  padding: 0.85rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--funcionariosedicao2-102053 .registro {
  margin-top: 1.75rem;
  padding: 1rem 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface, #ffffff);
}
demotable--funcionariosedicao2-102053 .registro-titulo {
  font-size: 1rem;
  font-weight: 600;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.35rem;
}
demotable--funcionariosedicao2-102053 .registro-vazio {
  font-size: 0.875rem;
  color: var(--ml-on-surface-faint, #79747e);
}
demotable--funcionariosedicao2-102053 .registro-lista {
  margin: 0.75rem 0 0;
  padding-left: 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}
demotable--funcionariosedicao2-102053 .registro-lista li {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  color: var(--ml-on-surface, #1c1b1f);
  word-break: break-word;
}
demotable--funcionariosedicao2-102053 .registro-lista li:first-child {
  font-weight: 600;
  color: var(--ml-primary, #3b82f6);
}
demotable--funcionariosedicao2-102053 .nota {
  margin-top: 0.5rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        /** Matrículas vivas na tabela. `delete` remove daqui — é a página que tira a linha do corpo. */
        this.matriculas = EQUIPE.map((f) => f.matricula);
        /** Nome, departamento e cargo por matrícula. O valor é da PÁGINA; a tabela não guarda valor. */
        this.registros = Object.fromEntries(EQUIPE.map((f) => [f.matricula, editaveisDe(f)]));
        /**
         * Espelho de qual linha a MOLÉCULA abriu, mantido só pelos eventos dela.
         *
         * Não vai para o markup como `editing-rows` — se fosse, a página voltaria a ser dona do modo e o
         * recurso em teste deixaria de ser exercitado.
         */
        this.linhaEmEdicao = '';
        /**
         * Valores em digitação, isolados até salvar. É o que permite cancelar sem alterar nada: os três
         * campos voltam juntos, porque nenhum deles foi gravado em `registros`.
         */
        this.rascunho = VAZIO;
        /**
         * Campos da linha RASCUNHO. Quem abre e fecha a linha é a molécula; estes valores são da página,
         * como todos os outros — no `cancel` são descartados, no `save` viram um registro.
         */
        this.novo = NOVO_VAZIO;
        this.criados = 0;
        this.carregando = false;
        this.registro = [];
    }
    anotar(evento, detalhe) {
        const linha = `${evento} — ${JSON.stringify(detalhe)}`;
        this.registro = [linha, ...this.registro].slice(0, 14);
    }
    /** Um campo do rascunho de edição, sem repetir o spread em cada `@input` do template. */
    digitar(campo, valor) {
        this.rascunho = { ...this.rascunho, [campo]: valor };
    }
    /** Um campo da linha rascunho de criação. */
    digitarNovo(campo, valor) {
        this.novo = { ...this.novo, [campo]: valor };
    }
    // ---- eventos da molécula ---------------------------------------------------
    onEdit(e) {
        const { key } = e.detail;
        this.anotar('edit', e.detail);
        this.linhaEmEdicao = key;
        this.rascunho = this.registros[key] ?? VAZIO;
    }
    onSave(e) {
        const detalhe = e.detail;
        this.anotar('save', detalhe);
        // `isNew` é o que separa gravar um registro existente de CRIAR um. A tabela abriu e fechou a
        // linha; escrever o `<TableRow>` novo no corpo é trabalho da página.
        if (detalhe.isNew) {
            this.criados += 1;
            const matricula = this.novo.matricula.trim() || `NOVO-${this.criados}`;
            this.registros = {
                ...this.registros,
                [matricula]: { nome: this.novo.nome, departamento: this.novo.departamento, cargo: this.novo.cargo },
            };
            this.matriculas = [...this.matriculas, matricula];
            this.novo = NOVO_VAZIO;
            return;
        }
        this.registros = { ...this.registros, [detalhe.key]: this.rascunho };
        this.linhaEmEdicao = '';
        this.rascunho = VAZIO;
    }
    onCancel(e) {
        const detalhe = e.detail;
        this.anotar('cancel', detalhe);
        // Reverter é só descartar o rascunho: `registros` nunca foi tocado, nos dois casos.
        if (detalhe.isNew) {
            this.novo = NOVO_VAZIO;
            return;
        }
        this.linhaEmEdicao = '';
        this.rascunho = VAZIO;
    }
    onDelete(e) {
        const { key } = e.detail;
        this.anotar('delete', e.detail);
        this.matriculas = this.matriculas.filter((m) => m !== key);
    }
    onRowAction(e) {
        this.anotar('rowAction', e.detail);
    }
    /** A tabela avisou que abriu a linha rascunho. Zerar os campos é trabalho da página. */
    onNewRecord(e) {
        this.anotar('newRecord', e.detail);
        this.novo = NOVO_VAZIO;
    }
    /** Não deve aparecer no registro quando o clique for numa ação. É o teste da guarda. */
    onRowClick(e) {
        this.anotar('rowClick', e.detail);
    }
    // ---- controles da página --------------------------------------------------
    restaurar() {
        this.matriculas = EQUIPE.map((f) => f.matricula);
        this.registros = Object.fromEntries(EQUIPE.map((f) => [f.matricula, editaveisDe(f)]));
        this.linhaEmEdicao = '';
        this.rascunho = VAZIO;
        this.novo = NOVO_VAZIO;
        this.criados = 0;
        this.registro = [];
    }
    esvaziar() {
        this.matriculas = [];
        this.linhaEmEdicao = '';
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Pessoas</p>
          <h1 class="title">Revisão de cargos — ações pela tabela</h1>
          <p class="subtitle">
            Aqui a <strong>tabela</strong> é dona do modo de edição. Não existe
            <code>editing-rows</code> no markup e não existe ternário de visibilidade: os botões
            ficam num <code>&lt;RowActions&gt;</code>, cada <code>&lt;RowAction&gt;</code> declara o
            que é, e a coluna <strong>Ações</strong> é criada pela própria tabela — o cabeçalho
            abaixo só declara quatro colunas. <strong>Nome</strong>, <strong>Departamento</strong> e
            <strong>Cargo</strong> abrem para edição juntos, e em modo leitura devem aparecer como
            texto, sem borda de campo. O botão <strong>Novo registro</strong>, no rodapé, abre uma
            linha rascunho no fim do corpo — ela não é ordenada nem paginada, e é uma por vez.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <div class="barra">
          <grouptriggeraction--ml-button-standard
            data-variant="secondary"
            size="xs"
            @action=${this.restaurar}
          >
            <Label>Restaurar dados</Label>
          </grouptriggeraction--ml-button-standard>
          <grouptriggeraction--ml-button-standard
            data-variant="ghost"
            size="xs"
            @action=${this.esvaziar}
          >
            <Label>Esvaziar lista</Label>
          </grouptriggeraction--ml-button-standard>
          <grouptriggeraction--ml-button-standard
            data-variant="ghost"
            size="xs"
            @action=${() => (this.carregando = !this.carregando)}
          >
            <Label>${this.carregando ? 'Parar carregamento' : 'Simular carregamento'}</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <groupviewtable--ml-inline-edit-table
          .loading=${this.carregando}
          @edit=${this.onEdit}
          @save=${this.onSave}
          @cancel=${this.onCancel}
          @delete=${this.onDelete}
          @rowAction=${this.onRowAction}
          @newRecord=${this.onNewRecord}
          @rowClick=${this.onRowClick}
        >
          <Caption>Cargos por pessoa</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="matricula" sortable>Matrícula</TableHead>
              <TableHead key="nome" sortable>Nome</TableHead>
              <TableHead key="departamento" sortable>Departamento</TableHead>
              <TableHead key="cargo" sortable>Cargo</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${this.matriculas.map((matricula) => this.renderLinha(matricula))}
          </TableBody>

          <!-- A linha RASCUNHO. Escrita UMA vez, não por linha: a tabela projeta estas células
               num <tr> extra quando o rascunho abre. Um por vez, por construção. -->
          <NewRecordRow key="novo">
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.matricula}
                @change=${(e) => this.digitarNovo('matricula', e.target.value)}
                @input=${(e) => this.digitarNovo('matricula', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.nome}
                @change=${(e) => this.digitarNovo('nome', e.target.value)}
                @input=${(e) => this.digitarNovo('nome', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.departamento}
                @change=${(e) => this.digitarNovo('departamento', e.target.value)}
                @input=${(e) => this.digitarNovo('departamento', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>
            <TableCell>
              <groupentertext--ml-enter-text
                .value=${this.novo.cargo}
                @change=${(e) => this.digitarNovo('cargo', e.target.value)}
                @input=${(e) => this.digitarNovo('cargo', e.target.value)}
              ></groupentertext--ml-enter-text>
            </TableCell>

            <!-- Mesmo vocabulario da linha. A inferencia do when nao muda: a linha rascunho esta
                 sempre em edicao, entao save e cancel aparecem e editar/excluir nao. Sem backtick
                 aqui dentro: o comentario vive num template literal, e o backtick o encerraria. -->
            <RowActions>
              <RowAction action="save">
                <grouptriggeraction--ml-button-standard data-variant="primary" size="xs">
                  <Label>Salvar</Label>
                </grouptriggeraction--ml-button-standard>
              </RowAction>
              <RowAction action="cancel">
                <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
                  <Label>Cancelar</Label>
                </grouptriggeraction--ml-button-standard>
              </RowAction>
            </RowActions>
          </NewRecordRow>

          <!-- O gatilho e filho DIRETO do rodape e usa o mesmo RowAction: nenhum slot novo. -->
          <TableFooter>
            <RowAction action="new">
              <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs">
                <Label>Novo registro</Label>
              </grouptriggeraction--ml-button-standard>
            </RowAction>
          </TableFooter>

          <Empty>Nenhum funcionário na lista. Use "Restaurar dados".</Empty>
          <Loading>Buscando funcionários...</Loading>
        </groupviewtable--ml-inline-edit-table>

        <section class="registro">
          <h2 class="registro-titulo">Eventos emitidos pela tabela</h2>
          <p class="nota">
            <code>delete</code> deve emitir <strong>sem</strong> fechar a linha aberta.
            <code>rowClick</code> <strong>não</strong> deve aparecer quando o clique for num botão de
            ação — só quando for na linha, fora dos controles.
          </p>
          ${this.registro.length === 0
            ? html `<p class="registro-vazio">Nenhum evento ainda.</p>`
            : html `<ol class="registro-lista">
                ${this.registro.map((linha) => html `<li>${linha}</li>`)}
              </ol>`}
        </section>
      </div>
    `;
    }
    renderLinha(matricula) {
        const valores = this.registros[matricula];
        if (!valores)
            return html ``;
        const editando = this.linhaEmEdicao === matricula;
        return html `
      <TableRow key=${matricula}>
        <TableCell>${matricula}</TableCell>
        ${this.renderCampo(matricula, 'nome', editando)}
        ${this.renderCampo(matricula, 'departamento', editando)}
        ${this.renderCampo(matricula, 'cargo', editando)}

        <RowActions>
          <RowAction action="edit">
            <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs">
              <Label>Editar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="delete">
            <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
              <Label>Excluir</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="save">
            <grouptriggeraction--ml-button-standard data-variant="primary" size="xs">
              <Label>Salvar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="cancel">
            <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
              <Label>Cancelar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="detalhes" when="always">
            <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
              <Label>Detalhes</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
        </RowActions>
      </TableRow>
    `;
    }
    /**
     * Uma célula editável.
     *
     * Quem alterna entre leitura e edição é a MOLÉCULA, carimbando `is-editing` no componente. Esta
     * página não passa esse atributo em lugar nenhum — só escolhe se o valor exibido é o persistido
     * ou o rascunho.
     */
    renderCampo(matricula, campo, editando) {
        const valor = editando ? this.rascunho[campo] : this.registros[matricula][campo];
        return html `
      <TableCell>
        <groupentertext--ml-enter-text
          .value=${valor}
          @change=${(e) => this.digitar(campo, e.target.value)}
          @input=${(e) => this.digitar(campo, e.target.value)}
        ></groupentertext--ml-enter-text>
      </TableCell>
    `;
    }
};
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "matriculas", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "registros", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "linhaEmEdicao", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "rascunho", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "novo", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "criados", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "carregando", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao2.prototype, "registro", void 0);
DemoTableFuncionariosEdicao2 = __decorate([
    customElement('demotable--funcionariosedicao2-102053')
], DemoTableFuncionariosEdicao2);
export { DemoTableFuncionariosEdicao2 };
