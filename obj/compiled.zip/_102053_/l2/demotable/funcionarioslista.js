var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/funcionarioslista.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página F1 do todo/analise-paginas-demonstracao-com-table.md.
//
// É a página que mostra o ganho dos SLOTS VIVOS: o botão "Ver" dentro de cada célula é uma
// molécula de verdade (ml-button-standard) com o handler DESTA página. Antes da migração ele
// seria HTML morto — pintava e não respondia. Aqui ele abre o painel de detalhe.
//
// Usa o modo INTERNO do contrato (skills/groupViewTable/creation.ts §9): as 60 linhas vão no
// markup e a molécula ordena tudo e fatia de 10 em 10. Esse modo só passou a funcionar nesta
// molécula em 2026-08-04 — antes ela desenhava a paginação e mostrava as 60 linhas.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-responsive-data-table';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import { FUNCIONARIOS, formatarMoeda } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-responsive-data-table',
    'grouptriggeraction--ml-button-standard',
];
let DemoTableFuncionariosLista = class DemoTableFuncionariosLista extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--funcionarioslista-102053 {
  display: block;
}
demotable--funcionarioslista-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--funcionarioslista-102053 .head {
  margin-bottom: 2rem;
}
demotable--funcionarioslista-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--funcionarioslista-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--funcionarioslista-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--funcionarioslista-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--funcionarioslista-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionarioslista-102053 .conteudo {
  display: flex;
  align-items: flex-start;
  gap: 1.5rem;
}
demotable--funcionarioslista-102053 .lista {
  flex: 1 1 auto;
  min-width: 0;
}
demotable--funcionarioslista-102053 .detalhe {
  flex: 0 0 22rem;
  position: sticky;
  top: 1.5rem;
  padding: 1.25rem 1.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-left: 4px solid var(--ml-primary, #3b82f6);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--funcionarioslista-102053 .detalhe-topo {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
}
demotable--funcionarioslista-102053 .detalhe-titulo {
  font-size: 1.125rem;
  font-weight: 600;
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionarioslista-102053 .fechar {
  border: none;
  background: none;
  font-size: 1.5rem;
  line-height: 1;
  cursor: pointer;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--funcionarioslista-102053 .campos {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(11rem, 1fr));
  gap: 0.9rem 1.5rem;
}
demotable--funcionarioslista-102053 .campos dt {
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.15rem;
}
demotable--funcionarioslista-102053 .campos dd {
  margin: 0;
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionarioslista-102053 .voltar {
  display: none;
  border: none;
  background: none;
  padding: 0 0 0.75rem;
  font-size: 0.875rem;
  cursor: pointer;
  color: var(--ml-primary, #3b82f6);
}
@media (max-width: 900px) {
  demotable--funcionarioslista-102053 .conteudo {
    display: block;
  }
  demotable--funcionarioslista-102053 .detalhe {
    flex: none;
    position: static;
    width: 100%;
    margin-bottom: 0;
  }
  demotable--funcionarioslista-102053 .com-detalhe .lista {
    display: none;
  }
  demotable--funcionarioslista-102053 .voltar {
    display: block;
  }
  demotable--funcionarioslista-102053 .fechar {
    display: none;
  }
}
`);
        /** Quem o usuário abriu pelo botão da linha. É a prova de que o handler chegou. */
        this.selecionado = null;
    }
    abrir(matricula) {
        this.selecionado = FUNCIONARIOS.find((f) => f.matricula === matricula) ?? null;
    }
    fechar() {
        this.selecionado = null;
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Pessoas</p>
          <h1 class="title">Quadro de funcionários</h1>
          <p class="subtitle">
            ${FUNCIONARIOS.length} pessoas, 10 por página. Ordene por qualquer coluna e navegue
            entre as páginas — a tabela cuida das duas coisas. O botão <strong>Ver</strong> de cada
            linha é um componente com o comportamento desta página.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <div class="conteudo ${this.selecionado ? 'com-detalhe' : ''}">
          <div class="lista">
            ${this.renderTabela()}
          </div>
          ${this.renderDetalhe()}
        </div>
      </div>
    `;
    }
    /**
     * Duas colunas no amplo: lista à esquerda, detalhe à direita. No estreito o cenário TROCA — o
     * detalhe ocupa a tela e a lista some, com um botão para voltar. Quem decide é a classe
     * "com-detalhe" no contêiner; o resto é CSS, sem media query em JS.
     *
     * Efeito colateral bem-vindo: com o painel aberto, a tabela fica num contêiner mais estreito e
     * a própria molécula esconde as colunas que não cabem — ela mede a largura disponível.
     */
    renderTabela() {
        return html `
      <groupviewtable--ml-responsive-data-table page-size="10">
          <Caption>Quadro ativo, ordenável por qualquer coluna</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="matricula" sortable>Matrícula</TableHead>
              <TableHead key="nome" sortable>Nome</TableHead>
              <TableHead key="departamento" sortable>Departamento</TableHead>
              <TableHead key="cargo" sortable>Cargo</TableHead>
              <TableHead key="situacao" sortable>Situação</TableHead>
              <TableHead key="acao">Ação</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${FUNCIONARIOS.map((f) => html `
                <TableRow>
                  <TableCell>${f.matricula}</TableCell>
                  <TableCell>${f.nome}</TableCell>
                  <TableCell>${f.departamento}</TableCell>
                  <TableCell>${f.cargo}</TableCell>
                  <TableCell>${f.situacao}</TableCell>
                  <TableCell>
                    <grouptriggeraction--ml-button-standard
                      data-variant="secondary"
                      size="xs"
                      @action=${() => this.abrir(f.matricula)}
                    >
                      <Label>Ver</Label>
                    </grouptriggeraction--ml-button-standard>
                  </TableCell>
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-responsive-data-table>
    `;
    }
    renderDetalhe() {
        if (!this.selecionado)
            return html ``;
        const f = this.selecionado;
        return html `
      <section class="detalhe">
        <button class="voltar" @click=${this.fechar}>← voltar para a lista</button>
        <div class="detalhe-topo">
          <h2 class="detalhe-titulo">${f.nome}</h2>
          <button class="fechar" @click=${this.fechar} aria-label="Fechar detalhe">×</button>
        </div>
        <dl class="campos">
          <div><dt>Matrícula</dt><dd>${f.matricula}</dd></div>
          <div><dt>Departamento</dt><dd>${f.departamento}</dd></div>
          <div><dt>Cargo</dt><dd>${f.cargo}</dd></div>
          <div><dt>Admissão</dt><dd>${f.admissao}</dd></div>
          <div><dt>Salário</dt><dd>${formatarMoeda(f.salario)}</dd></div>
          <div><dt>Situação</dt><dd>${f.situacao}</dd></div>
        </dl>
      </section>
    `;
    }
};
__decorate([
    state()
], DemoTableFuncionariosLista.prototype, "selecionado", void 0);
DemoTableFuncionariosLista = __decorate([
    customElement('demotable--funcionarioslista-102053')
], DemoTableFuncionariosLista);
export { DemoTableFuncionariosLista };
