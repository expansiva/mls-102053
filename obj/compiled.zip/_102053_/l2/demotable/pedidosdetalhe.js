var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/pedidosdetalhe.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página C4 do todo/analise-paginas-demonstracao-com-table.md.
//
// Demonstra a ml-lazy-record-detail-table: tabela com linha de detalhe sob demanda, um misto de
// tabela com accordion. Ao expandir, a molécula emite `rowClick` com o índice; a página busca os
// itens do pedido e escreve dentro do `<Detail>` daquela linha.
//
// O carregamento é SIMULADO com um atraso curto, de propósito: é assim que se comporta com um BFF
// de verdade, e mostra o estado "carregando…" que a tela precisa ter.
//
// Duas coisas dependem de o slot ser VIVO, e as duas aparecem aqui: o detalhe é OUTRA TABELA
// (uma molécula dentro de um slot), e ela chega depois, num segundo momento — conteúdo serializado
// entregaria markup morto e perderia o binding.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-lazy-record-detail-table';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
import { PEDIDOS, formatarMoeda, itensDoPedido, totalDoPedido, } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-lazy-record-detail-table',
    'groupviewtable--ml-data-table',
];
let DemoTablePedidosDetalhe = class DemoTablePedidosDetalhe extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--pedidosdetalhe-102053 {
  display: block;
}
demotable--pedidosdetalhe-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--pedidosdetalhe-102053 .head {
  margin-bottom: 2rem;
}
demotable--pedidosdetalhe-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--pedidosdetalhe-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--pedidosdetalhe-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--pedidosdetalhe-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--pedidosdetalhe-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--pedidosdetalhe-102053 .controles {
  display: flex;
  flex-wrap: wrap;
  gap: 1.75rem;
  padding: 0.9rem 1.25rem;
  margin-bottom: 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--pedidosdetalhe-102053 .controle {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
  cursor: pointer;
}
demotable--pedidosdetalhe-102053 .pessoa {
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  min-width: 0;
}
demotable--pedidosdetalhe-102053 .avatar {
  flex: none;
  width: 2.25rem;
  height: 2.25rem;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 0.8125rem;
  font-weight: 700;
  letter-spacing: 0.02em;
}
demotable--pedidosdetalhe-102053 .pessoa-texto {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
demotable--pedidosdetalhe-102053 .pessoa-nome {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: 600;
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
demotable--pedidosdetalhe-102053 .pessoa-email {
  color: var(--ml-on-surface-muted, #49454f);
  font-size: 0.8125rem;
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
demotable--pedidosdetalhe-102053 .status {
  display: inline-block;
  padding: 0.15rem 0.6rem;
  border-radius: 999px;
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.01em;
  background: var(--ml-surface-variant, #f0f0f0);
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--pedidosdetalhe-102053 .status.delivered {
  background: #dcfce7;
  color: #166534;
}
demotable--pedidosdetalhe-102053 .status.shipped {
  background: #dbeafe;
  color: #1e40af;
}
demotable--pedidosdetalhe-102053 .status.processing {
  background: #fef3c7;
  color: #92400e;
}
demotable--pedidosdetalhe-102053 .status.pending {
  background: #f1f5f9;
  color: #475569;
}
demotable--pedidosdetalhe-102053 .status.cancelled {
  background: #fee2e2;
  color: #991b1b;
}
demotable--pedidosdetalhe-102053 .carregando {
  margin-left: 2.5rem;
  padding: 0.75rem 1.1rem;
  border-left: 2px solid var(--ml-outline-variant, #e2e8f0);
  background: var(--ml-surface-dim, #f5f5f5);
  font-size: 0.8125rem;
  font-style: italic;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--pedidosdetalhe-102053 .detalhe {
  margin-left: 2.5rem;
  max-width: 56rem;
  padding: 0.9rem 1.1rem 1rem;
  border-left: 2px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0 0.375rem 0.375rem 0;
  background: var(--ml-surface-dim, #f5f5f5);
  --ml-outline-variant: #e9edf3;
  --ml-surface-dim: #fafbfc;
}
demotable--pedidosdetalhe-102053 .detalhe-titulo {
  font-size: 0.6875rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--ml-on-surface-faint, #79747e);
  margin-bottom: 0.5rem;
}
demotable--pedidosdetalhe-102053 .detalhe groupviewtable--ml-data-table th,
demotable--pedidosdetalhe-102053 .detalhe groupviewtable--ml-data-table td {
  font-size: 0.75rem;
  padding-top: 0.4rem;
  padding-bottom: 0.4rem;
}
demotable--pedidosdetalhe-102053 .detalhe groupviewtable--ml-data-table caption {
  display: none;
}
demotable--pedidosdetalhe-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        /** Índices cujo detalhe já foi carregado. */
        this.carregados = new Set();
        /** Índices em carregamento — é o que pinta o "carregando…". */
        this.carregando = new Set();
    }
    /**
     * A molécula avisa que a linha abriu; a página busca o detalhe. Aqui a busca é simulada, mas o
     * formato é o de uma chamada real: pede, espera, e só então tem o conteúdo.
     */
    onRowClick(e) {
        const indice = Number(e.detail?.index);
        if (Number.isNaN(indice) || this.carregados.has(indice) || this.carregando.has(indice))
            return;
        this.carregando = new Set([...this.carregando, indice]);
        window.setTimeout(() => {
            const emCurso = new Set(this.carregando);
            emCurso.delete(indice);
            this.carregando = emCurso;
            this.carregados = new Set([...this.carregados, indice]);
        }, 600);
    }
    renderStatus(status) {
        const classe = status.toLowerCase();
        return html `<span class="status ${classe}">${status}</span>`;
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Comercial</p>
          <h1 class="title">Pedidos por cliente</h1>
          <p class="subtitle">
            Clique na seta de uma linha para ver os itens do pedido. O conteúdo é buscado só nesse
            momento — a tabela avisa que a linha abriu e a página carrega o detalhe.
          </p>
          <p class="subtitle">
            São 8 pedidos com 5 por página, no modo INTERNAL: a página escreve TODAS as linhas e não
            informa <code>total-items</code>, então quem pagina é a molécula. O teste que interessa é
            abrir um detalhe na página 1, ir para a página 2 e voltar — o conteúdo tem de continuar lá.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <groupviewtable--ml-lazy-record-detail-table page-size="5" @rowClick=${this.onRowClick}>
          <Caption>Pedidos recentes</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="cliente" sortable>Customer</TableHead>
              <TableHead key="itens" sortable>Items</TableHead>
              <TableHead key="total" sortable>Total</TableHead>
              <TableHead key="status" sortable>Status</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${PEDIDOS.map((pedido, indice) => this.renderLinha(pedido, indice))}
          </TableBody>
        </groupviewtable--ml-lazy-record-detail-table>
      </div>
    `;
    }
    renderLinha(pedido, indice) {
        return html `
      <TableRow>
        <TableCell>
          <span class="pessoa">
            <span class="avatar" style="background:${pedido.cor}" aria-hidden="true">
              ${pedido.iniciais}
            </span>
            <span class="pessoa-texto">
              <strong class="pessoa-nome">${pedido.cliente}</strong>
              <span class="pessoa-email">${pedido.email}</span>
            </span>
          </span>
        </TableCell>
        <TableCell data-class="text-center" sort-value=${itensDoPedido(pedido)}>${itensDoPedido(pedido)}</TableCell>
        <TableCell data-class="text-right" sort-value=${totalDoPedido(pedido)}>
          ${formatarMoeda(totalDoPedido(pedido))}
        </TableCell>
        <TableCell>${this.renderStatus(pedido.status)}</TableCell>

        <Detail>${this.renderDetalhe(pedido, indice)}</Detail>
      </TableRow>
    `;
    }
    renderDetalhe(pedido, indice) {
        if (this.carregando.has(indice)) {
            return html `<p class="carregando">Carregando itens do pedido ${pedido.id}…</p>`;
        }
        if (!this.carregados.has(indice))
            return html ``;
        return html `
      <div class="detalhe">
        <p class="detalhe-titulo">Itens do pedido ${pedido.id}</p>
        <groupviewtable--ml-data-table>
          <TableHeader>
            <TableRow>
              <TableHead data-class="text-left" key="produto" sortable>Product</TableHead>
              <TableHead data-class="text-left" key="categoria" sortable>Category</TableHead>
              <TableHead data-class="text-right" key="preco" sortable>Price</TableHead>
              <TableHead data-class="text-right" key="qtd" sortable>Qty</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            ${pedido.itens.map((item) => html `
                <TableRow>
                  <TableCell>${item.produto}</TableCell>
                  <TableCell>${item.categoria}</TableCell>
                  <TableCell data-class="text-right" sort-value=${item.preco}>${formatarMoeda(item.preco)}</TableCell>
                  <TableCell data-class="text-right" sort-value=${item.quantidade}>${item.quantidade}</TableCell>
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-data-table>
      </div>
    `;
    }
};
__decorate([
    state()
], DemoTablePedidosDetalhe.prototype, "carregados", void 0);
__decorate([
    state()
], DemoTablePedidosDetalhe.prototype, "carregando", void 0);
DemoTablePedidosDetalhe = __decorate([
    customElement('demotable--pedidosdetalhe-102053')
], DemoTablePedidosDetalhe);
export { DemoTablePedidosDetalhe };
