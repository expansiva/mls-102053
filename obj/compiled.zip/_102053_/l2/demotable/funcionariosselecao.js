var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/funcionariosselecao.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página F2 do todo/analise-paginas-demonstracao-com-table.md.
//
// Demonstra a seleção em lote da ml-data-table-select: `select-mode="multi"` liga a coluna de
// caixas de seleção, e a molécula emite `change` com as posições marcadas.
//
// Detalhe do contrato que vale mostrar para a equipe: a seleção vem por ÍNDICE, não por chave.
// Índice é posição, não identidade — por isso esta página trabalha com conjunto fechado e sem
// ordenação. Numa tela que ordena ou pagina, a posição muda e o consumidor precisa reconciliar.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table-select';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import { FUNCIONARIOS, formatarMoeda } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-data-table-select',
    'grouptriggeraction--ml-button-standard',
];
const EQUIPE = FUNCIONARIOS.slice(0, 12);
let DemoTableFuncionariosSelecao = class DemoTableFuncionariosSelecao extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--funcionariosselecao-102053 {
  display: block;
}
demotable--funcionariosselecao-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--funcionariosselecao-102053 .head {
  margin-bottom: 2rem;
}
demotable--funcionariosselecao-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--funcionariosselecao-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--funcionariosselecao-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--funcionariosselecao-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--funcionariosselecao-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosselecao-102053 .barra {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.85rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--funcionariosselecao-102053 .contagem {
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosselecao-102053 .resultado {
  margin-bottom: 1rem;
  padding: 0.75rem 1rem;
  border-left: 4px solid var(--ml-primary, #3b82f6);
  border-radius: 0.25rem;
  background: var(--ml-primary-container, #e8f0fe);
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosselecao-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        /** Índices marcados, como a molécula os entrega. */
        this.selecionados = [];
        this.ultimaAcao = '';
    }
    onChange(e) {
        const valor = String(e.detail?.value ?? '');
        this.selecionados = valor
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => !Number.isNaN(n));
    }
    enviarComunicado() {
        const nomes = this.selecionados.map((i) => EQUIPE[i]?.nome).filter(Boolean);
        this.ultimaAcao = `Comunicado enviado para ${nomes.length} pessoa(s): ${nomes.join(', ')}`;
    }
    render() {
        const quantos = this.selecionados.length;
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Pessoas</p>
          <h1 class="title">Comunicado à equipe</h1>
          <p class="subtitle">
            Marque as pessoas que devem receber o comunicado. A barra de ações acompanha a
            seleção — ela só habilita quando há alguém marcado.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <div class="barra">
          <span class="contagem">
            ${quantos === 0
            ? 'Nenhuma pessoa selecionada'
            : `${quantos} de ${EQUIPE.length} selecionada(s)`}
          </span>
          <grouptriggeraction--ml-button-standard
            data-variant="primary"
            size="sm"
            ?disabled=${quantos === 0}
            @action=${this.enviarComunicado}
          >
            <Label>Enviar comunicado</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        ${this.ultimaAcao ? html `<p class="resultado">${this.ultimaAcao}</p>` : html ``}

        <groupviewtable--ml-data-table-select
          selectable
          select-mode="multi"
          @change=${this.onChange}
        >
          <Caption>Equipe elegível para o comunicado</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="matricula">Matrícula</TableHead>
              <TableHead key="nome">Nome</TableHead>
              <TableHead key="departamento">Departamento</TableHead>
              <TableHead key="cargo">Cargo</TableHead>
              <TableHead key="salario">Salário</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${EQUIPE.map((f) => html `
                <TableRow>
                  <TableCell>${f.matricula}</TableCell>
                  <TableCell>${f.nome}</TableCell>
                  <TableCell>${f.departamento}</TableCell>
                  <TableCell>${f.cargo}</TableCell>
                  <TableCell data-class="text-right">${formatarMoeda(f.salario)}</TableCell>
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-data-table-select>
      </div>
    `;
    }
};
__decorate([
    state()
], DemoTableFuncionariosSelecao.prototype, "selecionados", void 0);
__decorate([
    state()
], DemoTableFuncionariosSelecao.prototype, "ultimaAcao", void 0);
DemoTableFuncionariosSelecao = __decorate([
    customElement('demotable--funcionariosselecao-102053')
], DemoTableFuncionariosSelecao);
export { DemoTableFuncionariosSelecao };
