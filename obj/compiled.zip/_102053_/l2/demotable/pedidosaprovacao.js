var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/pedidosaprovacao.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página N2 de `todo/ajuste-contrato-view-table/plano-fechamento-groupviewtable-2.md` §4.4 —
// "verbo fora do vocabulário", a rota genérica de `rowAction`.
//
// O prompt original usa uma tabela de pedidos com "aprovar" e "duplicar", mas o alvo certo NÃO é a
// `ml-side-detail-table`: ela declara `RowActions`/`RowAction` na lista de slots por herança do
// boilerplate do grupo, mas não lê nenhum — não emite `rowAction`, não tem vocabulário de ação
// nenhum. Só a `ml-record-form-table` implementa isso de verdade. É o alvo desta página.
//
// `aprovar` e `duplicar` não pertencem ao vocabulário do grupo (`edit`/`delete`/`save`/`cancel`/
// `new`), então a molécula deve rotear os dois pelo evento genérico `rowAction`, com o verbo
// LITERAL em `detail.action` — nunca reaproveitando `edit` ou inventando um slot novo.
//
// O registro de eventos é o instrumento do teste: TODOS os eventos de ciclo de vida
// (`edit`/`save`/`cancel`/`delete`/`newRecord`) estão ligados ao mesmo log que `rowAction` — se
// algum deles aparecer ao clicar em "Aprovar" ou "Duplicar", a rota genérica não pegou.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-record-form-table';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import { PEDIDOS, formatarMoeda, totalDoPedido } from '/_102053_/l2/demotable/dados.js';
const COMPONENTES = ['groupviewtable--ml-record-form-table', 'grouptriggeraction--ml-button-standard'];
const BASE = PEDIDOS.slice(0, 6).map((pedido) => ({ chave: pedido.id, pedido }));
let DemoTablePedidosAprovacao = class DemoTablePedidosAprovacao extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--pedidosaprovacao-102053 {
  display: block;
}
demotable--pedidosaprovacao-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--pedidosaprovacao-102053 .head {
  margin-bottom: 2rem;
}
demotable--pedidosaprovacao-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--pedidosaprovacao-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--pedidosaprovacao-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--pedidosaprovacao-102053 .subtitle code,
demotable--pedidosaprovacao-102053 .nota code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  padding: 0.1rem 0.3rem;
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--pedidosaprovacao-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--pedidosaprovacao-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--pedidosaprovacao-102053 .barra {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.75rem;
  padding: 0.85rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--pedidosaprovacao-102053 .status {
  display: inline-block;
  padding: 0.15rem 0.6rem;
  border-radius: 999px;
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.01em;
  background: var(--ml-surface-variant, #f0f0f0);
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--pedidosaprovacao-102053 .status.aprovado {
  background: #dcfce7;
  color: #166534;
}
demotable--pedidosaprovacao-102053 .status.pendente {
  background: #fef3c7;
  color: #92400e;
}
demotable--pedidosaprovacao-102053 .registro {
  margin-top: 1.75rem;
  padding: 1rem 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface, #ffffff);
}
demotable--pedidosaprovacao-102053 .registro-titulo {
  font-size: 1rem;
  font-weight: 600;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.35rem;
}
demotable--pedidosaprovacao-102053 .registro-vazio {
  font-size: 0.875rem;
  color: var(--ml-on-surface-faint, #79747e);
}
demotable--pedidosaprovacao-102053 .registro-lista {
  margin: 0.75rem 0 0;
  padding-left: 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}
demotable--pedidosaprovacao-102053 .registro-lista li {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.8125rem;
  color: var(--ml-on-surface, #1c1b1f);
  word-break: break-word;
}
demotable--pedidosaprovacao-102053 .registro-lista li:first-child {
  font-weight: 600;
  color: var(--ml-primary, #3b82f6);
}
demotable--pedidosaprovacao-102053 .nota {
  margin-top: 0.5rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        this.linhas = BASE;
        this.aprovados = new Set();
        this.duplicacoes = 0;
        this.registro = [];
    }
    anotar(evento, detalhe) {
        const linha = `${evento} — ${JSON.stringify(detalhe)}`;
        this.registro = [linha, ...this.registro].slice(0, 14);
    }
    /** Única rota de verbo: tudo que não é do vocabulário do grupo cai aqui, com o nome literal. */
    onRowAction(e) {
        const { key, action } = e.detail;
        this.anotar('rowAction', { key, action });
        if (action === 'aprovar') {
            this.aprovados = new Set([...this.aprovados, key]);
            return;
        }
        if (action === 'duplicar') {
            const original = this.linhas.find((l) => l.chave === key);
            if (!original)
                return;
            this.duplicacoes += 1;
            const chave = `${original.pedido.id}-DUP${this.duplicacoes}`;
            this.linhas = [...this.linhas, { chave, pedido: { ...original.pedido, id: chave } }];
        }
    }
    // Ligados ao MESMO log — se um destes aparecer para um clique em "Aprovar"/"Duplicar", a rota
    // genérica não pegou e o verbo foi lido como parte do vocabulário fixo do grupo.
    onEdit(e) { this.anotar('edit (inesperado)', e.detail); }
    onSave(e) { this.anotar('save (inesperado)', e.detail); }
    onCancel(e) { this.anotar('cancel (inesperado)', e.detail); }
    onDelete(e) { this.anotar('delete (inesperado)', e.detail); }
    onNewRecord(e) { this.anotar('newRecord (inesperado)', e.detail); }
    restaurar() {
        this.linhas = BASE;
        this.aprovados = new Set();
        this.duplicacoes = 0;
        this.registro = [];
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Comercial</p>
          <h1 class="title">Pedidos — ações fora do vocabulário</h1>
          <p class="subtitle">
            Cada linha tem <strong>Aprovar</strong> e <strong>Duplicar</strong> — nenhum dos dois é
            <code>edit</code>/<code>delete</code>/<code>save</code>/<code>cancel</code>/<code>new</code>.
            A tabela deve emitir <code>rowAction</code> com o verbo literal em
            <code>detail.action</code>, sem inventar um slot novo nem reaproveitar um verbo do
            vocabulário fixo.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <div class="barra">
          <grouptriggeraction--ml-button-standard data-variant="secondary" size="xs" @action=${this.restaurar}>
            <Label>Restaurar dados</Label>
          </grouptriggeraction--ml-button-standard>
        </div>

        <groupviewtable--ml-record-form-table
          @rowAction=${this.onRowAction}
          @edit=${this.onEdit}
          @save=${this.onSave}
          @cancel=${this.onCancel}
          @delete=${this.onDelete}
          @newRecord=${this.onNewRecord}
        >
          <Caption>Pedidos pendentes de aprovação</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="id" sortable>Pedido</TableHead>
              <TableHead key="cliente" sortable>Cliente</TableHead>
              <TableHead key="total" sortable>Total</TableHead>
              <TableHead key="status">Status</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${this.linhas.map((linha) => this.renderLinha(linha))}
          </TableBody>

          <Empty>Nenhum pedido pendente.</Empty>
        </groupviewtable--ml-record-form-table>

        <section class="registro">
          <h2 class="registro-titulo">Eventos emitidos pela tabela</h2>
          <p class="nota">
            Só <code>rowAction</code> deve aparecer para estes cliques. Qualquer linha marcada
            "(inesperado)" é regressão: o verbo caiu no vocabulário fixo em vez da rota genérica.
          </p>
          ${this.registro.length === 0
            ? html `<p class="registro-vazio">Nenhum evento ainda.</p>`
            : html `<ol class="registro-lista">
                ${this.registro.map((linha) => html `<li>${linha}</li>`)}
              </ol>`}
        </section>
      </div>
    `;
    }
    renderLinha(linha) {
        const { pedido } = linha;
        const aprovado = this.aprovados.has(linha.chave);
        const total = totalDoPedido(pedido);
        return html `
      <TableRow key=${linha.chave}>
        <TableCell>${pedido.id}</TableCell>
        <TableCell>${pedido.cliente}</TableCell>
        <TableCell data-class="text-right" sort-value=${total}>${formatarMoeda(total)}</TableCell>
        <TableCell>
          ${aprovado ? html `<span class="status aprovado">Aprovado</span>` : html `<span class="status pendente">${pedido.status}</span>`}
        </TableCell>

        <RowActions>
          <RowAction action="aprovar">
            <grouptriggeraction--ml-button-standard data-variant="primary" size="xs">
              <Label>Aprovar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
          <RowAction action="duplicar">
            <grouptriggeraction--ml-button-standard data-variant="ghost" size="xs">
              <Label>Duplicar</Label>
            </grouptriggeraction--ml-button-standard>
          </RowAction>
        </RowActions>
      </TableRow>
    `;
    }
};
__decorate([
    state()
], DemoTablePedidosAprovacao.prototype, "linhas", void 0);
__decorate([
    state()
], DemoTablePedidosAprovacao.prototype, "aprovados", void 0);
__decorate([
    state()
], DemoTablePedidosAprovacao.prototype, "duplicacoes", void 0);
__decorate([
    state()
], DemoTablePedidosAprovacao.prototype, "registro", void 0);
DemoTablePedidosAprovacao = __decorate([
    customElement('demotable--pedidosaprovacao-102053')
], DemoTablePedidosAprovacao);
export { DemoTablePedidosAprovacao };
