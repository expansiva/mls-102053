var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/funcionariosedicao.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página F3 do todo/analise-paginas-demonstracao-com-table.md.
//
// Edição POR LINHA: cada linha tem "Editar", e só a linha aberta vira campo. É o que o nome
// "inline edit" faz esperar, e é como um cadastro real funciona — edita-se um registro por vez,
// com salvar e cancelar.
//
// Quem controla a edição é a MOLÉCULA, pelo modo por linha: a página informa
// `editing-rows` com a chave da linha aberta, e cada `<TableRow key="...">` se identifica.
// A página não mexe no `is-editing` de campo nenhum.
//
// O botão de cada linha carrega o handler DESTA página, com a matrícula certa — o que só é
// possível porque a molécula foi migrada para slots vivos: no caminho antigo ele seria um clone
// de string e não chamaria nada.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-inline-edit-table';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
import { FUNCIONARIOS } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-inline-edit-table',
    'groupentertext--ml-enter-text',
    'grouptriggeraction--ml-button-standard',
];
let DemoTableFuncionariosEdicao = class DemoTableFuncionariosEdicao extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demotable--funcionariosedicao-102053 {
  display: block;
}
demotable--funcionariosedicao-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--funcionariosedicao-102053 .head {
  margin-bottom: 2rem;
}
demotable--funcionariosedicao-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--funcionariosedicao-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--funcionariosedicao-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--funcionariosedicao-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--funcionariosedicao-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosedicao-102053 .barra {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.85rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--funcionariosedicao-102053 .estado {
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosedicao-102053 .resultado {
  margin-bottom: 1rem;
  padding: 0.75rem 1rem;
  border-left: 4px solid var(--ml-primary, #3b82f6);
  border-radius: 0.25rem;
  background: var(--ml-primary-container, #e8f0fe);
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--funcionariosedicao-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
        this.equipe = FUNCIONARIOS.slice(0, 8);
        /** Cargo por matrícula — o estado é da PÁGINA; a tabela não guarda valor. */
        this.cargos = Object.fromEntries(FUNCIONARIOS.slice(0, 8).map((f) => [f.matricula, f.cargo]));
        /** Qual linha está aberta para edição. Vazio = todas em leitura. */
        this.linhaEmEdicao = '';
        /** Valor em digitação, isolado até salvar — é o que permite cancelar. */
        this.rascunho = '';
        this.ultimoSalvo = '';
    }
    editar(matricula) {
        this.linhaEmEdicao = matricula;
        this.rascunho = this.cargos[matricula];
        this.ultimoSalvo = '';
    }
    cancelar() {
        this.linhaEmEdicao = '';
        this.rascunho = '';
    }
    salvar(matricula) {
        this.cargos = { ...this.cargos, [matricula]: this.rascunho };
        this.ultimoSalvo = `${this.equipe.find((f) => f.matricula === matricula)?.nome}: ${this.rascunho}`;
        this.linhaEmEdicao = '';
        this.rascunho = '';
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Pessoas</p>
          <h1 class="title">Revisão de cargos</h1>
          <p class="subtitle">
            Clique em <strong>Editar</strong> numa linha para alterar o cargo dela. Só a linha
            aberta vira campo — as demais continuam em leitura.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        ${this.ultimoSalvo
            ? html `<p class="resultado">Cargo atualizado — ${this.ultimoSalvo}</p>`
            : html ``}

        <groupviewtable--ml-inline-edit-table editing-rows=${this.linhaEmEdicao}>
          <Caption>Cargos por pessoa</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="matricula" sortable>Matrícula</TableHead>
              <TableHead key="nome" sortable>Nome</TableHead>
              <TableHead key="departamento" sortable>Departamento</TableHead>
              <TableHead key="cargo">Cargo</TableHead>
              <TableHead key="acao">Ação</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${this.equipe.map((f) => this.renderLinha(f.matricula))}
          </TableBody>
        </groupviewtable--ml-inline-edit-table>
      </div>
    `;
    }
    renderLinha(matricula) {
        const f = this.equipe.find((x) => x.matricula === matricula);
        const editando = this.linhaEmEdicao === matricula;
        return html `
      <TableRow key=${f.matricula}>
        <TableCell>${f.matricula}</TableCell>
        <TableCell>${f.nome}</TableCell>
        <TableCell>${f.departamento}</TableCell>
        <TableCell>
          <groupentertext--ml-enter-text
            .value=${editando ? this.rascunho : this.cargos[matricula]}
            @change=${(e) => (this.rascunho = e.target.value)}
            @input=${(e) => (this.rascunho = e.target.value)}
          ></groupentertext--ml-enter-text>
        </TableCell>
        <TableCell>
          ${editando
            ? html `
                <grouptriggeraction--ml-button-standard
                  data-variant="primary"
                  size="xs"
                  @action=${() => this.salvar(matricula)}
                >
                  <Label>Salvar</Label>
                </grouptriggeraction--ml-button-standard>
                <grouptriggeraction--ml-button-standard
                  data-variant="ghost"
                  size="xs"
                  @action=${this.cancelar}
                >
                  <Label>Cancelar</Label>
                </grouptriggeraction--ml-button-standard>
              `
            : html `
                <grouptriggeraction--ml-button-standard
                  data-variant="secondary"
                  size="xs"
                  @action=${() => this.editar(matricula)}
                >
                  <Label>Editar</Label>
                </grouptriggeraction--ml-button-standard>
              `}
        </TableCell>
      </TableRow>
    `;
    }
};
__decorate([
    state()
], DemoTableFuncionariosEdicao.prototype, "cargos", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao.prototype, "linhaEmEdicao", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao.prototype, "rascunho", void 0);
__decorate([
    state()
], DemoTableFuncionariosEdicao.prototype, "ultimoSalvo", void 0);
DemoTableFuncionariosEdicao = __decorate([
    customElement('demotable--funcionariosedicao-102053')
], DemoTableFuncionariosEdicao);
export { DemoTableFuncionariosEdicao };
