var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/equipemedia.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página C3 do todo/analise-paginas-demonstracao-com-table.md.
//
// A célula como MÍDIA: foto redonda à esquerda, nome em cima e e-mail embaixo — três informações
// numa coluna só. É o padrão de tabela de pessoas que a equipe reconhece de produtos prontos.
//
// Usa a ml-advanced-data-table por dois recursos que só ela tem e que combinam com este caso:
// **redimensionar coluna** (arrastando a divisa do cabeçalho) e **reordenar coluna** (arrastando
// o cabeçalho). A coluna de pessoa é a que mais se beneficia de largura ajustável.
//
// Avatar com INICIAIS e não foto: a página do harness é autocontida — sem rede, sem arquivo. O
// desenho é o mesmo que uma foto teria.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-advanced-data-table';
import { COLABORADORES, formatarMoeda } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = ['groupviewtable--ml-advanced-data-table'];
let DemoTableEquipeMedia = class DemoTableEquipeMedia extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`demotable--equipemedia-102053 {
  display: block;
}
demotable--equipemedia-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--equipemedia-102053 .head {
  margin-bottom: 2rem;
}
demotable--equipemedia-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--equipemedia-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--equipemedia-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--equipemedia-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--equipemedia-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--equipemedia-102053 .controles {
  display: flex;
  flex-wrap: wrap;
  gap: 1.75rem;
  padding: 0.9rem 1.25rem;
  margin-bottom: 1.25rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.5rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--equipemedia-102053 .controle {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  font-size: 0.9375rem;
  color: var(--ml-on-surface, #1c1b1f);
  cursor: pointer;
}
demotable--equipemedia-102053 .pessoa {
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  min-width: 0;
}
demotable--equipemedia-102053 .avatar {
  flex: none;
  width: 2.25rem;
  height: 2.25rem;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 0.8125rem;
  font-weight: 700;
  letter-spacing: 0.02em;
}
demotable--equipemedia-102053 .pessoa-texto {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
demotable--equipemedia-102053 .pessoa-nome {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: 600;
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
demotable--equipemedia-102053 .pessoa-email {
  color: var(--ml-on-surface-muted, #49454f);
  font-size: 0.8125rem;
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
demotable--equipemedia-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Pessoas</p>
          <h1 class="title">Equipe por empresa</h1>
          <p class="subtitle">
            A coluna <strong>Name</strong> traz três informações numa célula só: avatar, nome e
            e-mail. Arraste a divisa do cabeçalho para <strong>mudar a largura</strong> da coluna,
            ou arraste o próprio cabeçalho para <strong>reordenar</strong>.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <groupviewtable--ml-advanced-data-table>
          <Caption>Quadro por empresa, cargo e remuneração</Caption>

          <TableHeader>
            <TableRow>
              <TableHead key="nome" sortable>Name</TableHead>
              <TableHead key="empresa" sortable>Company</TableHead>
              <TableHead key="cargo" sortable>Occupation</TableHead>
              <TableHead key="salario" sortable>Salary</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            ${COLABORADORES.map((p) => html `
                <TableRow>
                  <TableCell>
                    <span class="pessoa">
                      <span class="avatar" style="background:${p.cor}" aria-hidden="true">
                        ${p.iniciais}
                      </span>
                      <span class="pessoa-texto">
                        <strong class="pessoa-nome">${p.nome}</strong>
                        <span class="pessoa-email">${p.email}</span>
                      </span>
                    </span>
                  </TableCell>
                  <TableCell>${p.empresa}</TableCell>
                  <TableCell>${p.cargo}</TableCell>
                  <TableCell data-class="text-right">${formatarMoeda(p.salario)}</TableCell>
                </TableRow>
              `)}
          </TableBody>
        </groupviewtable--ml-advanced-data-table>

        <p class="nota">
          A ordenação por <strong>Name</strong> lê o texto da célula inteira — nome e e-mail juntos.
          Como o nome vem primeiro, o resultado é o esperado; vale saber que a regra é essa.
        </p>
      </div>
    `;
    }
};
DemoTableEquipeMedia = __decorate([
    customElement('demotable--equipemedia-102053')
], DemoTableEquipeMedia);
export { DemoTableEquipeMedia };
