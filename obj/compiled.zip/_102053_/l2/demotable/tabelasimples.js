var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demotable/tabelasimples.ts" enhancement="_102020_/l2/enhancementAura"/>
// Página C1 do todo/analise-paginas-demonstracao-com-table.md.
//
// As duas tabelas básicas do grupo, lado a lado, com os MESMOS dados. Serve para a equipe
// enxergar quando NÃO precisa das mais pesadas: a maioria das telas é uma listagem simples, e
// puxar a tabela avançada só porque ela existe custa markup e comportamento que ninguém pediu.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewtable/ml-view-table';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
import { FUNCIONARIOS } from '/_102053_/l2/demotable/dados.js';
/** Tags em uso na tela. Aparecem no cabeçalho, para a equipe ver o que vai escrever. */
const COMPONENTES = [
    'groupviewtable--ml-view-table',
    'groupviewtable--ml-data-table',
];
const AMOSTRA = FUNCIONARIOS.slice(0, 6);
let DemoTableTabelaSimples = class DemoTableTabelaSimples extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`demotable--tabelasimples-102053 {
  display: block;
}
demotable--tabelasimples-102053 .page {
  padding: 2.5rem 2rem;
  max-width: 76rem;
  margin: 0 auto;
}
demotable--tabelasimples-102053 .head {
  margin-bottom: 2rem;
}
demotable--tabelasimples-102053 .eyebrow {
  font-size: 0.75rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.4rem;
}
demotable--tabelasimples-102053 .title {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.5rem;
}
demotable--tabelasimples-102053 .subtitle {
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
  max-width: 52rem;
}
demotable--tabelasimples-102053 .componentes {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
}
demotable--tabelasimples-102053 .componentes code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border: 1px solid var(--ml-outline-variant, #e2e8f0);
  border-radius: 0.25rem;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
}
demotable--tabelasimples-102053 .lado-a-lado {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(24rem, 1fr));
  gap: 2rem;
  align-items: start;
}
demotable--tabelasimples-102053 .coluna {
  min-width: 0;
}
demotable--tabelasimples-102053 .coluna-titulo {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.9375rem;
  font-weight: 600;
  color: var(--ml-on-surface, #1c1b1f);
  margin-bottom: 0.25rem;
}
demotable--tabelasimples-102053 .coluna-nota {
  font-size: 0.8125rem;
  color: var(--ml-on-surface-muted, #49454f);
  margin-bottom: 0.9rem;
}
demotable--tabelasimples-102053 .coluna-nota code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 0.75rem;
  padding: 0.1rem 0.3rem;
  border-radius: 0.2rem;
  background: var(--ml-surface-dim, #f5f5f5);
}
demotable--tabelasimples-102053 .nota {
  margin-top: 1.25rem;
  font-size: 0.875rem;
  color: var(--ml-on-surface-muted, #49454f);
  line-height: 1.6;
}
`);
    }
    render() {
        return html `
      <div class="page">
        <header class="head">
          <p class="eyebrow">Comparação</p>
          <h1 class="title">As duas tabelas básicas</h1>
          <p class="subtitle">
            Mesmos dados, mesmo markup. À esquerda a de exibição pura; à direita a que já traz
            ordenação. Nenhuma das duas precisa de configuração para o caso comum.
          </p>
          <p class="componentes">
            <span>Componentes nesta tela:</span>
            ${COMPONENTES.map((c) => html `<code>${c}</code>`)}
          </p>
        </header>

        <div class="lado-a-lado">
          <section class="coluna">
            <h2 class="coluna-titulo">ml-view-table</h2>
            <p class="coluna-nota">Exibição. Sem ordenação, sem seleção.</p>
            <groupviewtable--ml-view-table>
              <Caption>Equipe</Caption>
              <TableHeader>
                <TableRow>
                  <TableHead key="nome">Nome</TableHead>
                  <TableHead key="departamento">Departamento</TableHead>
                  <TableHead key="cargo">Cargo</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                ${AMOSTRA.map((f) => html `
                    <TableRow>
                      <TableCell>${f.nome}</TableCell>
                      <TableCell>${f.departamento}</TableCell>
                      <TableCell>${f.cargo}</TableCell>
                    </TableRow>
                  `)}
              </TableBody>
            </groupviewtable--ml-view-table>
          </section>

          <section class="coluna">
            <h2 class="coluna-titulo">ml-data-table</h2>
            <p class="coluna-nota">
              O mesmo, mais ordenação: basta marcar a coluna com <code>sortable</code>.
            </p>
            <groupviewtable--ml-data-table>
              <Caption>Equipe</Caption>
              <TableHeader>
                <TableRow>
                  <TableHead key="nome" sortable>Nome</TableHead>
                  <TableHead key="departamento" sortable>Departamento</TableHead>
                  <TableHead key="cargo" sortable>Cargo</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                ${AMOSTRA.map((f) => html `
                    <TableRow>
                      <TableCell>${f.nome}</TableCell>
                      <TableCell>${f.departamento}</TableCell>
                      <TableCell>${f.cargo}</TableCell>
                    </TableRow>
                  `)}
              </TableBody>
            </groupviewtable--ml-data-table>
          </section>
        </div>
      </div>
    `;
    }
};
DemoTableTabelaSimples = __decorate([
    customElement('demotable--tabelasimples-102053')
], DemoTableTabelaSimples);
export { DemoTableTabelaSimples };
