var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterboolean/ml-checkbox-preference-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CHECKBOX PREFERENCE — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterBoolean
// Casca (estratégia D): herda tudo de CheckboxPreferenceMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { CheckboxPreferenceMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference.js';
let CheckboxPreferenceMoleculeBrutal = class CheckboxPreferenceMoleculeBrutal extends CheckboxPreferenceMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-checkbox-preference-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupenterboolean--ml-checkbox-preference-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-checkbox-preference-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-checkbox-preference-brutal .ml-helper {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-checkbox-preference-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-checkbox-preference-brutal .ml-checkbox {
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  background: var(--ml-surface, #ffffff);
  accent-color: var(--ml-primary, #3b82f6);
  cursor: pointer;
  transition: none;
}
groupenterboolean--ml-checkbox-preference-brutal .ml-checkbox:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
  box-shadow: none;
}
groupenterboolean--ml-checkbox-preference-brutal .ml-checkbox:checked {
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupenterboolean--ml-checkbox-preference-brutal .ml-checkbox-error {
  border-color: var(--ml-error, #ef4444);
}
groupenterboolean--ml-checkbox-preference-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
  border-color: #999999;
}
`);
    }
};
CheckboxPreferenceMoleculeBrutal = __decorate([
    customElement('groupenterboolean--ml-checkbox-preference-brutal')
], CheckboxPreferenceMoleculeBrutal);
export { CheckboxPreferenceMoleculeBrutal };
