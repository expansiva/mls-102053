var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterboolean/ml-boolean-segmented-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BOOLEAN SEGMENTED — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterBoolean
// Casca (estratégia D): herda tudo de BooleanSegmentedMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { BooleanSegmentedMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-boolean-segmented.js';
let BooleanSegmentedMoleculeBrutal = class BooleanSegmentedMoleculeBrutal extends BooleanSegmentedMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-boolean-segmented-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-md: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f0f0f0;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #555555;
  --ml-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupenterboolean--ml-boolean-segmented-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-helper {
  color: var(--ml-on-surface-muted, #555555);
  font-family: var(--ml-font-family, monospace);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-track {
  border-radius: var(--ml-radius-md, 0);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option:hover:not(.ml-disabled):not(.ml-segmented-option-active) {
  background: var(--ml-surface-dim, #f0f0f0);
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option:active:not(.ml-disabled) {
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option-active {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: var(--ml-outline-variant, #000000);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option-active:hover:not(.ml-disabled) {
  background: #2563eb;
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option-active:active:not(.ml-disabled) {
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option-error:hover:not(.ml-disabled) {
  box-shadow: 2px 2px 0 var(--ml-error, #ef4444);
  transform: translate(2px, 2px);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-segmented-option-error:active:not(.ml-disabled) {
  box-shadow: 0 0 0 var(--ml-error, #ef4444);
  transform: translate(4px, 4px);
}
groupenterboolean--ml-boolean-segmented-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
`);
    }
};
BooleanSegmentedMoleculeBrutal = __decorate([
    customElement('groupenterboolean--ml-boolean-segmented-brutal')
], BooleanSegmentedMoleculeBrutal);
export { BooleanSegmentedMoleculeBrutal };
