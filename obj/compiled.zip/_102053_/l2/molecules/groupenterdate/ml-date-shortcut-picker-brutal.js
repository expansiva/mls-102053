var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterdate/ml-date-shortcut-picker-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATE SHORTCUT PICKER — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterDate
// Casca (estratégia D): herda tudo de DateShortcutPickerMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { DateShortcutPickerMolecule } from '/_102040_/l2/molecules/groupenterdate/ml-date-shortcut-picker.js';
let DateShortcutPickerMoleculeBrutal = class DateShortcutPickerMoleculeBrutal extends DateShortcutPickerMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-date-shortcut-picker-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-helper {
  color: #555555;
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut {
  background-color: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
  cursor: pointer;
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut--hoverable:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-variant, #000000);
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut--hoverable:active {
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-active {
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: #000000;
  box-shadow: 2px 2px 0 #000000;
  transform: translate(2px, 2px);
  transition: none;
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-input {
  background-color: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-input:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
  border-color: var(--ml-outline-variant, #000000);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-input--focused {
  border-color: var(--ml-outline-variant, #000000);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-input--error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-input--error:focus {
  outline: 3px solid var(--ml-error, #ef4444);
  outline-offset: 2px;
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444);
}
groupenterdate--ml-date-shortcut-picker-brutal .ml-date-shortcut-input--readonly {
  background-color: var(--ml-surface-dim, #f5f5f5);
  cursor: default;
  box-shadow: none;
}
groupenterdate--ml-date-shortcut-picker-brutal .animate-spin {
  animation-timing-function: steps(8);
}
`);
    }
};
DateShortcutPickerMoleculeBrutal = __decorate([
    customElement('groupenterdate--ml-date-shortcut-picker-brutal')
], DateShortcutPickerMoleculeBrutal);
export { DateShortcutPickerMoleculeBrutal };
