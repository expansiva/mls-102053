var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupenterdate/ml-compact-calendar-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COMPACT CALENDAR — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterDate
// Casca (estratégia D): herda tudo de MlCompactCalendarMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlCompactCalendarMolecule } from '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar.js';
let MlCompactCalendarMoleculeBrutal = class MlCompactCalendarMoleculeBrutal extends MlCompactCalendarMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-compact-calendar-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupenterdate--ml-compact-calendar-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterdate--ml-compact-calendar-brutal .ml-helper {
  color: #555555;
  font-family: var(--ml-font-family, monospace);
}
groupenterdate--ml-compact-calendar-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterdate--ml-compact-calendar-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupenterdate--ml-compact-calendar-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, monospace);
}
groupenterdate--ml-compact-calendar-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-container {
  background-color: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-container--error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444);
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-header {
  border-bottom: 2px solid #000000;
  padding-bottom: 6px;
  margin-bottom: 8px;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-header-clear {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface-muted, #999999);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  border: 2px solid #000000;
  border-radius: var(--ml-radius-sm, 0);
  background: var(--ml-surface, #ffffff);
  cursor: pointer;
  transition: none;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-header-clear:hover {
  color: var(--ml-on-surface, #000000);
  background: var(--ml-surface-dim, #f5f5f5);
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-nav {
  border-bottom: 2px solid #000000;
  padding-bottom: 6px;
  margin-bottom: 6px;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-nav-btn {
  background-color: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
  cursor: pointer;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-nav-btn--enabled:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-nav-btn--enabled:active {
  background-color: var(--ml-surface-dim, #f5f5f5);
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-nav-btn:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-nav-btn.ml-disabled {
  border-color: #999999;
  box-shadow: 2px 2px 0 #999999;
  color: #999999;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-grid {
  font-family: var(--ml-font-family, monospace);
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-day {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border: 2px solid transparent;
  border-radius: var(--ml-radius-sm, 0);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  transition: none;
  cursor: pointer;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-day--hoverable:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
  border-color: #000000;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-day:focus-visible {
  outline: 2px solid #000000;
  outline-offset: 1px;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-day-outside {
  color: var(--ml-on-surface-muted, #999999);
  opacity: 0.5;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-day-selected {
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: #000000;
  border-width: 2px;
  border-style: solid;
  box-shadow: 2px 2px 0 #000000;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-day-today {
  border-color: #000000;
  border-width: 2px;
  border-style: solid;
}
groupenterdate--ml-compact-calendar-brutal .ml-calendar-day-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
  border-color: transparent;
}
`);
    }
};
MlCompactCalendarMoleculeBrutal = __decorate([
    customElement('groupenterdate--ml-compact-calendar-brutal')
], MlCompactCalendarMoleculeBrutal);
export { MlCompactCalendarMoleculeBrutal };
