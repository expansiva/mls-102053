var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var MlCompactCalendarMolecule_1;
/// <mls fileReference="_102053_/l2/molecules/groupenterdate/ml-compact-calendar.ts" enhancement="_102020_/l2/enhancementAura"/>
// copiedFrom: _102040_/l2/molecules/groupenterdate/ml-compact-calendar @ 2026-08-26
// =============================================================================
// COMPACT CALENDAR MOLECULE
// =============================================================================
// Skill Group: enter + date
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    labelRequired: '*',
    placeholder: 'Select a date',
    loading: 'Loading...',
    clear: 'Clear',
    week: 'Wk',
    noValue: '—',
};
const message_pt = {
    labelRequired: '*',
    placeholder: 'Selecione uma data',
    loading: 'Carregando...',
    clear: 'Limpar',
    week: 'Sem',
    noValue: '—',
};
const message_de = {
    labelRequired: '*',
    placeholder: 'Datum auswählen',
    loading: 'Wird geladen...',
    clear: 'Löschen',
    week: 'KW',
    noValue: '—',
};
const messages = {
    en: message_en,
    pt: message_pt,
    de: message_de,
};
/// **collab_i18n_end**
let MlCompactCalendarMolecule = MlCompactCalendarMolecule_1 = class MlCompactCalendarMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-compact-calendar .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdate--ml-compact-calendar .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-compact-calendar .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-compact-calendar .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-compact-calendar .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-compact-calendar .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdate--ml-compact-calendar .ml-calendar-container {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupenterdate--ml-compact-calendar .ml-calendar-container--error {
  border-color: var(--ml-error, #ef4444);
}
groupenterdate--ml-compact-calendar .ml-calendar-header-clear:hover {
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdate--ml-compact-calendar .ml-calendar-nav-btn {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdate--ml-compact-calendar .ml-calendar-nav-btn--enabled:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupenterdate--ml-compact-calendar .ml-calendar-day {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdate--ml-compact-calendar .ml-calendar-day--hoverable:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupenterdate--ml-compact-calendar .ml-calendar-day-outside {
  color: var(--ml-on-surface-faint, #79747e);
}
groupenterdate--ml-compact-calendar .ml-calendar-day-selected {
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: var(--ml-primary, #3b82f6);
}
groupenterdate--ml-compact-calendar .ml-calendar-day-today {
  border-color: var(--ml-primary, #3b82f6);
}
groupenterdate--ml-compact-calendar .ml-calendar-day-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.minDate = '';
        this.maxDate = '';
        this.placeholder = '';
        this.firstDayOfWeek = 0;
        this.showWeekNumbers = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false; // kept for contract compliance
        this.viewMonth = new Date().getMonth();
        this.viewYear = new Date().getFullYear();
        this.hasFocus = false;
        this.instanceId = `compact-calendar-${MlCompactCalendarMolecule_1.idCounter++}`;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const minAttr = this.getAttribute('min-date');
        const maxAttr = this.getAttribute('max-date');
        if (valueAttr === `{{${key}}}`) {
            const selected = this.parseIsoDate(String(value || ''));
            if (selected) {
                this.viewMonth = selected.getMonth();
                this.viewYear = selected.getFullYear();
            }
            else {
                this.setViewToToday();
            }
        }
        if (minAttr === `{{${key}}}` || maxAttr === `{{${key}}}`) {
            this.ensureViewWithinBounds();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        const selected = this.parseIsoDate(this.value || '');
        if (selected) {
            this.viewMonth = selected.getMonth();
            this.viewYear = selected.getFullYear();
        }
        else {
            this.setViewToToday();
        }
        this.ensureViewWithinBounds();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleDayClick(day) {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (!this.isDateSelectable(day))
            return;
        const iso = this.formatIsoDate(day);
        this.value = iso;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleClear() {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (this.value === null || this.value === '')
            return;
        this.value = null;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handlePrevMonth() {
        if (!this.canNavigatePrev())
            return;
        this.navigateToMonth(-1);
    }
    handleNextMonth() {
        if (!this.canNavigateNext())
            return;
        this.navigateToMonth(1);
    }
    handleFocusIn() {
        if (!this.isEditing || this.disabled)
            return;
        if (!this.hasFocus) {
            this.hasFocus = true;
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
    }
    handleFocusOut(e) {
        if (!this.isEditing || this.disabled)
            return;
        const related = e.relatedTarget;
        if (related && this.contains(related))
            return;
        if (this.hasFocus) {
            this.hasFocus = false;
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        }
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const labelId = `${this.instanceId}-label`;
        const errorId = `${this.instanceId}-error`;
        const helperId = `${this.instanceId}-helper`;
        const describedBy = this.error
            ? errorId
            : (this.hasSlot('Helper') ? helperId : '');
        return html `
<div class="${cn('w-full', this.cssClass)}" @focusin=${this.handleFocusIn} @focusout=${this.handleFocusOut}>
${this.renderLabel(labelId)}
<div
class="${this.getContainerClasses()}"
role="dialog"
aria-modal="true"
aria-labelledby=${labelId}
aria-describedby=${describedBy}
aria-invalid=${this.error ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
>
${this.renderHeader()}
${this.renderCalendar()}
</div>
${this.renderFeedback(errorId, helperId)}
</div>
`;
    }
    renderViewMode() {
        const labelId = `${this.instanceId}-label`;
        const display = this.formatDisplayValue(this.value);
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel(labelId)}
<div class="ml-text text-sm">
${display}
</div>
</div>
`;
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label id=${labelId} class="${cn('ml-label mb-1 block text-sm', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
${this.required ? html `<span class="ml-error-text ml-1">${this.msg.labelRequired}</span>` : html ``}
</label>
`;
    }
    renderHeader() {
        const display = this.formatDisplayValue(this.value, true);
        const canClear = !!this.value && !this.disabled && !this.readonly && !this.loading;
        return html `
<div class="ml-calendar-header mb-2 flex items-center justify-between">
<div class="ml-text text-sm">
${display}
</div>
<div class="flex items-center gap-2">
${this.loading ? html `<span class="ml-text-muted text-xs">${this.msg.loading}</span>` : html ``}
${canClear ? html `
<button
class="ml-text-muted text-xs ml-calendar-header-clear"
@click=${this.handleClear}
>
${this.msg.clear}
</button>
` : html ``}
</div>
</div>
`;
    }
    renderCalendar() {
        const monthTitle = this.getMonthTitle();
        const weekdays = this.getWeekdayNames();
        const grid = this.getCalendarDays();
        const gridCols = this.showWeekNumbers ? 'grid-cols-8' : 'grid-cols-7';
        const weekLabel = this.showWeekNumbers
            ? html `<div class="ml-text-muted text-xs font-medium">${this.msg.week}</div>`
            : html ``;
        return html `
<div class="ml-calendar-grid w-full">
<div class="ml-calendar-nav mb-2 flex items-center justify-between">
<button
class="${this.getNavButtonClasses(this.canNavigatePrev())}"
@click=${this.handlePrevMonth}
?disabled=${!this.canNavigatePrev()}
aria-label="Previous month"
>
‹
</button>
<div class="ml-text text-sm font-medium" aria-live="polite">
${monthTitle}
</div>
<button
class="${this.getNavButtonClasses(this.canNavigateNext())}"
@click=${this.handleNextMonth}
?disabled=${!this.canNavigateNext()}
aria-label="Next month"
>
›
</button>
</div>
<div class="grid ${gridCols} gap-1" role="row">
${weekLabel}
${weekdays.map((d) => html `<div class="ml-text-muted text-xs font-medium">${d}</div>`)}
</div>
<div class="mt-1 grid ${gridCols} gap-1" role="grid">
${grid.map((week) => html `
${this.showWeekNumbers ? html `
<div class="ml-text-muted text-xs flex items-center justify-center">
${week.weekNumber}
</div>
` : html ``}
${week.days.map((day) => this.renderDayCell(day))}
`)}
</div>
</div>
`;
    }
    renderDayCell(day) {
        const isSelected = this.isSameIsoDate(day.date, this.value); // Ensure selected date matches by ISO string
        const classes = this.getDayClasses(day, isSelected);
        const disabled = day.disabled || this.disabled || this.readonly || this.loading;
        return html `
<button
class="${classes}"
@click=${() => this.handleDayClick(day.date)}
?disabled=${disabled}
role="gridcell"
aria-selected=${isSelected ? 'true' : 'false'}
aria-disabled=${disabled ? 'true' : 'false'}
>
${day.date.getDate()}
</button>
`;
    }
    renderFeedback(errorId, helperId) {
        if (this.error) {
            return html `<p id=${errorId} class="ml-error-text mt-1 text-xs">${this.error}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${helperId} class="${cn('ml-helper mt-1 text-xs', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    // ===========================================================================
    // HELPERS — DATE
    // ===========================================================================
    setViewToToday() {
        const now = new Date();
        this.viewMonth = now.getMonth();
        this.viewYear = now.getFullYear();
    }
    parseIsoDate(value) {
        if (!value)
            return null;
        const parts = value.split('-').map((p) => parseInt(p, 10));
        if (parts.length !== 3 || parts.some((p) => isNaN(p)))
            return null;
        const [year, month, day] = parts;
        return new Date(year, month - 1, day);
    }
    formatIsoDate(date) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }
    formatDisplayValue(value, allowPlaceholder = false) {
        if (!value)
            return allowPlaceholder ? (this.placeholder || this.msg.placeholder) : this.msg.noValue;
        const date = this.parseIsoDate(value);
        if (!date)
            return this.msg.noValue;
        const locale = this.locale || navigator.language || 'en-US';
        return new Intl.DateTimeFormat(locale).format(date);
    }
    getMonthTitle() {
        const locale = this.locale || navigator.language || 'en-US';
        const date = new Date(this.viewYear, this.viewMonth, 1);
        return new Intl.DateTimeFormat(locale, { month: 'long', year: 'numeric' }).format(date);
    }
    getWeekdayNames() {
        const locale = this.locale || navigator.language || 'en-US';
        const formatter = new Intl.DateTimeFormat(locale, { weekday: 'short' });
        const base = new Date(2021, 7, 1); // Sunday
        const days = Array.from({ length: 7 }, (_, i) => {
            const d = new Date(base.getFullYear(), base.getMonth(), base.getDate() + i);
            return formatter.format(d);
        });
        const start = Math.min(Math.max(this.firstDayOfWeek, 0), 6);
        return days.slice(start).concat(days.slice(0, start));
    }
    getCalendarDays() {
        const first = new Date(this.viewYear, this.viewMonth, 1);
        const startOffset = (first.getDay() - this.firstDayOfWeek + 7) % 7;
        const startDate = new Date(this.viewYear, this.viewMonth, 1 - startOffset);
        const weeks = [];
        let current = new Date(startDate);
        for (let w = 0; w < 6; w++) {
            const weekDays = [];
            const weekStart = new Date(current);
            for (let d = 0; d < 7; d++) {
                const dayDate = new Date(current);
                const inCurrentMonth = dayDate.getMonth() === this.viewMonth;
                const disabled = !inCurrentMonth || !this.isDateSelectable(dayDate);
                weekDays.push({
                    date: dayDate,
                    inCurrentMonth,
                    disabled,
                });
                current.setDate(current.getDate() + 1);
            }
            weeks.push({
                weekNumber: this.getWeekNumber(weekStart),
                days: weekDays,
            });
        }
        return weeks;
    }
    isDateSelectable(date) {
        if (!date)
            return false;
        const min = this.parseIsoDate(this.minDate || '');
        const max = this.parseIsoDate(this.maxDate || '');
        const day = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        if (min && day < new Date(min.getFullYear(), min.getMonth(), min.getDate()))
            return false;
        if (max && day > new Date(max.getFullYear(), max.getMonth(), max.getDate()))
            return false;
        return true;
    }
    isSameDay(a, b) {
        if (!a || !b)
            return false;
        return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
    }
    isSameIsoDate(date, value) {
        if (!value)
            return false;
        return this.formatIsoDate(date) === value; // Compare using ISO string to keep selection highlight stable
    }
    getWeekNumber(date) {
        const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        const dayNum = d.getUTCDay() || 7;
        d.setUTCDate(d.getUTCDate() + 4 - dayNum);
        const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
        return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    }
    ensureViewWithinBounds() {
        const min = this.parseIsoDate(this.minDate || '');
        const max = this.parseIsoDate(this.maxDate || '');
        const viewIndex = this.viewYear * 12 + this.viewMonth;
        if (min) {
            const minIndex = min.getFullYear() * 12 + min.getMonth();
            if (viewIndex < minIndex) {
                this.viewYear = min.getFullYear();
                this.viewMonth = min.getMonth();
            }
        }
        if (max) {
            const maxIndex = max.getFullYear() * 12 + max.getMonth();
            if (viewIndex > maxIndex) {
                this.viewYear = max.getFullYear();
                this.viewMonth = max.getMonth();
            }
        }
    }
    canNavigatePrev() {
        if (this.disabled || this.readonly || this.loading)
            return false;
        const prev = new Date(this.viewYear, this.viewMonth - 1, 1);
        const min = this.parseIsoDate(this.minDate || '');
        if (!min)
            return true;
        const minMonth = new Date(min.getFullYear(), min.getMonth(), 1);
        return prev >= minMonth;
    }
    canNavigateNext() {
        if (this.disabled || this.readonly || this.loading)
            return false;
        const next = new Date(this.viewYear, this.viewMonth + 1, 1);
        const max = this.parseIsoDate(this.maxDate || '');
        if (!max)
            return true;
        const maxMonth = new Date(max.getFullYear(), max.getMonth(), 1);
        return next <= maxMonth;
    }
    navigateToMonth(delta) {
        const newDate = new Date(this.viewYear, this.viewMonth + delta, 1);
        this.viewYear = newDate.getFullYear();
        this.viewMonth = newDate.getMonth();
        this.dispatchEvent(new CustomEvent('monthChange', {
            bubbles: true,
            composed: true,
            detail: { year: this.viewYear, month: this.viewMonth + 1 },
        }));
    }
    // ===========================================================================
    // HELPERS — CLASSES
    // ===========================================================================
    getContainerClasses() {
        return cn('ml-calendar-container w-full rounded-lg border p-3 transition', this.error ? 'ml-calendar-container--error' : '', this.disabled ? 'ml-disabled' : '', this.readonly ? 'cursor-default' : '');
    }
    getNavButtonClasses(enabled) {
        return cn('ml-calendar-nav-btn h-7 w-7 rounded-md text-sm border transition', enabled ? 'ml-calendar-nav-btn--enabled' : 'ml-disabled');
    }
    getDayClasses(day, isSelected) {
        const isToday = this.isSameDay(day.date, new Date());
        const isDayDisabled = day.disabled || this.disabled || this.readonly || this.loading;
        return cn('ml-calendar-day h-8 w-8 rounded-md text-xs border border-transparent transition flex items-center justify-center', !day.inCurrentMonth ? 'ml-calendar-day-outside' : '', isSelected ? 'ml-calendar-day-selected' : '', !isSelected && isToday ? 'ml-calendar-day-today' : '', !isDayDisabled && !isSelected ? 'ml-calendar-day--hoverable' : '', isDayDisabled ? 'ml-calendar-day-disabled' : '');
    }
};
MlCompactCalendarMolecule.idCounter = 0;
__decorate([
    propertyDataSource({ type: String })
], MlCompactCalendarMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCompactCalendarMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCompactCalendarMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCompactCalendarMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-date' })
], MlCompactCalendarMolecule.prototype, "minDate", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-date' })
], MlCompactCalendarMolecule.prototype, "maxDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCompactCalendarMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'first-day-of-week' })
], MlCompactCalendarMolecule.prototype, "firstDayOfWeek", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-week-numbers' })
], MlCompactCalendarMolecule.prototype, "showWeekNumbers", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlCompactCalendarMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCompactCalendarMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCompactCalendarMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCompactCalendarMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCompactCalendarMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlCompactCalendarMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlCompactCalendarMolecule.prototype, "viewMonth", void 0);
__decorate([
    state()
], MlCompactCalendarMolecule.prototype, "viewYear", void 0);
__decorate([
    state()
], MlCompactCalendarMolecule.prototype, "hasFocus", void 0);
MlCompactCalendarMolecule = MlCompactCalendarMolecule_1 = __decorate([
    customElement('groupenterdate--ml-compact-calendar')
], MlCompactCalendarMolecule);
export { MlCompactCalendarMolecule };
