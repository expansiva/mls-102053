var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupselectone/ml-dial-select-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DIAL SELECT — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupSelectOne
// Casca (estratégia D): herda tudo de DialSelectMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { DialSelectMolecule } from '/_102040_/l2/molecules/groupselectone/ml-dial-select.js';
let DialSelectMoleculeBrutal = class DialSelectMoleculeBrutal extends DialSelectMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-dial-select-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupselectone--ml-dial-select-brutal .ml-label {
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-dial-select-brutal .ml-helper {
  color: #555555;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-dial-select-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-dial-select-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-dial-select-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-dial-select-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-dial-select-brutal .ml-dial-track {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border-color: var(--ml-outline-variant, #000000);
  border-width: var(--ml-border-width, 3px);
  border-style: solid;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupselectone--ml-dial-select-brutal .ml-dial-track.ml-disabled {
  border-color: #999999;
  box-shadow: 4px 4px 0 #999999;
}
groupselectone--ml-dial-select-brutal .ml-dial-track-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444);
}
groupselectone--ml-dial-select-brutal .ml-dial-focus:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupselectone--ml-dial-select-brutal .ml-dial-focus:focus {
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupselectone--ml-dial-select-brutal .ml-dial-option {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border-color: var(--ml-outline-variant, #000000);
  border-width: var(--ml-border-width, 3px);
  border-style: solid;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  transition: none;
}
groupselectone--ml-dial-select-brutal .ml-dial-option.ml-disabled {
  border-color: #999999;
}
groupselectone--ml-dial-select-brutal .ml-dial-option-selected {
  border-color: var(--ml-outline-variant, #000000);
  background-color: #000000;
  color: #ffffff;
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-dial-select-brutal .ml-dial-option-hover:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-dial-select-brutal .ml-dial-ring {
  border-color: var(--ml-outline-variant, #000000);
  border-width: 2px;
  border-style: solid;
}
groupselectone--ml-dial-select-brutal .ml-dial-search {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupselectone--ml-dial-select-brutal .ml-dial-search::placeholder {
  color: var(--ml-on-surface-muted, #999999);
  text-transform: none;
}
groupselectone--ml-dial-select-brutal .ml-dial-search:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
}
groupselectone--ml-dial-select-brutal .ml-dial-search:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
`);
    }
};
DialSelectMoleculeBrutal = __decorate([
    customElement('groupselectone--ml-dial-select-brutal')
], DialSelectMoleculeBrutal);
export { DialSelectMoleculeBrutal };
