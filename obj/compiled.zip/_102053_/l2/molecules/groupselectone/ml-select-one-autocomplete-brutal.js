var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupselectone/ml-select-one-autocomplete-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SELECT ONE AUTOCOMPLETE — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupSelectOne
// Casca (estratégia D): herda tudo de SelectOneAutocompleteMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { SelectOneAutocompleteMolecule } from '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete.js';
let SelectOneAutocompleteMoleculeBrutal = class SelectOneAutocompleteMoleculeBrutal extends SelectOneAutocompleteMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-select-one-autocomplete-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-radius-md: 0;
  --ml-radius-lg: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger:not(.ml-disabled):hover {
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger:not(.ml-disabled):active {
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger:focus-within {
  outline: 3px solid #000000;
  outline-offset: 2px;
  border-color: var(--ml-outline-variant, #000000);
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger-open {
  border-color: var(--ml-outline-variant, #000000);
  box-shadow: 1px 1px 0 #000000;
  transform: translate(2px, 2px);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger-error {
  border-color: var(--ml-error, #ef4444) !important;
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger-error:focus-within {
  box-shadow: 2px 2px 0 var(--ml-error, #ef4444);
  outline-color: var(--ml-error, #ef4444);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-combobox-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-combobox-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
  text-transform: none;
  letter-spacing: normal;
  font-weight: 400;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-panel {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-item {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  border-radius: var(--ml-radius-sm, 0);
  border-color: transparent;
  transition: none;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-item:hover:not(.ml-disabled) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-item-selected {
  background: #000000;
  color: #ffffff;
  border-color: #000000;
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-item-highlighted {
  background: var(--ml-surface-dim, #f5f5f5);
  box-shadow: none;
  outline: 3px solid #000000;
  outline-offset: -3px;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-item-selected.ml-select-item-highlighted {
  background: #000000;
  color: #ffffff;
  outline-color: #ffffff;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-empty {
  color: #666666;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-label {
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-helper {
  color: #555555;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-panel .ml-text-muted {
  color: #555555;
  border-bottom: 2px solid #000000;
  font-weight: var(--ml-font-weight-medium, 700);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-select-one-autocomplete-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-select-one-autocomplete-brutal .ml-select-trigger.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
  transform: none;
}
`);
    }
};
SelectOneAutocompleteMoleculeBrutal = __decorate([
    customElement('groupselectone--ml-select-one-autocomplete-brutal')
], SelectOneAutocompleteMoleculeBrutal);
export { SelectOneAutocompleteMoleculeBrutal };
