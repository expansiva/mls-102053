var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ALERT MODAL — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupNotifyUser
// Casca (estratégia D): herda tudo de MlAlertModalMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlAlertModalMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.js';
let MlAlertModalMoleculeBrutal = class MlAlertModalMoleculeBrutal extends MlAlertModalMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-alert-modal-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-on-surface-faint: #555555;
  --ml-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  --ml-success: #16a34a;
  --ml-success-dim: #ecfdf5;
  --ml-warning: #d97706;
  --ml-warning-dim: #fffbeb;
  --ml-info-border: #000000;
  --ml-success-border: #000000;
  --ml-warning-border: #000000;
  --ml-outline-error: #ef4444;
}
groupnotifyuser--ml-alert-modal-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupnotifyuser--ml-alert-modal-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, monospace);
}
groupnotifyuser--ml-alert-modal-brutal .ml-text-faint {
  color: var(--ml-on-surface-faint, #555555);
  font-family: var(--ml-font-family, monospace);
}
groupnotifyuser--ml-alert-modal-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupnotifyuser--ml-alert-modal-brutal .ml-helper {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, monospace);
}
groupnotifyuser--ml-alert-modal-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupnotifyuser--ml-alert-modal-brutal .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupnotifyuser--ml-alert-modal-brutal .ml-success-text {
  color: var(--ml-success, #16a34a);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupnotifyuser--ml-alert-modal-brutal .ml-warning-text {
  color: var(--ml-warning, #d97706);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupnotifyuser--ml-alert-modal-brutal .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupnotifyuser--ml-alert-modal-brutal .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-alert-modal-brutal .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupnotifyuser--ml-alert-modal-brutal .ml-primary-dim-bg {
  background: #dbeafe;
}
groupnotifyuser--ml-alert-modal-brutal .ml-error-dim-bg {
  background: #fee2e2;
}
groupnotifyuser--ml-alert-modal-brutal .ml-success-dim-bg {
  background: var(--ml-success-dim, #ecfdf5);
}
groupnotifyuser--ml-alert-modal-brutal .ml-warning-dim-bg {
  background: var(--ml-warning-dim, #fffbeb);
}
groupnotifyuser--ml-alert-modal-brutal .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border {
  border-color: var(--ml-outline-variant, #000000);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-focus {
  border-color: var(--ml-primary, #3b82f6);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-info {
  border-color: var(--ml-info-border, #000000);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-success {
  border-color: var(--ml-success-border, #000000);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-warning {
  border-color: var(--ml-warning-border, #000000);
}
groupnotifyuser--ml-alert-modal-brutal .ml-focus-ring {
  box-shadow: 0 0 0 3px #000000;
}
groupnotifyuser--ml-alert-modal-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupnotifyuser--ml-alert-modal-brutal .hover\:ml-text:hover {
  color: var(--ml-on-surface, #000000);
}
groupnotifyuser--ml-alert-modal-brutal [role="alert"],
groupnotifyuser--ml-alert-modal-brutal [role="status"] {
  border-radius: var(--ml-radius-sm, 0) !important;
  border: var(--ml-border-width, 3px) solid #000000 !important;
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000) !important;
  font-family: var(--ml-font-family, monospace);
  transition: none;
}
groupnotifyuser--ml-alert-modal-brutal [role="alert"] {
  border-color: var(--ml-error, #ef4444) !important;
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444) !important;
}
groupnotifyuser--ml-alert-modal-brutal button[aria-label] {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  cursor: pointer;
  transition: none;
  padding: 4px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
groupnotifyuser--ml-alert-modal-brutal button[aria-label]:hover {
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
groupnotifyuser--ml-alert-modal-brutal button[aria-label]:active {
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
groupnotifyuser--ml-alert-modal-brutal button[aria-label]:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupnotifyuser--ml-alert-modal-brutal .ml-primary-dim-bg,
groupnotifyuser--ml-alert-modal-brutal .ml-success-dim-bg,
groupnotifyuser--ml-alert-modal-brutal .ml-warning-dim-bg,
groupnotifyuser--ml-alert-modal-brutal .ml-error-dim-bg {
  border-radius: var(--ml-radius-sm, 0);
  border: 2px solid #000000;
}
groupnotifyuser--ml-alert-modal-brutal h3.ml-text,
groupnotifyuser--ml-alert-modal-brutal h3 {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  color: var(--ml-on-surface, #000000);
}
groupnotifyuser--ml-alert-modal-brutal .absolute.inset-0[aria-hidden="true"] {
  background: rgba(0, 0, 0, 0.6) !important;
  backdrop-filter: none !important;
}
groupnotifyuser--ml-alert-modal-brutal .mt-6.flex.items-center.justify-end {
  border-top: 3px solid #000000;
  padding-top: 1rem;
  margin-top: 1.5rem;
}
`);
    }
};
MlAlertModalMoleculeBrutal = __decorate([
    customElement('groupnotifyuser--ml-alert-modal-brutal')
], MlAlertModalMoleculeBrutal);
export { MlAlertModalMoleculeBrutal };
