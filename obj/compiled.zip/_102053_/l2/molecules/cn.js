/// <mls fileReference="_102053_/l2/molecules/cn.ts" enhancement="_blank"/>
export function cn(...inputs) {
    return inputs.filter(Boolean).join(' ');
}
