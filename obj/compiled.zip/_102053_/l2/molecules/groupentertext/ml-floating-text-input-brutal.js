var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupentertext/ml-floating-text-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// FLOATING TEXT INPUT — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterText
// Casca (estratégia D): herda tudo de MlFloatingTextInputMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlFloatingTextInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-floating-text-input.js';
let MlFloatingTextInputMoleculeBrutal = class MlFloatingTextInputMoleculeBrutal extends MlFloatingTextInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-floating-text-input-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-on-surface-faint: #999999;
  --ml-error: #ef4444;
  --ml-outline-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupentertext--ml-floating-text-input-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupentertext--ml-floating-text-input-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-floating-text-input-brutal .ml-text-faint {
  color: var(--ml-on-surface-faint, #999999);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-floating-text-input-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-floating-text-input-brutal .ml-helper {
  color: #555555;
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-floating-text-input-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-floating-text-input-brutal .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupentertext--ml-floating-text-input-brutal .ml-input-container:focus-within {
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
  border-color: var(--ml-outline-variant, #000000);
}
groupentertext--ml-floating-text-input-brutal .ml-input-container-error {
  border-color: var(--ml-error, #ef4444) !important;
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444) !important;
}
groupentertext--ml-floating-text-input-brutal .ml-input-container-error:focus-within {
  box-shadow: 2px 2px 0 var(--ml-error, #ef4444) !important;
  transform: translate(2px, 2px);
}
groupentertext--ml-floating-text-input-brutal .ml-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupentertext--ml-floating-text-input-brutal .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #999999);
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
}
groupentertext--ml-floating-text-input-brutal .ml-spinner {
  border-color: var(--ml-outline-variant, #000000);
  border-top-color: var(--ml-on-surface, #000000);
  border-width: 3px;
  border-style: solid;
  border-radius: 0;
}
groupentertext--ml-floating-text-input-brutal .animate-spin {
  animation-timing-function: steps(8);
}
groupentertext--ml-floating-text-input-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupentertext--ml-floating-text-input-brutal .ml-input-container.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupentertext--ml-floating-text-input-brutal .ml-input-container.ml-disabled:focus-within {
  box-shadow: 3px 3px 0 #999999;
  transform: none;
}
`);
    }
};
MlFloatingTextInputMoleculeBrutal = __decorate([
    customElement('groupentertext--ml-floating-text-input-brutal')
], MlFloatingTextInputMoleculeBrutal);
export { MlFloatingTextInputMoleculeBrutal };
