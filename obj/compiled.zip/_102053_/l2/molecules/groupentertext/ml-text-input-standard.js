var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupentertext/ml-text-input-standard.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML TEXT INPUT STANDARD MOLECULE
// =============================================================================
// Skill Group: groupEnterText
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
let MlTextInputStandardMolecule = class MlTextInputStandardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        this.mask = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.displayValue = '';
        this.uid = `ml-text-${Math.random().toString(36).slice(2, 9)}`;
        // ===========================================================================
        // EVENT HANDLERS
        // ===========================================================================
        this.handleInput = (e) => {
            if (!this.isEditing || this.isDisabledOrLoading() || this.readonly)
                return;
            const target = e.target;
            const rawInput = target.value ?? '';
            if (this.isTextarea()) {
                let nextValue = rawInput;
                if (this.maxLength !== null && nextValue.length > this.maxLength) {
                    nextValue = nextValue.slice(0, this.maxLength);
                }
                this.value = nextValue;
                this.displayValue = nextValue;
                target.value = nextValue;
            }
            else if (this.mask) {
                let raw = this.extractRawFromMasked(rawInput, this.mask);
                if (this.maxLength !== null && raw.length > this.maxLength) {
                    raw = raw.slice(0, this.maxLength);
                }
                const formatted = this.applyMask(raw, this.mask);
                this.value = raw;
                this.displayValue = formatted;
                target.value = formatted;
            }
            else {
                let nextValue = rawInput;
                if (this.maxLength !== null && nextValue.length > this.maxLength) {
                    nextValue = nextValue.slice(0, this.maxLength);
                }
                this.value = nextValue;
                this.displayValue = nextValue;
                target.value = nextValue;
            }
            this.dispatchEvent(new CustomEvent('input', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
        };
        this.handleBlur = () => {
            if (!this.isEditing)
                return;
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            this.dispatchEvent(new CustomEvent('blur', {
                bubbles: true,
                composed: true,
            }));
        };
        this.handleFocus = () => {
            if (!this.isEditing)
                return;
            this.dispatchEvent(new CustomEvent('focus', {
                bubbles: true,
                composed: true,
            }));
        };
    }
    // ===========================================================================
    // STATE CHANGE HANDLER — derived state sync
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const maskAttr = this.getAttribute('mask');
        const rowsAttr = this.getAttribute('rows');
        if (valueAttr === `{{${key}}}` || maskAttr === `{{${key}}}` || rowsAttr === `{{${key}}}`) {
            this.updateDisplayValueFromProps();
        }
        this.requestUpdate();
    }
    updated(changedProps) {
        if (changedProps.has('value') || changedProps.has('mask') || changedProps.has('rows')) {
            this.updateDisplayValueFromProps();
        }
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        return html `
      <div class="${cn('flex w-full flex-col gap-1', this.cssClass)}">
        ${this.renderLabel()}
        ${this.isEditing ? this.renderEditMode() : this.renderViewMode()}
        ${this.isEditing ? this.renderFeedback() : nothing}
      </div>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id="${this.getLabelId()}" class="${cn('ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderEditMode() {
        return html `
      <div class="${this.getFieldContainerClasses()}">
        ${this.renderPrefix()}
        ${this.renderInputElement()}
        ${this.renderSuffix()}
        ${this.loading ? this.renderSpinner() : nothing}
      </div>
      ${this.renderCounter()}
    `;
    }
    renderViewMode() {
        const display = this.getViewDisplayValue();
        return html `
      <div class="${cn('flex w-full items-center gap-2', 'ml-text')}">
        ${this.renderPrefix()}
        <span class="ml-text">${display}</span>
        ${this.renderSuffix()}
      </div>
    `;
    }
    renderInputElement() {
        const describedBy = this.getDescribedBy();
        const ariaInvalid = this.hasError() ? 'true' : 'false';
        const ariaRequired = this.required ? 'true' : 'false';
        const labelId = this.hasSlot('Label') ? this.getLabelId() : nothing;
        if (this.isTextarea()) {
            return html `
        <textarea
          class="${this.getInputClasses()}"
          .value=${this.displayValue}
          name=${this.name || nothing}
          placeholder=${this.placeholder || nothing}
          minlength=${this.minLength ?? nothing}
          maxlength=${this.maxLength ?? nothing}
          rows=${this.rows}
          autocomplete=${this.autocomplete || nothing}
          ?disabled=${this.isDisabledOrLoading()}
          ?readonly=${this.readonly}
          aria-labelledby=${labelId}
          aria-describedby=${describedBy || nothing}
          aria-invalid=${ariaInvalid}
          aria-required=${ariaRequired}
          @input=${this.handleInput}
          @blur=${this.handleBlur}
          @focus=${this.handleFocus}
        ></textarea>
      `;
        }
        return html `
      <input
        class="${this.getInputClasses()}"
        .value=${this.displayValue}
        type=${this.inputType}
        name=${this.name || nothing}
        placeholder=${this.placeholder || nothing}
        minlength=${this.minLength ?? nothing}
        maxlength=${this.maxLength ?? nothing}
        autocomplete=${this.autocomplete || nothing}
        ?disabled=${this.isDisabledOrLoading()}
        ?readonly=${this.readonly}
        aria-labelledby=${labelId}
        aria-describedby=${describedBy || nothing}
        aria-invalid=${ariaInvalid}
        aria-required=${ariaRequired}
        @input=${this.handleInput}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
      />
    `;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `
      <div class="${cn('ml-text-muted', this.getSlotClass('Prefix'))}">
        ${unsafeHTML(this.getSlotContent('Prefix'))}
      </div>
    `;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `
      <div class="${cn('ml-text-muted', this.getSlotClass('Suffix'))}">
        ${unsafeHTML(this.getSlotContent('Suffix'))}
      </div>
    `;
    }
    renderFeedback() {
        if (this.hasError()) {
            return html `
        <p id="${this.getErrorId()}" class="${cn('text-xs ml-error-text')}">
          ${unsafeHTML(this.error)}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p id="${this.getHelperId()}" class="${cn('text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderCounter() {
        if (!this.isTextarea() || this.maxLength === null)
            return html ``;
        const current = this.value?.length ?? 0;
        return html `
      <div id="${this.getCounterId()}" class="${cn('text-xs ml-text-muted')}" aria-live="polite">
        ${current} / ${this.maxLength}
      </div>
    `;
    }
    renderSpinner() {
        return html `<span class="ml-spinner" aria-hidden="true"></span>`;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    updateDisplayValueFromProps() {
        if (this.isTextarea()) {
            this.displayValue = this.value ?? '';
            return;
        }
        if (this.mask) {
            this.displayValue = this.applyMask(this.value ?? '', this.mask);
            return;
        }
        this.displayValue = this.value ?? '';
    }
    isTextarea() {
        return this.rows > 1;
    }
    isDisabledOrLoading() {
        return this.disabled || this.loading;
    }
    hasError() {
        return !!this.error && this.isEditing;
    }
    getViewDisplayValue() {
        if (this.inputType === 'password')
            return '••••••••';
        if (!this.value)
            return '—';
        return this.value;
    }
    getFieldContainerClasses() {
        return [
            'flex w-full items-center gap-2 px-3 py-2',
            'ml-input-container',
            this.hasError() ? 'ml-input-container-error' : '',
            this.isDisabledOrLoading() ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses() {
        return [
            'w-full bg-transparent outline-none',
            'ml-input',
            this.isDisabledOrLoading() ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getLabelId() {
        return `${this.uid}-label`;
    }
    getHelperId() {
        return `${this.uid}-helper`;
    }
    getErrorId() {
        return `${this.uid}-error`;
    }
    getCounterId() {
        return `${this.uid}-counter`;
    }
    getDescribedBy() {
        const ids = [];
        if (this.hasError())
            ids.push(this.getErrorId());
        else if (this.hasSlot('Helper'))
            ids.push(this.getHelperId());
        if (this.isTextarea() && this.maxLength !== null)
            ids.push(this.getCounterId());
        return ids.join(' ');
    }
    isMaskToken(token) {
        return token === '#' || token === 'A' || token === '*';
    }
    isCharAllowed(ch, token) {
        if (token === '#')
            return /\d/.test(ch);
        if (token === 'A')
            return /[A-Za-z]/.test(ch);
        return true;
    }
    extractRawFromMasked(input, mask) {
        let raw = '';
        let tokenIndex = 0;
        for (const ch of input) {
            while (tokenIndex < mask.length && !this.isMaskToken(mask[tokenIndex])) {
                tokenIndex += 1;
            }
            if (tokenIndex >= mask.length)
                break;
            const token = mask[tokenIndex];
            if (this.isCharAllowed(ch, token)) {
                raw += ch;
                tokenIndex += 1;
            }
        }
        return raw;
    }
    applyMask(raw, mask) {
        let output = '';
        let rawIndex = 0;
        for (const token of mask) {
            if (this.isMaskToken(token)) {
                if (rawIndex >= raw.length)
                    break;
                const ch = raw[rawIndex];
                if (this.isCharAllowed(ch, token)) {
                    output += ch;
                    rawIndex += 1;
                }
                else {
                    rawIndex += 1;
                }
            }
            else {
                output += token;
            }
        }
        return output;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTextInputStandardMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTextInputStandardMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTextInputStandardMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTextInputStandardMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], MlTextInputStandardMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], MlTextInputStandardMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlTextInputStandardMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTextInputStandardMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], MlTextInputStandardMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTextInputStandardMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlTextInputStandardMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTextInputStandardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTextInputStandardMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTextInputStandardMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTextInputStandardMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTextInputStandardMolecule.prototype, "displayValue", void 0);
MlTextInputStandardMolecule = __decorate([
    customElement('groupentertext--ml-text-input-standard')
], MlTextInputStandardMolecule);
export { MlTextInputStandardMolecule };
