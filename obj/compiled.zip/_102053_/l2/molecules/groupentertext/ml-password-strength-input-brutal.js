var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/molecules/groupentertext/ml-password-strength-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PASSWORD STRENGTH INPUT — BRUTALISM (mls-102053)
// =============================================================================
// Skill Group: groupEnterText
// Casca (estratégia D): herda tudo de PasswordStrengthInputMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { PasswordStrengthInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-password-strength-input.js';
let PasswordStrengthInputMoleculeBrutal = class PasswordStrengthInputMoleculeBrutal extends PasswordStrengthInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-password-strength-input-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-on-surface-faint: #555555;
  --ml-error: #ef4444;
  --ml-success: #22c55e;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupentertext--ml-password-strength-input-brutal .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
groupentertext--ml-password-strength-input-brutal .ml-input-container:focus-within {
  border-color: var(--ml-primary, #3b82f6);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  outline: none;
}
groupentertext--ml-password-strength-input-brutal .ml-input-container-error {
  border-color: var(--ml-error, #ef4444) !important;
  box-shadow: 4px 4px 0 var(--ml-error, #ef4444) !important;
}
groupentertext--ml-password-strength-input-brutal .ml-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  transition: none;
}
groupentertext--ml-password-strength-input-brutal .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #555555);
  font-weight: 400;
}
groupentertext--ml-password-strength-input-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-password-strength-input-brutal .ml-helper {
  color: var(--ml-on-surface-faint, #555555);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-password-strength-input-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-password-strength-input-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupentertext--ml-password-strength-input-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-password-strength-input-brutal .ml-text-faint {
  color: var(--ml-on-surface-faint, #555555);
  font-family: var(--ml-font-family, monospace);
  transition: none;
}
groupentertext--ml-password-strength-input-brutal .ml-spinner {
  color: var(--ml-on-surface, #000000);
}
groupentertext--ml-password-strength-input-brutal .ml-spinner.animate-spin {
  animation-timing-function: steps(8);
}
groupentertext--ml-password-strength-input-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-password-strength-input-brutal .ml-disabled .ml-input-container {
  border-color: #999999;
  box-shadow: 4px 4px 0 #999999;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-track {
  background: var(--ml-surface-dim, #f5f5f5);
  border: 2px solid var(--ml-outline-variant, #000000);
  border-radius: 0;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-weak {
  background-color: var(--ml-error, #ef4444);
  border-radius: 0;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-weak-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-password-strength-input-brutal .ml-strength-fair {
  background-color: #f59e0b;
  border-radius: 0;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-fair-text {
  color: #f59e0b;
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-password-strength-input-brutal .ml-strength-strong {
  background-color: var(--ml-success, #22c55e);
  border-radius: 0;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-strong-text {
  color: var(--ml-success, #22c55e);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
`);
    }
};
PasswordStrengthInputMoleculeBrutal = __decorate([
    customElement('groupentertext--ml-password-strength-input-brutal')
], PasswordStrengthInputMoleculeBrutal);
export { PasswordStrengthInputMoleculeBrutal };
