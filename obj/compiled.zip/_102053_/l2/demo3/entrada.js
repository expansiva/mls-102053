var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102053_/l2/demo3/entrada.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DEMO 3 — ENTRADA · componentes do mls-102055 (glassmorphism por herança)
// =============================================================================
// Mesmo layout/dados/instâncias do demo2. Mudam só: as tags (sufixo -glass),
// os imports (102055) e o rótulo da demo.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
let Demo3Entrada = class Demo3Entrada extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`demo3--entrada-102053 {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
demo3--entrada-102053 .page {
  min-height: 100vh;
  padding: 2.5rem 2rem;
}
demo3--entrada-102053 .shell {
  max-width: 64rem;
  margin: 0 auto;
}
demo3--entrada-102053 .head {
  text-align: center;
  margin-bottom: 2.5rem;
}
demo3--entrada-102053 .brand {
  font-weight: 700;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
demo3--entrada-102053 .title {
  font-size: 1.625rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
}
demo3--entrada-102053 .subtitle {
  font-size: 0.8125rem;
}
demo3--entrada-102053 .block {
  margin-bottom: 2rem;
  border-radius: 16px;
  padding: 1.5rem;
}
demo3--entrada-102053 .block-title {
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 0.75rem;
}
demo3--entrada-102053 .grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1.25rem;
  align-items: start;
}
demo3--entrada-102053 .page {
  background: radial-gradient(circle at 15% 15%, #4c1d95 0%, transparent 55%), radial-gradient(circle at 85% 85%, #be185d 0%, transparent 50%), linear-gradient(135deg, #0b1220 0%, #1e1b4b 100%);
  background-attachment: fixed;
}
demo3--entrada-102053 .brand {
  color: #c7d2fe;
}
demo3--entrada-102053 .title {
  color: #ffffff;
}
demo3--entrada-102053 .subtitle {
  color: rgba(255, 255, 255, 0.65);
}
demo3--entrada-102053 .block {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
demo3--entrada-102053 .block-title {
  color: rgba(255, 255, 255, 0.55);
}
`);
        this.tgOn = true;
        this.tgOff = false;
        this.date = '2026-03-15';
        this.dt = '2026-03-15T09:30';
        this.price = 1299.9;
        this.budget = 5000;
        this.qty = 3;
        this.rangeLow = 200;
        this.rangeHigh = 750;
        this.fullName = 'Maria Silva';
        this.username = 'maria.silva';
        this.password = 'Senha123!';
        this.tags = 'design, ux';
        this.time = '09:30';
    }
    upd(key) {
        return (e) => {
            this[key] = e.detail?.value;
        };
    }
    render() {
        return html `
      <div class="page">
        <div class="shell">
          <header class="head">
            <div class="brand">◆ collab · 102055</div>
            <h1 class="title">Entrada — glass por herança (102055)</h1>
            <p class="subtitle">toggle · date · datetime · money · number · text · time</p>
          </header>

          <section class="block">
            <h2 class="block-title">groupEnterBoolean — ml-toggle-switch</h2>
            <div class="grid">
              <groupenterboolean--ml-toggle-switch-glass .value=${this.tgOn} @change=${this.upd('tgOn')}>
                <Label>Notificações por e-mail</Label>
                <Helper>Resumo diário</Helper>
              </groupenterboolean--ml-toggle-switch-glass>
              <groupenterboolean--ml-toggle-switch-glass .value=${this.tgOff} @change=${this.upd('tgOff')}>
                <Label>Modo escuro</Label>
                <Helper>Tema do sistema</Helper>
              </groupenterboolean--ml-toggle-switch-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupEnterDate / groupEnterDatetime / groupEnterTime</h2>
            <div class="grid">
              <groupenterdate--ml-date-picker-glass .value=${this.date} locale="pt-BR" @change=${this.upd('date')}>
                <Label>Data de início</Label>
                <Helper>Selecionada: ${this.date ?? '—'}</Helper>
              </groupenterdate--ml-date-picker-glass>
              <groupenterdatetime--ml-datetime-picker-glass .value=${this.dt} locale="pt-BR" minute-step="15" @change=${this.upd('dt')}>
                <Label>Agendamento</Label>
                <Helper>Selecionado: ${this.dt ?? '—'}</Helper>
              </groupenterdatetime--ml-datetime-picker-glass>
              <groupentertime--ml-clock-time-picker-glass .value=${this.time} locale="pt-BR" minute-step="5" @change=${this.upd('time')}>
                <Label>Horário</Label>
                <Helper>Selecionado: ${this.time ?? '—'}</Helper>
              </groupentertime--ml-clock-time-picker-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupEnterMoney — ml-currency-input</h2>
            <div class="grid">
              <groupentermoney--ml-currency-input-glass .value=${this.price} currency="BRL" locale="pt-BR" @change=${this.upd('price')}>
                <Label>Preço</Label>
                <Helper>Valor de venda</Helper>
              </groupentermoney--ml-currency-input-glass>
              <groupentermoney--ml-currency-input-glass .value=${this.budget} currency="USD" locale="en-US" min="0" max="10000" @change=${this.upd('budget')}>
                <Label>Budget (USD)</Label>
              </groupentermoney--ml-currency-input-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupEnterNumber — ml-number-stepper / ml-range-slider</h2>
            <div class="grid">
              <groupenternumber--ml-number-stepper-glass .value=${this.qty} min="0" max="10" step="1" @change=${this.upd('qty')}>
                <Label>Quantidade</Label>
                <Helper>Selecionado: ${this.qty}</Helper>
              </groupenternumber--ml-number-stepper-glass>
              <groupenternumber--ml-range-slider-glass
                .value=${this.rangeLow}
                .valueHigh=${this.rangeHigh}
                min="0"
                max="1000"
                step="50"
                locale="pt-BR"
                @change=${(e) => {
            this.rangeLow = e.detail?.value ?? this.rangeLow;
            this.rangeHigh = e.detail?.valueHigh ?? this.rangeHigh;
        }}
              >
                <Label>Faixa de preço</Label>
                <Helper>${this.rangeLow} – ${this.rangeHigh}</Helper>
                <Prefix>R$</Prefix>
              </groupenternumber--ml-range-slider-glass>
            </div>
          </section>

          <section class="block">
            <h2 class="block-title">groupEnterText — floating / password / tag</h2>
            <div class="grid">
              <groupentertext--ml-floating-text-input-glass .value=${this.fullName} @change=${this.upd('fullName')}>
                <Label>Nome completo</Label>
                <Helper>Como no documento</Helper>
              </groupentertext--ml-floating-text-input-glass>
              <groupentertext--ml-floating-text-input-glass .value=${this.username} @change=${this.upd('username')}>
                <Label>Usuário</Label>
              </groupentertext--ml-floating-text-input-glass>
              <groupentertext--ml-password-strength-input-glass .value=${this.password} @change=${this.upd('password')}>
                <Label>Senha</Label>
                <Helper>Use letras, números e símbolos</Helper>
              </groupentertext--ml-password-strength-input-glass>
              <groupentertext--ml-tag-input-glass .value=${this.tags} @change=${this.upd('tags')}>
                <Label>Tags</Label>
                <Helper>Enter ou vírgula para adicionar</Helper>
              </groupentertext--ml-tag-input-glass>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
__decorate([
    state()
], Demo3Entrada.prototype, "tgOn", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "tgOff", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "date", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "dt", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "price", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "budget", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "qty", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "rangeLow", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "rangeHigh", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "fullName", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "username", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "password", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "tags", void 0);
__decorate([
    state()
], Demo3Entrada.prototype, "time", void 0);
Demo3Entrada = __decorate([
    customElement('demo3--entrada-102053')
], Demo3Entrada);
export { Demo3Entrada };
