declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102053_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102053_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102053_/l2/demo/notificacoes" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    export class DemoLiveSlotsNotificacoes extends StateLitElement {
        /** Linhas do painel de log. É o que torna o resultado legível sem acompanhar a migração. */
        private log;
        /** Valor do consumidor exibido DENTRO do slot — o teste de reatividade (§7.3). */
        private contador;
        /**
         * Visibilidade das REGIÕES (§7.2). Vai por `.visible` nas moléculas, não por render
         * condicional da página: as moléculas precisam ser as MESMAS instâncias escondendo e
         * reabrindo a própria região. Se a página as removesse do DOM, o Lit criaria outras
         * novas ao voltar, e o bug que este item persegue — projetar uma vez só funciona na
         * primeira abertura — passaria despercebido.
         */
        private regioesAbertas;
        /** Quantas vezes já se escondeu e reabriu. O roteiro pede 3. */
        private ciclos;
        /**
         * O modal é controlado à parte porque é overlay: aberto, cobre a página inteira.
         * A molécula NÃO se fecha sozinha ao clicar na ação (`handleActionClick` só dispara
         * o evento) — quem fecha é o consumidor, ecoando o estado. É o mesmo contrato da
         * seleção da ml-data-table-minimal.
         */
        private modalAberto;
        /**
         * Tanto ml-button-standard quanto as moléculas de notificação disparam 'action',
         * as duas com bubbles+composed. Registrar a TAG de quem disparou é o que separa
         * os dois casos — e é o discriminador do A/B:
         *
         *   slot vivo    → duas linhas: a do BOTÃO (molécula aninhada viva) e a do wrapper
         *   snapshot     → só a do wrapper; o botão é HTML morto e não dispara nada
         */
        private onAction;
        /** O card de controle emite cardClick, não action. Serve para provar que ele está vivo. */
        private onCardClick;
        /** O X das moléculas mexe no `visible` DELAS; a página precisa ecoar ou o estado desencontra. */
        private onDismiss;
        private registrar;
        private limparLog;
        private alternarRegioes;
        private abrirModal;
        private incrementar;
        /**
         * Diz ONDE cada botão do banner de controle está e se está visível. Existe porque a leitura
         * do código não bastou: o `_hideSlotTags()` do moleculeBase põe display:none no slot tag de
         * origem, o que me fez prever que o original ficaria oculto — e a tela mostrou dois botões.
         * Entre deduzir e medir, medir.
         */
        private diagnosticar;
        private diagnosticarHost;
        render(): TemplateResult;
        private renderControles;
        /**
         * Conteúdo do slot: o botão-molécula (prova o §7.1 — molécula aninhada viva) MAIS um texto
         * com o contador da página (prova o §7.3 — reatividade do binding dentro do slot).
         *
         * O contador fica FORA do <Label> de propósito. O ml-button-standard ainda NÃO foi migrado
         * (ml-button-standard.ts:157 lê o Label por getSlotContent), então o que ele mostra é um
         * clone serializado: um binding do Lit posto ali dentro morre na serialização DELE, e o
         * teste mediria o slot errado. Como irmão do botão, o span está no slot da molécula
         * externa — que é o que esta migração mudou.
         */
        private conteudoSlot;
        private renderMigradas;
        /**
         * A/B dentro da MESMA instância, e é a forma mais limpa de isolar a variável: os dois botões
         * são o mesmo componente, na mesma molécula, no mesmo passe de render — só muda o SLOT.
         * `Action` é vivo; `Message` continua no snapshot e vai continuar (a régua da TASK manda
         * conteúdo ficar serializado), então este controle sobrevive a todas as ondas.
         *
         * A primeira versão usava ml-profile-card como controle, mas ele é da Onda 1: migrá-lo
         * apagaria o lado B da página.
         */
        private renderControle;
        /**
         * Fica fora dos blocos porque é overlay: aberto, cobre a página. Abre pelo botão da barra e
         * fecha pela ação ou pelo X — os dois caminhos passam pelo eco do consumidor.
         */
        private renderModal;
        private renderLog;
    }
}
declare module "_102053_/l2/demo/tabela" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class DemoLiveSlotsTabela extends StateLitElement {
        private log;
        private contador;
        private pagina;
        /** Espelho do sort que a molécula anunciou, para a página saber o que esperar ver. */
        private ordemChave;
        private ordemDirecao;
        /**
         * 4 = pagina (só 4 linhas chegam a ser renderizadas/projetadas).
         * 20 = mostra as 9 (todas renderizadas e projetadas).
         * A comparação entre os dois é o que isola a hipótese "linha nunca renderizada não entra
         * na ordenação": se ordenar certo com 20 e errado com 4, é isso.
         */
        private tamanhoPagina;
        private alternarTamanho;
        /**
         * O valor está fora de ordem em relação ao id de propósito: ordenar por Valor tem de
         * embaralhar visivelmente a ordem dos ids. Se as duas colunas subissem juntas, uma troca
         * de conteúdo entre linhas passaria despercebida.
         */
        private readonly linhas;
        private registrar;
        private limparLog;
        private incrementar;
        /** Clique num botão de linha. O `data-origem` diz de qual linha ele veio. */
        private onAction;
        private onSort;
        /**
         * A ordem que a página ESPERA ver, calculada aqui a partir dos mesmos dados que ela deu à
         * molécula. Existe porque a conferência linha a linha só enxerga divergência DENTRO da
         * linha: se a linha inteira estiver errada, célula e botão continuam casando e o teste
         * passa. Foi o que aconteceu na 1ª rodada da P4.
         */
        private ordemEsperada;
        /** O que cada célula de Valor tem no DOM de ORIGEM — é o que a ordenação da molécula lê. */
        private dumpOrigem;
        /** Paginação é prop controlada: sem este eco a tabela avança e o pai nunca sabe. */
        private onPageChange;
        /**
         * O teste do §7.4, sem depender de olho: para cada <tr> renderizada, compara o texto da
         * PRIMEIRA célula com o `data-origem` do botão que está naquela mesma linha. Se a âncora
         * reusada entregar o conteúdo à linha errada — o bug que o 2º piloto corrigiu com
         * `data-ml-live-held` —, os dois deixam de casar e a divergência aparece aqui.
         */
        private conferirLinhas;
        render(): TemplateResult;
        private renderTabela;
        private renderLog;
    }
}
declare module "_102053_/l2/skills/theme_old" {
    export const themeInfo: {
        name: string;
        suffix: string;
        displayName: string;
        description: string;
        background: {
            kind: "light" | "dark" | "image";
            css: string;
            note: string;
        };
    };
    export const skill = "\n# Theme \u2014 Brutalism\n\n## 1. Visual Signature\n\n| Aspect | Value |\n|---|---|\n| Background | solid, opaque (`#3b82f6`, `#ffffff`, `#f5f5f5`) \u2014 NO transparency/blur |\n| Border | `3px solid #000` (disabled: `#999`) |\n| Radius | `0` everywhere \u2014 hard edges |\n| Shadow | offset, solid, no blur: `4px 4px 0 #000` (resting), `2px 2px 0` (hover) |\n| Font | `'JetBrains Mono', 'SF Mono', 'Courier New', monospace`, weight 700 |\n| Text | `text-transform: uppercase` + `letter-spacing: 0.05em` on labels/buttons |\n| Transition | `none` \u2014 state changes snap instantly |\n| Extras | kinetic hover: element translates INTO its shadow |\n| Background contract | light page background; black-on-white contrast |\n\n**Kinetic hover** (signature interaction): on `:hover` the element moves toward\nits shadow (`transform: translate(2px, 2px)` + shadow shrinks to `2px 2px 0`);\non `:active` it \"bottoms out\" (`translate(4px, 4px)`, shadow `0 0 0`). Disabled\nfor flat variants (ghost/link) which have no shadow.\n\n## 2. Tokens\n\nCanonical values, validated in the pilot.\n\n| Token | Brutal value | Role |\n|---|---|---|\n| `--ml-font-family` | `'JetBrains Mono', 'SF Mono', 'Courier New', monospace` | font |\n| `--ml-font-weight-medium` | `700` | emphasis weight |\n| `--ml-radius-sm` / `-md` / `-lg` | `0` | hard edges |\n| `--ml-border-width` | `3px` | thick borders |\n| `--ml-outline-variant` | `#000000` | default border |\n| `--ml-primary` | `#3b82f6` | primary action bg |\n| `--ml-on-primary` | `#ffffff` | text on primary |\n| `--ml-surface` | `#ffffff` | component bg |\n| `--ml-surface-dim` | `#f5f5f5` (`#f0f0f0` on buttons) | hover bg |\n| `--ml-on-surface` | `#000000` | primary text |\n| `--ml-on-surface-muted` | `#999999` | placeholder/secondary |\n| `--ml-error` | `#ef4444` | error text/border/bg |\n| `--ml-shadow-1` | `4px 4px 0 #000000` | resting offset shadow |\n| `--ml-shadow-2` | `2px 2px 0 #000000` | hover (shrunk) shadow |\n| `--ml-disabled-opacity` | `0.4` | disabled |\n| `--ml-text-transform` | `uppercase` | theme extra \u2014 brutal signature |\n| `--ml-letter-spacing` | `0.05em` | theme extra \u2014 brutal signature |\n\n## 3. Canonical CSS Rules\n\n**Interactive surface** (`.ml-button`, `.ml-select-trigger`, ...):\n```less\nborder-radius: var(--ml-radius-sm, 0);\nborder: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);\nfont-family: var(--ml-font-family, monospace);\nfont-weight: var(--ml-font-weight-medium, 700);\ntext-transform: var(--ml-text-transform, uppercase);   // buttons/labels only\nletter-spacing: var(--ml-letter-spacing, 0.05em);\nbox-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);\ntransition: none;\n&:not(.ml-disabled):hover  { box-shadow: var(--ml-shadow-2); transform: translate(2px, 2px); }\n&:not(.ml-disabled):active { box-shadow: 0 0 0 #000000;      transform: translate(4px, 4px); }\n&:focus-visible { outline: 3px solid #000000; outline-offset: 2px; }\n```\n\n**Motion stance**: the theme sheet must set `transition: none` explicitly on\ninteractive elements (the base defines transitions).\n\n**Flat variants** (`.ml-button-ghost`, `.ml-button-link`): `box-shadow: none`\nand neutralize the kinetic hover (`transform: none` in hover/active). Link also\ndrops the border and underlines (`text-underline-offset: 3px`,\n`text-decoration-thickness: 2px`).\n\n**States** \u2014 style the ml-* state classes the base emits:\n- `.ml-disabled`: `opacity: 0.4; cursor: not-allowed; pointer-events: none` +\n  grey out structure: `border-color: #999; box-shadow: <offset> #999`.\n  Compound states with their own values need a compound selector, e.g.\n  `.ml-select-trigger.ml-disabled { border-color: #999; box-shadow: 3px 3px 0 #999; }`.\n- open/selected use inversion: `.ml-select-item-selected { background: #000;\n  color: #fff; font-weight: 700; }`; open trigger sinks into its shadow\n  (`.ml-select-trigger-open { box-shadow: 1px 1px 0 #000; transform: translate(2px, 2px); }`).\n- error: `border-color: #ef4444; box-shadow: <offset> #ef4444`.\n\n**Panels** (`.ml-select-panel`, in the portal): `border: 3px solid #000;\nborder-radius: 0; background: #fff; box-shadow: 4px 4px 0 #000`. Section\nseparators are hard borders (`border-bottom: 3px solid #000` on the search\ncontainer, `2px solid #000` under group labels).\n\n**Mechanical spinner**: keep the inherited SVG spinner but make its rotation\nstepped (no smoothness): `.animate-spin { animation-timing-function: steps(8); }`.\nDo NOT re-introduce glyph icons in markup.\n\n## 4. Theme Nuances\n\n- Secondary text stays literal (not tokenized): helper/group-label `#555`,\n  empty state `#666`, item divider `border-bottom: 1px solid #e5e5e5`.\n- `text-transform: uppercase` applies to labels/buttons \u2014 not to user\n  content (input values, item text).\n- Migration precedence examples: an old `3px 3px 0` shadow offset or a\n  different grey WINS over the token table for that molecule's scope.\n- Kinetic hover must NOT be added to a migrated molecule whose old file had\n  none at rest-visible cost \u2014 apply only signature/state-completeness rules.\n";
    export const examples: {
        pattern: string;
        ref: string;
    }[];
}
