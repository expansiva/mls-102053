declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102053_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102053_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102053_/l2/brutalshowcase/testeinicial" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal';
    export class BrutalShowcaseTesteInicial extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/groupviewcard/ml-profile-card';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    export class Demo1AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupentermoney/ml-currency-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupenternumber/ml-range-slider';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102040_/l2/molecules/groupentertext/ml-tag-input';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class Demo1Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    export class Demo1Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class Demo1Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo1/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-card-selector';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-popover-multi-select';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class Demo1Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress-brutal';
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card-brutal';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal';
    export class Demo2AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal';
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker-brutal';
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker-brutal';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input-brutal';
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker-brutal';
    export class Demo2Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay-brutal';
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating-brutal';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale-brutal';
    export class Demo2Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-brutal';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps-brutal';
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav-brutal';
    export class Demo2Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo2/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-radio-group-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-segmented-control-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector-brutal';
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select-brutal';
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar-brutal';
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-brutal';
    export class Demo2Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/acao-visualizacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-profile-card-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
    export class Demo3AcaoVisualizacao extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/entrada" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
    import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
    import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
    import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
    import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
    export class Demo3Entrada extends StateLitElement {
        private tgOn;
        private tgOff;
        private date;
        private dt;
        private price;
        private budget;
        private qty;
        private rangeLow;
        private rangeHigh;
        private fullName;
        private username;
        private password;
        private tags;
        private time;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/feedback" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
    export class Demo3Feedback extends StateLitElement {
        private stars;
        private mood;
        private modalOpen;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/navegacao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass';
    import '/_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass';
    export class Demo3Navegacao extends StateLitElement {
        private main;
        private tab;
        private pill;
        private step;
        private wiz;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo3/selecao" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-radio-group-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-segmented-control-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-combobox-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-card-selector-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass';
    import '/_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass';
    import '/_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass';
    export class Demo3Selecao extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private hab;
        private q;
        private upd;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase1-ds" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102053_/l2/molecules/groupexpandcontent/ml-accordion';
    export class Demo4ShowcaseFase1Ds extends StateLitElement {
        private toggleOn;
        private toggleOff;
        private handleInput;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase1" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102053_/l2/molecules/groupexpandcontent/ml-accordion';
    export class Demo4ShowcaseFase1 extends StateLitElement {
        private inputValue;
        private inputError;
        private toggleOn;
        private toggleOff;
        private handleInput;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase2" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102053_/l2/molecules/groupexpandcontent/ml-accordion';
    export class Demo4ShowcaseFase2 extends StateLitElement {
        private toggleVal;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase3" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102053_/l2/molecules/groupexpandcontent/ml-accordion';
    export class Demo4ShowcaseFase3 extends StateLitElement {
        private toggleVal;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/showcase-fase4" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102053_/l2/molecules/groupexpandcontent/ml-accordion';
    export class Demo4ShowcaseFase4 extends StateLitElement {
        private darkMode;
        private toggleVal;
        private toggleOff;
        private toggleDarkMode;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/demo4/sign-in" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102053_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102053_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102053_/l2/molecules/groupenterboolean/ml-toggle-switch';
    export class Demo4SignIn extends StateLitElement {
        private email;
        private password;
        private remember;
        private loading;
        private error;
        private handleSubmit;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/checkout" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseCheckout extends StateLitElement {
        private cardName;
        private cardNumber;
        private expiry;
        private cpf;
        private saveCard;
        private diffAddress;
        private loading;
        private onCardName;
        private onCardNumber;
        private onExpiry;
        private onCpf;
        private onSaveCard;
        private onDiffAddress;
        private onConfirm;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demodropdown" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown';
    export class GlassShowcaseDemoDropdown extends StateLitElement {
        private country;
        private team;
        private onCountry;
        private onTeam;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote2" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseDemoLote2 extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote3" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseDemoLote3 extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote4" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class GlassShowcaseDemoLote4 extends StateLitElement {
        private tab;
        private pill;
        private navItem;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote5" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider';
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox';
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select';
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class GlassShowcaseDemoLote5 extends StateLitElement {
        private qty;
        private priceLow;
        private priceHigh;
        private price;
        private password;
        private tags;
        private fruit;
        private tier;
        private langs;
        private query;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote6" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    export class GlassShowcaseDemoLote6 extends StateLitElement {
        private step;
        private wiz;
        private stars;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demolote7" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class GlassShowcaseDemoLote7 extends StateLitElement {
        private date;
        private dt;
        private time;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/demomultiselect" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    export class GlassShowcaseDemoMultiSelect extends StateLitElement {
        private skills;
        private teams;
        private onSkills;
        private onTeams;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/login" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseLogin extends StateLitElement {
        private email;
        private password;
        private remember;
        private emailError;
        private loading;
        private onEmailInput;
        private onPasswordInput;
        private onRememberChange;
        private isEmailValid;
        private onSubmit;
        private goToSignup;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/settings" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSettings extends StateLitElement {
        private dirty;
        private loading;
        private values;
        private onFieldChange;
        private onSave;
        private onCancel;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase/signup" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GlassShowcaseSignup extends StateLitElement {
        private name;
        private email;
        private phone;
        private password;
        private acceptedTerms;
        private loading;
        private onName;
        private onEmail;
        private onPhone;
        private onPassword;
        private onTerms;
        private onSubmit;
        private goToLogin;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotea" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass';
    import '/_102055_/l2/molecules/groupentertext/ml-tag-input-glass';
    import '/_102055_/l2/molecules/groupentermoney/ml-currency-input-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass';
    import '/_102055_/l2/molecules/groupenternumber/ml-range-slider-glass';
    export class GlassShowcase2DemoLoteA extends StateLitElement {
        private fullName;
        private password;
        private tags;
        private price;
        private qty;
        private priceLow;
        private priceHigh;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloteb" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-radio-group-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-segmented-control-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-combobox-glass';
    import '/_102055_/l2/molecules/groupselectone/ml-card-selector-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass';
    import '/_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass';
    import '/_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass';
    import '/_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass';
    export class GlassShowcase2DemoLoteB extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        private skills;
        private langs;
        private query;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotec" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass';
    import '/_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass';
    export class GlassShowcase2DemoLoteC extends StateLitElement {
        private dt;
        private time;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloted" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass';
    import '/_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-profile-card-glass';
    import '/_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass';
    export class GlassShowcase2DemoLoteD extends StateLitElement {
        private lastAction;
        private selectedPlan;
        private onAction;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotee" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass';
    import '/_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass';
    import '/_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass';
    import '/_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass';
    export class GlassShowcase2DemoLoteE extends StateLitElement {
        private bc;
        private pill;
        private tab;
        private navItem;
        private stepper;
        private wizard;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demolotef" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass';
    import '/_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass';
    import '/_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass';
    export class GlassShowcase2DemoLoteF extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demoloteg" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass';
    import '/_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass';
    import '/_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-star-rating-glass';
    import '/_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass';
    export class GlassShowcase2DemoLoteG extends StateLitElement {
        private stars;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/glassshowcase2/demopilot" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass';
    import '/_102055_/l2/molecules/groupenterdate/ml-date-picker-glass';
    export class GlassShowcase2DemoPilot extends StateLitElement {
        private notif;
        private terms;
        private date;
        render(): TemplateResult;
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-boolean-segmented-brutal" {
    import { BooleanSegmentedMolecule } from '_102040_/l2/molecules/groupenterboolean/ml-boolean-segmented';
    export class BooleanSegmentedMoleculeBrutal extends BooleanSegmentedMolecule {
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-checkbox-preference-brutal" {
    import { CheckboxPreferenceMolecule } from '_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    export class CheckboxPreferenceMoleculeBrutal extends CheckboxPreferenceMolecule {
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/index" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/groupenterboolean/ml-boolean-segmented-brutal";
    import "_102053_/l2/molecules/groupenterboolean/ml-checkbox-preference-brutal";
    export class GroupEnterBooleanIndex extends StateLitElement {
        private card1;
        private card2;
        render(): any;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
    }
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-boolean-segmented-brutal.defs" {
    export const group = "groupEnterBoolean";
    export const layoutConfig: {
        boolean: string;
        labelPlacement: string;
        validation: string;
    };
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-boolean-segmented-brutal\n\n# Objective\nEnable the user to choose between two mutually exclusive boolean states through a pair of side-by-side options. The molecule must clearly identify the current selection, inform the system of changes, and adapt its interactivity and presentation according to editing, viewing, disabled, and error conditions.\n\n# Responsibilities\n- Display a provided label above the control.\n- Present two selectable options side by side during editing, representing affirmative and negative boolean states.\n- Visually distinguish the option that matches the current value from the unselected option.\n- Set the value to affirmative when that option is chosen.\n- Set the value to negative when that option is chosen.\n- Immediately inform the system when the user changes the selection, reporting the new boolean value.\n- Honor an initially configured boolean value.\n- Prevent user interaction and suppress system notifications while disabled.\n- Show the current value as static text during viewing mode, without interactive elements or system notifications.\n- Display helper text beneath the control during editing when available and no error is present.\n- Display error text and apply an error presentation when an error is present, replacing helper text.\n- Keep the distinguished option synchronized with the current value at all times.\n- Signal when the control receives or loses focus during editing.\n- Support keyboard selection during editing, allowing the user to toggle the value using the Space key and inform the system of the change.\n- Communicate disabled, selected, and invalid states to assistive technologies.\n- Associate the control with its visible label for accessibility.\n\n# Constraints\n- Only native boolean values (true or false) are valid selections.\n- The control must not send notifications to the system while disabled.\n- Error text and helper text must not appear in viewing mode.\n- Interactive options must not be rendered in viewing mode.\n- The visually distinguished option must always reflect the current value.\n- Keyboard interaction must only be available during editing and when not disabled.\n- The label must appear above the control; helper or error text must appear below the control during editing.\n- User interaction must be ignored while the control is disabled.\n\n# Notes\n- The affirmative option represents true; the negative option represents false.\n- The presentation must remain effective across light and dark environments.\n- Error state takes precedence over helper text display.";
}
declare module "_102053_/l2/molecules/groupenterboolean/ml-checkbox-preference-brutal.defs" {
    export const group = "groupEnterBoolean";
    export const layoutConfig: {
        boolean: string;
        labelPlacement: string;
        validation: string;
    };
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-checkbox-preference-brutal\n\n# Objective\nProvide a boolean preference control that allows users to mark or unmark an option. It must support an interactive editing mode for changing the value and a read-only view mode for displaying the current state, while clearly communicating validation issues.\n\n# Responsibilities\n- Present an interactive toggle in editing mode that switches the value between true and false.\n- Display static text \"Yes\" when the value is true and \"No\" when the value is false in view mode, without allowing interaction.\n- Update the value and notify the system when the user activates the toggle in editing mode.\n- Support keyboard activation to toggle the value when the control has focus in editing mode.\n- Prevent user interaction and value changes when disabled.\n- Display provided label content next to the control and associate it for accessibility.\n- Show error messages and apply an error state when an error exists in editing mode.\n- Show helper text below the control when no error is present and helper content is available in editing mode.\n- Report when the control gains focus and when it loses focus, only in editing mode.\n- Keep the visual checked appearance consistent with the current boolean value.\n\n# Constraints\n- Must conform to the groupEnterBoolean group behavior definitions.\n- Must not allow interaction or value changes in view mode.\n- Must not allow interaction or value changes when disabled.\n- Must suppress change notifications in view mode and when disabled.\n- Must prioritize error display over helper content in editing mode.\n- Must present only static text without interactive elements when in view mode.\n- Must provide equivalent visual treatments for light and dark modes, preserving contrast for all states including focus and error.\n\n# Notes\n- The editing layout should display the toggle indicator adjacent to the preference description, such as \"[x] Utilizar biometria\".\n- Visual spacing between the toggle, label, and auxiliary text must remain clear and readable for preference lists.";
}
declare module "_102053_/l2/molecules/groupenterdate/ml-compact-calendar-brutal" {
    import { MlCompactCalendarMolecule } from '_102040_/l2/molecules/groupenterdate/ml-compact-calendar';
    export class MlCompactCalendarMoleculeBrutal extends MlCompactCalendarMolecule {
    }
}
declare module "_102053_/l2/molecules/groupenterdate/ml-date-shortcut-picker-brutal" {
    import { DateShortcutPickerMolecule } from '_102040_/l2/molecules/groupenterdate/ml-date-shortcut-picker';
    export class DateShortcutPickerMoleculeBrutal extends DateShortcutPickerMolecule {
    }
}
declare module "_102053_/l2/molecules/groupenterdate/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/groupenterdate/ml-compact-calendar-brutal";
    import "_102053_/l2/molecules/groupenterdate/ml-date-shortcut-picker-brutal";
    export class GroupEnterDateIndex extends StateLitElement {
        private card1;
        private card2;
        render(): TemplateResult;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
    }
}
declare module "_102053_/l2/molecules/groupenterdate/ml-compact-calendar-brutal.defs" {
    export const group = "groupEnterDate";
    export const layoutConfig: {
        dateInput: string;
        labelPlacement: string;
        validation: string;
        requiredMark: string;
    };
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-compact-calendar-brutal\n\n# Objective\nAllow the user to select a single date from an always-visible inline calendar grid. The calendar renders directly inside the page layout without a popover, shows the current month with navigation controls, highlights today and the selected date, optionally displays week numbers, and respects min/max date bounds. It also has a view-only mode that shows the selected value as plain text.\n\n# Responsibilities\n- Render a full inline calendar grid for the current view month, showing all days in a 7-column layout.\n- Navigate to the previous or next month when the corresponding buttons are clicked.\n- Highlight the currently selected day and today's date visually.\n- Emit a \"change\" custom event with the selected ISO date string when the user clicks a selectable day.\n- Emit a \"monthChange\" custom event when the user navigates to a different month.\n- Emit \"focus\" and \"blur\" custom events when focus enters or leaves the component.\n- Provide a clear button in the header that removes the current selection and emits a \"change\" event with null.\n- Display the selected date in a locale-aware human-readable format in the header; show a placeholder when nothing is selected.\n- Disable navigation buttons when the target month would go outside the min/max date bounds.\n- Disable individual day cells that fall outside the current month or outside the min/max date range.\n- Support optional display of ISO week numbers as an additional column when \"show-week-numbers\" is true.\n- Respect a configurable first-day-of-week so the weekday header row and grid alignment start on the correct day.\n- Update the view month automatically when the \"value\", \"min-date\", or \"max-date\" properties change via external state binding.\n- Render in view-only mode (non-editable static text) when \"is-editing\" is false.\n- Display a label slot above the calendar and a helper/error slot below.\n- Show a required indicator next to the label when \"required\" is true.\n- Show an error message and apply error border styling to the container when \"error\" is non-empty.\n- Show a loading message and prevent day selection and navigation when \"loading\" is true.\n- Apply disabled styling and block all interaction when \"disabled\" is true.\n- Apply readonly styling and block day selection and clearing when \"readonly\" is true.\n\n# Constraints\n- Day cells outside the current month must be rendered as disabled and must not be selectable.\n- The clear button must not appear when there is no selection or when the component is in disabled, readonly, or loading state.\n- Navigation to previous or next month must be blocked when it would move outside the allowed min/max range.\n- Selection must always be a single date; the component does not support multi-selection.\n- In disabled or readonly state all interaction including month navigation must be blocked.\n- The calendar must always be visible; it does not collapse into a dropdown.\n- The \"change\" event must only fire when a valid, selectable date is chosen or when the selection is explicitly cleared.";
}
declare module "_102053_/l2/molecules/groupenterdate/ml-date-shortcut-picker-brutal.defs" {
    export const group = "groupEnterDate";
    export const layoutConfig: {
        dateInput: string;
        labelPlacement: string;
        validation: string;
        requiredMark: string;
    };
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-date-shortcut-picker-brutal\n\n# Objective\nProvide a date selection interface that offers configurable shortcut options for common dates alongside a manual date entry field. It allows users to quickly select predefined dates or enter a date manually, maintaining compliance with the groupEnterDate contract.\n\n# Responsibilities\n- Display configurable shortcut options labeled \"Hoje\", \"Ontem\", \"Esta semana\", \"Este m\u00EAs\", and \"\u00DAltimos 30 dias\" above the manual entry field, arranged horizontally and wrapping when space is insufficient\n- Present each shortcut as a pill-shaped element with consistent internal spacing and visual feedback for hover, focus, and selection states\n- Highlight the shortcut that corresponds to the current value using accent colors, including dark mode variants\n- When \"Hoje\" is selected, set the value to the current date in ISO format and emit the change event\n- When \"Ontem\" is selected, set the value to the previous day's date in ISO format and emit the change event\n- When \"Esta semana\" is selected, set the value to the first day of the current week based on the configured firstDayOfWeek, in ISO format, and emit the change event\n- When \"Este m\u00EAs\" is selected, set the value to the first day of the current month in ISO format and emit the change event\n- When \"\u00DAltimos 30 dias\" is selected, set the value to the date from 30 days before today in ISO format and emit the change event\n- Update the manual entry field to reflect the value when a shortcut is selected\n- Provide a manual date entry field with standard surface, border, and text styling, supporting dark mode and showing placeholder text when empty\n- Allow users to type a valid date or clear the manual entry field\n- When a valid date is entered manually, update the value in ISO format and emit the change event\n- When the manual entry is cleared, set the value to null and emit the change event with null\n- Disable any shortcut whose calculated date falls outside the minDate and maxDate boundaries, showing it with reduced opacity and no hover states\n- Prevent disabled shortcuts from changing the value if activated\n- When disabled, prevent all shortcuts and the manual field from being interactive\n- When readonly, prevent shortcuts from changing the value and prevent the manual field from being edited\n- During loading, display a loading indicator with contrast appropriate for light and dark modes, replacing the interactive area and blocking all interactions\n- In display mode, show only the formatted date text according to locale, or a long dash when no value exists; hide shortcuts, manual entry, error messages, and helper text\n- When the error property is a non-empty string, display the error message below the field, apply error border styling to the manual entry with colors supporting dark mode, and apply the error visual state\n- When no error is present and helper text is provided, display the helper text below the field in a secondary style\n- Emit a blur event when the manual entry field loses focus\n- Emit a focus event when the manual entry field receives focus\n- Apply accessibility attributes: associate the label via aria-labelledby, associate error text via aria-describedby, set aria-invalid when an error exists, and set aria-required when required\n\n# Constraints\n- Must use only the properties, events, and slot tags defined in the groupEnterDate contract\n- All date values emitted must follow the ISO \"YYYY-MM-DD\" format\n- Shortcuts must not update the value if their resulting date is outside the minDate/maxDate range\n- Error display takes precedence over helper text display\n- The manual entry field must support a null state when cleared\n- In display mode, no interactive elements or supporting text may be visible\n\n# Notes\n- The available shortcut set is configurable\n- Date display formatting follows the current locale settings\n- The firstDayOfWeek configuration affects only the \"Esta semana\" shortcut calculation";
}
declare module "_102053_/l2/molecules/groupentertext/ml-cpf-input-brutal" {
    import { CpfInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-cpf-input';
    export class CpfInputMoleculeBrutal extends CpfInputMolecule {
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input-brutal" {
    import { MlFloatingTextInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    export class MlFloatingTextInputMoleculeBrutal extends MlFloatingTextInputMolecule {
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-password-strength-input-brutal" {
    import { PasswordStrengthInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-password-strength-input';
    export class PasswordStrengthInputMoleculeBrutal extends PasswordStrengthInputMolecule {
    }
}
declare module "_102053_/l2/molecules/groupentertext/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/groupentertext/ml-cpf-input-brutal";
    import "_102053_/l2/molecules/groupentertext/ml-floating-text-input-brutal";
    import "_102053_/l2/molecules/groupentertext/ml-password-strength-input-brutal";
    export class GroupEnterTextIndex extends StateLitElement {
        private cardCpf;
        private cardFloating;
        private cardPassword;
        render(): TemplateResult;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
    }
}
declare module "_102053_/l2/molecules/groupentertext/ml-cpf-input-brutal.defs" {
    export const group = "groupEnterText";
    export const layoutConfig: {
        labelPlacement: string;
        validation: string;
    };
    export const skill = "# Metadata\n- TagName: groupentertext--ml-cpf-input-brutal\n# Objective\nPermitir a entrada e exibi\u00E7\u00E3o de CPF com formata\u00E7\u00E3o padr\u00E3o, mantendo o valor armazenado como apenas n\u00FAmeros.\n# Responsibilities\n- Aceitar a digita\u00E7\u00E3o de at\u00E9 11 d\u00EDgitos num\u00E9ricos para CPF.\n- Exibir o CPF formatado como 000.000.000-00 quando houver 11 d\u00EDgitos.\n- Manter e disponibilizar o valor armazenado apenas como sequ\u00EAncia num\u00E9rica, sem pontos e h\u00EDfen.\n- Em modo de edi\u00E7\u00E3o, permitir entrada em uma \u00FAnica linha com formata\u00E7\u00E3o aplicada na exibi\u00E7\u00E3o.\n- Disparar atualiza\u00E7\u00E3o a cada digita\u00E7\u00E3o com o valor bruto num\u00E9rico.\n- Ao perder o foco, emitir eventos de altera\u00E7\u00E3o e de perda de foco com o valor bruto num\u00E9rico.\n- Em modo de visualiza\u00E7\u00E3o, exibir o valor formatado quando existir; caso contr\u00E1rio, exibir \u201C\u2014\u201D.\n- Exibir r\u00F3tulo, ajuda, prefixo e sufixo quando fornecidos.\n- Exibir mensagem de erro quando fornecida e aplicar o estado de erro.\n# Constraints\n- Quando desabilitado, n\u00E3o permitir intera\u00E7\u00E3o nem emitir eventos de entrada.\n- Quando somente leitura, bloquear edi\u00E7\u00E3o e permitir sele\u00E7\u00E3o de texto, sem emitir eventos de entrada.\n- Se obrigat\u00F3rio e o valor estiver vazio, entrar em estado de erro quando a mensagem de erro for fornecida.\n- Deve apresentar os estados visuais: normal, focado, preenchido, desabilitado, somente leitura, erro e carregando.\n- A exibi\u00E7\u00E3o deve sempre seguir o formato de CPF com pontos e h\u00EDfen quando houver valor.\n# Notes\n- O valor armazenado \u00E9 sempre num\u00E9rico e sem formata\u00E7\u00E3o.";
}
declare module "_102053_/l2/molecules/groupentertext/ml-floating-text-input-brutal.defs" {
    export const group = "groupEnterText";
    export const layoutConfig: {
        labelPlacement: string;
        validation: string;
    };
    export const skill = "# Metadata\n- TagName: groupentertext--ml-floating-text-input-brutal\n\n# Objective\nAllow the user to enter a single line of text through an input field that features a floating label \u2014 the label starts in the placeholder position and animates upward when the field is focused or has a value. The component supports optional input masking, prefix and suffix slots, character length limits, multiple input types, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Display a floating label that animates to a smaller position above the input when the field is focused or has a value.\n- Accept and expose typed text as the component's value, dispatching an \"input\" event on each keystroke and a \"change\" event on blur.\n- Apply an optional input mask: insert literal separator characters automatically, strip non-matching characters, and store only the raw (unmasked) digits or letters as the value.\n- Enforce optional maximum and minimum character length limits on the raw value.\n- Support multiple input types (text, password, email, etc.) via the input-type property; never apply masking when the type is \"password\".\n- Render a read-only view mode (isEditing = false) that shows the label and value as plain text, displaying \"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\" for password type and \"\u2014\" when the value is empty.\n- Show an inline error message styled in red when the error property is set.\n- Show a helper text below the field when a Helper slot is provided and there is no error.\n- Render optional prefix and suffix content inside the input container via named slots.\n- Show a spinning indicator inside the suffix area when the loading state is active.\n- Dispatch \"focus\" and \"blur\" custom events when the underlying input gains or loses focus.\n- Synchronize the displayed masked value when the bound value, mask, or input-type changes externally.\n\n# Constraints\n- Input, typing, focus, and all interaction must be blocked when disabled, readonly, loading, or isEditing is false.\n- Masking must never be applied to password-type inputs.\n- The raw (unmasked) value must be stored in the value property; masked characters are display-only.\n- The clear action and option list are not part of this component; it is a plain text input, not a select.\n- Error styling must persist until the error property is cleared externally.\n- The loading state must prevent interaction and display a spinner in place of or alongside the suffix slot.\n- Multiple simultaneous selections or multi-line input are not supported by this component.";
}
declare module "_102053_/l2/molecules/groupentertext/ml-password-strength-input-brutal.defs" {
    export const group = "groupEnterText";
    export const layoutConfig: {
        labelPlacement: string;
        validation: string;
        requiredMark: string;
    };
    export const skill = "# Metadata\n- TagName: groupentertext--ml-password-strength-input-brutal\n\n# Objective\nProvide a password entry field that allows switching between hidden and visible text, combined with a real-time strength indicator based on configurable validation criteria. It operates within the groupEnterText contract.\n\n# Responsibilities\n- Present a password entry field during editing when configured for a single row.\n- Offer a control to alternate between masked and plain text visibility during editing, without changing the stored value.\n- Show a static placeholder for empty values and a masked representation for filled values when not in editing mode, while hiding all editing controls, strength indicators, and helper or error information.\n- Assess password strength using configurable criteria: minimum length (when specified), uppercase letters, numbers, and symbols.\n- Consider the length requirement satisfied when no minimum length is configured.\n- Classify strength into four levels based on how many criteria are met: zero to one as weak, two as medium, three as strong, and four as very strong.\n- Refresh the strength bar and criteria checklist immediately upon any change to the entered value.\n- Honor configured input masking for display while basing strength calculations on the underlying unmasked value.\n- Refuse input beyond a configured maximum length; show a character counter when multiple rows are allowed together with a maximum length limit.\n- Disable editing and prevent interaction with the visibility control when the field is marked as disabled, read-only, or loading.\n- Notify changes only through the contract-specified interactions (input, change, blur, focus), providing the current value.\n- Position label content above the field when supplied.\n- Position prefix content before the entry area and suffix content after it; the visibility control must coexist with suffix content.\n- Place the strength indicator below the entry area and above any helper or error message during editing.\n- Display a horizontal strength bar and adjacent text label that correspond to the current strength level.\n- Present each validation criterion beneath the strength bar with a visual marker indicating whether it is met.\n- Apply distinct visual treatments to distinguish satisfied criteria from unsatisfied ones.\n- Present error indicators and messaging when validation fails, while maintaining the strength indicator visible during editing.\n- Reduce opacity and remove interactive capabilities from the entire field set when disabled.\n- Allow text selection but block visibility toggle interaction when read-only.\n- Present a loading state that blocks entry and conceals the strength indicator.\n- Adapt all semantic colors for dark appearance, including backgrounds, borders, text, errors, and accents.\n\n# Constraints\n- Must only use the contract-defined content areas: Label, Helper, Prefix, and Suffix.\n- The visibility control must only appear when editing a single-row password field.\n- Strength evaluation must always reference the underlying value, never a masked representation.\n- No interactions other than those defined in the contract may be used to communicate changes.\n- When not in editing mode, no entry field, visibility control, strength indicator, helper text, or error message may appear.\n- The visibility control must not displace or suppress suffix content.\n- During loading, the strength indicator must remain hidden.\n\n# Notes\n- Strength assessment reflects the current state continuously as the user enters text.\n- Masking and character counting behaviors adhere to the groupEnterText contract.";
}
declare module "_102053_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal" {
    import { MlAlertModalMolecule } from '_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    export class MlAlertModalMoleculeBrutal extends MlAlertModalMolecule {
    }
}
declare module "_102053_/l2/molecules/groupnotifyuser/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal";
    export class GroupNotifyUserIndex extends StateLitElement {
        private card1Visible;
        render(): TemplateResult;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
    }
}
declare module "_102053_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal.defs" {
    export const group = "groupNotifyUser";
    export const layoutConfig: {
        feedback: string;
    };
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-alert-modal-brutal\n\n# Objective\nPresent a blocking modal alert for critical or destructive actions that demands user attention and an explicit choice before proceeding. Communicate severity through visual cues and provide clear options to confirm or cancel the action.\n\n# Responsibilities\n- Appear as a centered overlay with a backdrop that blocks interaction with the underlying screen when activated\n- Display a severity-appropriate icon by default, while allowing replacement with a custom icon when provided\n- Show a title when one is supplied\n- Always display the descriptive message content when the alert is active\n- Present externally supplied action buttons, including confirmation and cancellation options, arranged side by side\n- Notify the system when the user selects an action button\n- Notify the system when the user dismisses the alert through an available dismiss mechanism\n- Remain open when the user interacts with the backdrop or clicks outside the alert boundaries\n- Disappear completely without leaving reserved space when in an inactive state\n- Automatically close after a configured duration when specified, transitioning to an inactive state and signaling dismissal\n- Support distinct severity levels: danger treated as error, warning as warning, and info as info\n- Disable user-initiated dismissal mechanisms when configured as non-dismissible\n- Adjust presentation to modal overlay behavior when positioned for centered display\n- Announce its presence and severity to assistive technologies using appropriate roles and live regions\n- Adapt its visual presentation for dark environments\n\n# Constraints\n- The backdrop must be purely visual and must not respond to clicks or taps by closing the alert\n- Action buttons must be supplied externally; the alert must not generate default buttons\n- No output may be displayed when the alert is inactive\n- When non-dismissible, no close button or dismiss gesture may be available to the user\n- The message area must not be empty when the alert is visible\n- Default icons must match the severity level when no custom icon is supplied\n- Auto-dismiss must only occur when a positive duration is configured and the alert is active\n- Severity mapping must remain consistent: danger corresponds to error behavior\n- Modal positioning must cover the full screen with an overlay backdrop\n- Accessibility announcements must reflect the current alert type\n\n# Notes\n- The caller is responsible for defining the labels and appearance of the action buttons placed inside the action area\n- Dismissal via the dedicated dismiss mechanism is equivalent to cancellation from the system's perspective";
}
declare module "_102053_/l2/molecules/groupselectone/ml-combobox-brutal" {
    import { MlComboboxMolecule } from '_102040_/l2/molecules/groupselectone/ml-combobox';
    export class MlComboboxMoleculeBrutal extends MlComboboxMolecule {
        protected portalWidgetName: string;
    }
}
declare module "_102053_/l2/molecules/groupselectone/ml-dial-select-brutal" {
    import { DialSelectMolecule } from '_102040_/l2/molecules/groupselectone/ml-dial-select';
    export class DialSelectMoleculeBrutal extends DialSelectMolecule {
    }
}
declare module "_102053_/l2/molecules/groupselectone/ml-select-one-autocomplete-brutal" {
    import { SelectOneAutocompleteMolecule } from '_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    export class SelectOneAutocompleteMoleculeBrutal extends SelectOneAutocompleteMolecule {
    }
}
declare module "_102053_/l2/molecules/groupselectone/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102053_/l2/molecules/groupselectone/ml-combobox-brutal";
    import "_102053_/l2/molecules/groupselectone/ml-dial-select-brutal";
    import "_102053_/l2/molecules/groupselectone/ml-select-one-autocomplete-brutal";
    export class GroupSelectOneIndex extends StateLitElement {
        private card1;
        private card2;
        private card3;
        render(): TemplateResult;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
    }
}
declare module "_102053_/l2/molecules/groupselectone/ml-combobox-brutal.defs" {
    export const group = "groupSelectOne";
    export const layoutConfig: {
        selectOne: string;
        labelPlacement: string;
        validation: string;
    };
    export const skill = "# Metadata\n- TagName: groupselectone--ml-combobox-brutal\n\n# Objective\nAllow the user to choose exactly one option from a list by typing into a text field to filter results. A dropdown of matching options appears as the user types or when the field is focused. Optionally, when free-text mode is enabled, any typed value can be accepted even if it does not match a predefined option. The component supports groups, a clearable selection, required and error states, and a read-only view mode.\n\n# Responsibilities\n- Open the dropdown and display all options when the text field is focused.\n- Filter the visible options in real time as the user types, using case-insensitive partial matching on option label text.\n- Confirm the highlighted option as the selection when Enter is pressed, and close the dropdown.\n- Move the highlight down or up through the visible non-disabled options with Arrow Down / Arrow Up keys.\n- Close the dropdown without making changes when Escape is pressed, restoring the text field to the currently selected label.\n- Close the dropdown when Tab is pressed or when the user clicks outside the component.\n- Commit the typed text as the value in free-text mode when Enter is pressed and no option is highlighted, or when the field loses focus.\n- Display a \"Use ...\" entry at the bottom of the dropdown in free-text mode when the typed text does not exactly match any visible option.\n- Sync the text field display to the selected option's label when value is changed externally while the dropdown is closed.\n- Show an optional clear (x) button when clearable = true and the field has a value; clicking it resets value to null.\n- Display items inside named group sections with a group label header when items belong to a Group slot.\n- Show a checkmark next to the currently selected option in the dropdown.\n- Render a skeleton pulse placeholder while loading = true and the dropdown is closed.\n- Dispatch \"change\" when a selection is confirmed, \"input\" on every keystroke, \"focus\" on field focus, and \"blur\" when the component loses focus.\n- Show an error message below the field or a helper text from the Helper slot.\n- Render a compact read-only label and value display when isEditing = false.\n- Render a hidden input with the form name when the name property is set.\n\n# Constraints\n- All typing, dropdown opening, and selection must be blocked when disabled = true or loading = true.\n- readonly = true must allow focus and display but block typing, dropdown opening, and selection.\n- The dropdown must not be visible while the field lacks focus, except when opened by keyboard navigation.\n- Only one option can be selected at a time; selecting a new option always replaces the previous one.\n- In non-free-text mode, closing the dropdown without making a selection must restore the text field to the label of the current value, never retain an unmatched typed string.\n- Disabled options (item-level disabled attribute) must not be selectable by mouse or keyboard.\n- The clear button must not appear unless clearable = true is set.\n- The error state must persist until the error property is cleared.";
}
declare module "_102053_/l2/molecules/groupselectone/ml-dial-select-brutal.defs" {
    export const group = "groupSelectOne";
    export const layoutConfig: {
        selectOne: string;
        labelPlacement: string;
        validation: string;
    };
    export const skill = "# Metadata\n- TagName: groupselectone--ml-dial-select-brutal\n\n# Objective\nAllow the user to choose exactly one option from a circular dial layout. Options are arranged as buttons on concentric rings radiating outward from a central trigger button. Clicking the center opens or closes the rings; clicking a ring item selects it. Items from different groups appear on separate rings, while standalone items share an outermost ring. The component supports an optional search field, keyboard navigation, error and loading states, and a read-only view mode.\n\n# Responsibilities\n- Toggle the rings open or closed when the central trigger button is clicked.\n- Open the rings and move the highlight to the first enabled item when Arrow Down, Enter, or Space is pressed while closed.\n- Navigate the highlight forward or backward through visible non-disabled items with Arrow Down / Arrow Up keys while the rings are open.\n- Select the highlighted item when Enter is pressed while the rings are open, then close them.\n- Close the rings without making a selection when Escape is pressed.\n- Close the rings when the user clicks anywhere outside the component.\n- Arrange items from each Group slot on its own concentric ring and standalone items on a shared outer ring.\n- Show an optional search input above the dial when searchable = true and the dial is open; filter all visible items by the typed query.\n- Scale the dial container size automatically based on the number of rings and the fixed per-item size.\n- Display the selected item's label inside the central trigger button; show a placeholder or Trigger slot content when nothing is selected.\n- Dispatch a \"change\" custom event when a selection is made.\n- Emit \"focus\" and \"blur\" events when the trigger button gains or loses focus.\n- Display an error message or helper text below the dial.\n- Render a compact read-only text view of the selected label or placeholder when isEditing = false.\n- Render a hidden input with the form name when the name property is set.\n\n# Constraints\n- All interaction (trigger click, keyboard, item selection) must be blocked when disabled = true, readonly = true, or loading = true.\n- The component must not open when isEditing = false.\n- Disabled items (item-level disabled attribute) must not be selectable by click or keyboard.\n- Only one item can be selected at a time; selecting a new item replaces the previous selection immediately.\n- The highlight must stay within the flat list of currently visible non-disabled items; it must never land on a disabled item.\n- The search filter only affects the visible items in the open dial; it never alters value.\n- The central trigger must carry proper ARIA attributes (role=\"combobox\", aria-expanded, aria-haspopup, aria-invalid) at all times.";
}
declare module "_102053_/l2/molecules/groupselectone/ml-select-one-autocomplete-brutal.defs" {
    export const group = "groupSelectOne";
    export const layoutConfig: {
        selectOne: string;
        labelPlacement: string;
        validation: string;
    };
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-one-autocomplete-brutal\n\n# Objective\nAllow the user to choose exactly one option from a list by typing into a text field to filter results. A list of matching options appears when the field gains focus. The component supports readonly, disabled, and error states, offers an optional way to clear the selection, and allows full keyboard control.\n\n# Responsibilities\n- Filter the list of options by partial case-insensitive text match on their labels as the user types.\n- Show the list of options when the field has focus; hide it when focus is lost.\n- Permit only one selected option at a time; choosing a new option replaces the previous one.\n- Display the label of the currently selected option inside the text field.\n- Allow moving a highlight through the visible options using up and down arrow keys.\n- Confirm the highlighted option as the selection when Enter is pressed.\n- Close the option list without making changes when Escape is pressed.\n- Show a message when typing yields no matching options.\n- Provide an optional clear control that removes the current selection.\n- Prevent all interaction, typing, and list display when in readonly or disabled states.\n- Present an error message and invalid appearance when the field is in an error state.\n- Indicate when data is loading and prevent selection during that time.\n- Update the displayed label if the selected value is changed from outside.\n\n# Constraints\n- The option list must not be visible while the field lacks focus.\n- Highlight navigation must remain within the filtered set of options.\n- Readonly state must show the current selection label but block focus, typing, and list opening.\n- Disabled state must show the current selection label but block all interaction.\n- The clear control must not appear unless explicitly enabled.\n- Error indication must persist until the error state is resolved.\n- Selection must always be singular; multiple simultaneous selections are not allowed.\n\n# Notes\n- The filtering logic must match partial strings regardless of case (for example, typing \"zonas\" matches \"Amazonas\").\n- The component is intended for single-item selection scenarios such as choosing one state from a country list.";
}
declare module "_102053_/l2/skills/theme" {
    export const themeInfo: {
        name: string;
        suffix: string;
        displayName: string;
        description: string;
        background: {
            kind: "light" | "dark" | "image";
            css: string;
            note: string;
        };
    };
    export const skill = "\n# Theme \u2014 Brutalism\n\n## 1. Visual Signature\n\n| Aspect | Value |\n|---|---|\n| Background | solid, opaque (`#3b82f6`, `#ffffff`, `#f5f5f5`) \u2014 NO transparency/blur |\n| Border | `3px solid #000` (disabled: `#999`) |\n| Radius | `0` everywhere \u2014 hard edges |\n| Shadow | offset, solid, no blur: `4px 4px 0 #000` (resting), `2px 2px 0` (hover) |\n| Font | `'JetBrains Mono', 'SF Mono', 'Courier New', monospace`, weight 700 |\n| Text | `text-transform: uppercase` + `letter-spacing: 0.05em` on labels/buttons |\n| Transition | `none` \u2014 state changes snap instantly |\n| Extras | kinetic hover: element translates INTO its shadow |\n| Background contract | light page background; black-on-white contrast |\n\n**Kinetic hover** (signature interaction): on `:hover` the element moves toward\nits shadow (`transform: translate(2px, 2px)` + shadow shrinks to `2px 2px 0`);\non `:active` it \"bottoms out\" (`translate(4px, 4px)`, shadow `0 0 0`). Disabled\nfor flat variants (ghost/link) which have no shadow.\n\n## 2. Tokens\n\nCanonical values, validated in the pilot.\n\n| Token | Brutal value | Role |\n|---|---|---|\n| `--ml-font-family` | `'JetBrains Mono', 'SF Mono', 'Courier New', monospace` | font |\n| `--ml-font-weight-medium` | `700` | emphasis weight |\n| `--ml-radius-sm` / `-md` / `-lg` | `0` | hard edges |\n| `--ml-border-width` | `3px` | thick borders |\n| `--ml-outline-variant` | `#000000` | default border |\n| `--ml-primary` | `#3b82f6` | primary action bg |\n| `--ml-on-primary` | `#ffffff` | text on primary |\n| `--ml-surface` | `#ffffff` | component bg |\n| `--ml-surface-dim` | `#f5f5f5` (`#f0f0f0` on buttons) | hover bg |\n| `--ml-on-surface` | `#000000` | primary text |\n| `--ml-on-surface-muted` | `#999999` | placeholder/secondary |\n| `--ml-error` | `#ef4444` | error text/border/bg |\n| `--ml-shadow-1` | `4px 4px 0 #000000` | resting offset shadow |\n| `--ml-shadow-2` | `2px 2px 0 #000000` | hover (shrunk) shadow |\n| `--ml-disabled-opacity` | `0.4` | disabled |\n| `--ml-text-transform` | `uppercase` | theme extra \u2014 brutal signature |\n| `--ml-letter-spacing` | `0.05em` | theme extra \u2014 brutal signature |\n\n## 3. Canonical CSS Rules\n\n**Interactive surface** (`.ml-button`, `.ml-select-trigger`, ...):\n```less\nborder-radius: var(--ml-radius-sm, 0);\nborder: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);\nfont-family: var(--ml-font-family, monospace);\nfont-weight: var(--ml-font-weight-medium, 700);\ntext-transform: var(--ml-text-transform, uppercase);   // buttons/labels only\nletter-spacing: var(--ml-letter-spacing, 0.05em);\nbox-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);\ntransition: none;\n&:not(.ml-disabled):hover  { box-shadow: var(--ml-shadow-2); transform: translate(2px, 2px); }\n&:not(.ml-disabled):active { box-shadow: 0 0 0 #000000;      transform: translate(4px, 4px); }\n&:focus-visible { outline: 3px solid #000000; outline-offset: 2px; }\n```\n\n**Motion stance**: the theme sheet must set `transition: none` explicitly on\ninteractive elements (the base defines transitions).\n\n**Flat variants** (`.ml-button-ghost`, `.ml-button-link`): `box-shadow: none`\nand neutralize the kinetic hover (`transform: none` in hover/active). Link also\ndrops the border and underlines (`text-underline-offset: 3px`,\n`text-decoration-thickness: 2px`).\n\n**States** \u2014 style the ml-* state classes the base emits:\n- `.ml-disabled`: `opacity: 0.4; cursor: not-allowed; pointer-events: none` +\n  grey out structure: `border-color: #999; box-shadow: <offset> #999`.\n  Compound states with their own values need a compound selector, e.g.\n  `.ml-select-trigger.ml-disabled { border-color: #999; box-shadow: 3px 3px 0 #999; }`.\n- open/selected use inversion: `.ml-select-item-selected { background: #000;\n  color: #fff; font-weight: 700; }`; open trigger sinks into its shadow\n  (`.ml-select-trigger-open { box-shadow: 1px 1px 0 #000; transform: translate(2px, 2px); }`).\n- error: `border-color: #ef4444; box-shadow: <offset> #ef4444`.\n\n**Panels** (`.ml-select-panel`, in the portal): `border: 3px solid #000;\nborder-radius: 0; background: #fff; box-shadow: 4px 4px 0 #000`. Section\nseparators are hard borders (`border-bottom: 3px solid #000` on the search\ncontainer, `2px solid #000` under group labels).\n\n**Mechanical spinner**: keep the inherited SVG spinner but make its rotation\nstepped (no smoothness): `.animate-spin { animation-timing-function: steps(8); }`.\nDo NOT re-introduce glyph icons in markup.\n\n## 4. Theme Nuances\n\n- Secondary text stays literal (not tokenized): helper/group-label `#555`,\n  empty state `#666`, item divider `border-bottom: 1px solid #e5e5e5`.\n- `text-transform: uppercase` applies to labels/buttons \u2014 not to user\n  content (input values, item text).\n- Migration precedence examples: an old `3px 3px 0` shadow offset or a\n  different grey WINS over the token table for that molecule's scope.\n- Kinetic hover must NOT be added to a migrated molecule whose old file had\n  none at rest-visible cost \u2014 apply only signature/state-completeness rules.\n";
    export const examples: {
        pattern: string;
        ref: string;
    }[];
}
declare module "_102053_/l2/testes/account-settings" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class AccountSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingPerfil: boolean;
        isEditingSeguranca: boolean;
        isEditingCobranca: boolean;
        errors: Record<string, string>;
        name: string;
        email: string;
        phone: string;
        birthDate: string;
        bio: string;
        recoveryEmail: string;
        twoFaEnabled: boolean;
        pushNotif: boolean;
        cpf: string;
        spendingLimit: number;
        spendingAlert: number;
        autoPayment: boolean;
        termsAccepted: boolean;
        language: string;
        timezone: string;
        theme: string;
        private snapshotPerfil;
        private snapshotSeguranca;
        private snapshotCobranca;
        private editPerfil;
        private cancelPerfil;
        private savePerfil;
        private editSeguranca;
        private cancelSeguranca;
        private saveSeguranca;
        private editCobranca;
        private cancelCobranca;
        private saveCobranca;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get themeLabel();
        private formatMoney;
        private formatCpf;
        private err;
        private badge;
        private editHeader;
        private renderPerfilView;
        private renderSegurancaView;
        private renderCobrancaView;
        private renderPreferenciasView;
        private renderPerfilEditForm;
        private renderSegurancaEditForm;
        private renderCobrancaEditForm;
        private renderPreferenciasControls;
        private renderActivePanel;
        private renderTabs;
        render(): any;
    }
}
declare module "_102053_/l2/testes/appointment-scheduler" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    interface Meeting {
        id: number;
        title: string;
        date: string;
        room: string;
        participants: number;
    }
    export class AppointmentScheduler extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        title: string;
        agenda: string;
        startAt: string;
        intervalStart: string;
        intervalEnd: string;
        preferredStart: string;
        preferredEnd: string;
        participants: string[];
        selectedRooms: string[];
        recurrence: string;
        recurrenceCount: number;
        errors: Record<string, string>;
        upcomingMeetings: Meeting[];
        private readonly availableRooms;
        private readonly allParticipants;
        private validate;
        private err;
        private handleAgendar;
        private handleParticipantSelect;
        private removeParticipant;
        private renderTabs;
        private renderNovaReuniaoForm;
        private renderMinhasReunioes;
        render(): any;
    }
}
declare module "_102053_/l2/testes/budget-editor" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface BudgetRow {
        id: number;
        description: string;
        costCenter: string;
        qty: number;
        planned: number;
        actual: number;
    }
    export class BudgetEditor extends StateLitElement {
        rows: BudgetRow[];
        activeFilter: 'all' | 'over' | 'within';
        editingRowId: number | null;
        tableEpoch: number;
        bannerDismissed: boolean;
        toastVisible: boolean;
        editDescription: string;
        editCostCenter: string;
        editQty: number;
        editPlanned: number;
        editActual: number;
        errors: Record<string, string>;
        private editSnapshot;
        private get filteredRows();
        private get overBudgetRows();
        private get editingRow();
        private fmt;
        private err;
        private handleRowClick;
        private openEdit;
        private cancelEdit;
        private saveEdit;
        private renderTable;
        private renderEditPanel;
        render(): any;
    }
}
declare module "_102053_/l2/testes/candidate-pipeline" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-thumbs-rating';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload';
    import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand';
    import '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type Stage = 'triagem' | 'interview' | 'technical' | 'proposal' | 'hired';
    interface HistoryEntry {
        date: string;
        type: string;
        description: string;
    }
    interface Candidate {
        id: number;
        name: string;
        role: string;
        stage: Stage;
        rating: number;
        thumb: 'up' | 'down' | null;
        cvFile: string | null;
        interviewDate: string;
        history: HistoryEntry[];
    }
    export class CandidatePipeline extends StateLitElement {
        activeStage: Stage;
        searchQuery: string;
        selectedId: number;
        toastVisible: boolean;
        toastMessage: string;
        candidates: Candidate[];
        private readonly job;
        private readonly stageOrder;
        private readonly stageLabels;
        private readonly nextStageLabel;
        private get selectedCandidate();
        private get filteredCandidates();
        private countByStage;
        private initials;
        private selectFirstInStage;
        private autoSelectAfterMutation;
        private advanceCandidate;
        private rejectCandidate;
        private updateCandidate;
        private showToast;
        render(): any;
        private renderCandidateCard;
        private renderEmptyPanel;
        private renderDetailPanel;
    }
}
declare module "_102053_/l2/testes/corporate-dashboard" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-gauge';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class CorporateDashboard extends StateLitElement {
        period: string;
        bannerVisible: boolean;
        private readonly kpiData;
        private readonly transactions;
        private get kpis();
        private statusBadge;
        render(): any;
    }
}
declare module "_102053_/l2/testes/customer-profile" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class CustomerProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        clientName: string;
        personType: string;
        cnpj: string;
        cpf: string;
        email: string;
        phone: string;
        segment: string;
        city: string;
        stateUF: string;
        registerDate: string;
        birthday: string;
        channels: string;
        acceptsOffers: boolean;
        acceptsWpp: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get segmentLabel();
        private get initials();
        private get personTypeLabel();
        render(): any;
    }
}
declare module "_102053_/l2/testes/edicao-cliente" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EdicaoClientePage extends StateLitElement {
        private nome;
        private endereco;
        private situacao;
        private pesquisa;
        private clienteAtual;
        private errors;
        private saved;
        connectedCallback(): void;
        private getClientes;
        private err;
        private handleSelect;
        private handleSave;
        private handleCancel;
        private clearForm;
        render(): any;
        private renderForm;
        private renderSectionHeader;
    }
}
declare module "_102053_/l2/testes/employee-profile" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        admissionDate: string;
        department: string;
        role: string;
        workRegime: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get departmentLabel();
        private get roleLabel();
        private get initials();
        render(): any;
    }
}
declare module "_102053_/l2/testes/employee-registration" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeRegistration extends StateLitElement {
        currentStep: number;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        department: string;
        role: string;
        workRegime: string;
        admissionDate: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        modules: string;
        privacyAccepted: boolean;
        private readonly steps;
        private validate;
        private next;
        private back;
        private err;
        render(): any;
        private renderStep0;
        private renderStep1;
        private renderStep2;
    }
}
declare module "_102053_/l2/testes/escolha-orcamento" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-select';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EscolhaOrcamentoPage extends StateLitElement {
        private step;
        private steps;
        private orcamentoSelecionado;
        private orcamentoIdx;
        private tarefas;
        private bloquearVeiculo;
        private justificativa;
        private justificativaError;
        private osGerada;
        private getMenorValor;
        private brl;
        private stars;
        private tarefaLabel;
        private completeStep;
        private handleWizardChange;
        private handleTableChange;
        private handleNext;
        private handleBack;
        private handleGerarOS;
        render(): any;
        private renderNav;
        private renderStep0;
        private renderStep1;
        private compRow;
        private handleVistoriaChange;
        private renderStep2;
        private renderStep3;
        private renderStep4;
    }
}
declare module "_102053_/l2/testes/field-service-order" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code-1d';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code';
    import '/_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker';
    import '/_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    import '/_102040_/l2/molecules/groupentertime/ml-time-scroll-picker';
    import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface ChecklistItem {
        id: number;
        label: string;
        done: boolean;
    }
    export class FieldServiceOrder extends StateLitElement {
        currentStep: number;
        scannedBarcode: string;
        scannedQr: string;
        locationCoords: string;
        arrivalTime: string;
        preferredWindowStart: string;
        preferredWindowEnd: string;
        report: string;
        loadingHistory: boolean;
        historyLoaded: boolean;
        toastVisible: boolean;
        toastMessage: string;
        checklist: ChecklistItem[];
        private readonly order;
        private readonly serviceHistory;
        private get doneCount();
        private get allDone();
        private get checklistProgress();
        private toggleItem;
        private showToast;
        private loadHistory;
        private nextStep;
        render(): any;
    }
}
declare module "_102053_/l2/testes/financial-report" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-pie-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-view-table';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class FinancialReport extends StateLitElement {
        startDate: string;
        endDate: string;
        granularity: string;
        activeView: 'revenue' | 'expense' | 'margin';
        activeTab: string;
        private readonly summary;
        private kpiRing;
        render(): any;
    }
}
declare module "_102053_/l2/testes/ml-radio-group-exemple" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    interface Config {
        value: string;
        isEditing: boolean;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        loading: boolean;
        error: string;
    }
    export class MlRadioGroupExemple extends StateLitElement {
        basic: Config;
        grouped: Config;
        private toggle;
        private renderToggle;
        private renderConfig;
        render(): any;
    }
}
declare module "_102053_/l2/testes/order-management" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupviewchart/ml-line-chart';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class OrderManagement extends StateLitElement {
        activeTab: string;
        search: string;
        statusFilter: string;
        sortBy: string;
        filterStartDate: string;
        filterEndDate: string;
        page: number;
        bannerVisible: boolean;
        private readonly pageSize;
        private readonly allOrders;
        private readonly volumePoints;
        private get filteredOrders();
        private get visibleOrders();
        private toStatusKey;
        private countByTab;
        private statusBadge;
        private lateInTransit;
        render(): any;
    }
}
declare module "_102053_/l2/testes/org-chart" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type ViewMode = 'orgchart' | 'tree' | 'diagram';
    type LevelFilter = 'all' | 'exec' | 'manager' | 'operational';
    interface Employee {
        name: string;
        role: string;
        level: LevelFilter;
        dept: string;
        email: string;
    }
    export class OrgChart extends StateLitElement {
        activeDept: string;
        activeView: ViewMode;
        levelFilter: LevelFilter;
        searchQuery: string;
        selectedEmployee: Employee | null;
        loadingChart: boolean;
        loadingProgress: number;
        toastVisible: boolean;
        toastMessage: string;
        private readonly navItems;
        private readonly allEmployees;
        private get currentDeptLabel();
        private get employees();
        private initials;
        private levelLabel;
        private matchesSearch;
        private matchesLevel;
        private switchDept;
        private showToast;
        private handleNodeClick;
        private renderHierarchyNodes;
        render(): any;
    }
}
declare module "_102053_/l2/testes/product-edit" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class ProductEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        productName: string;
        sku: string;
        barcode: string;
        description: string;
        salePrice: number | null;
        costPrice: number | null;
        stock: number | null;
        minStock: number | null;
        packQty: number | null;
        category: string;
        supplier: string;
        tags: string;
        isActive: boolean;
        availOnline: boolean;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get margin();
        private get marginColor();
        private get stockStatus();
        private get categoryLabel();
        private get supplierLabel();
        render(): any;
    }
}
declare module "_102053_/l2/testes/select-one" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class SelectOne102040 extends StateLitElement {
        radioValue: string;
        radioGroupedValue: string;
        segmentedValue: string;
        segmentedErrorValue: string;
        render(): any;
    }
}
declare module "_102053_/l2/testes/supplier-edit" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SupplierEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        viewEpoch: number;
        errors: Record<string, string>;
        companyName: string;
        cnpj: string;
        email: string;
        website: string;
        address: string;
        companyType: string;
        paymentTerm: string;
        currency: string;
        taxRegime: string;
        contractStart: string;
        certExpiry: string;
        categories: string;
        isActive: boolean;
        isHomologated: boolean;
        isPreferred: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get companyTypeLabel();
        private get taxRegimeLabel();
        private get paymentTermLabel();
        private get currencyLabel();
        private readonly categoryMap;
        private get categoryLabels();
        private get initials();
        private statusBadge;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102053_/l2/testes/system-settings" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SystemSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingGeral: boolean;
        isEditingNotif: boolean;
        isEditingLimites: boolean;
        isEditingIntegracoes: boolean;
        errors: Record<string, string>;
        companyName: string;
        domain: string;
        supportEmail: string;
        language: string;
        timezone: string;
        currency: string;
        theme: string;
        emailNotif: boolean;
        smsNotif: boolean;
        pushNotif: boolean;
        require2fa: boolean;
        autoApproveLimit: number;
        defaultingAlert: number;
        sessionTimeout: number;
        loginAttempts: number;
        erp: string;
        termsAccepted: boolean;
        dataRetention: boolean;
        private snapshotGeral;
        private snapshotNotif;
        private snapshotLimites;
        private snapshotIntegracoes;
        private editGeral;
        private cancelGeral;
        private saveGeral;
        private editNotif;
        private cancelNotif;
        private saveNotif;
        private editLimites;
        private cancelLimites;
        private saveLimites;
        private editIntegracoes;
        private cancelIntegracoes;
        private saveIntegracoes;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get currencyLabel();
        private get themeLabel();
        private get erpLabel();
        private formatMoney;
        private err;
        private badge;
        private editHeader;
        private renderGeralView;
        private renderNotifView;
        private renderLimitesView;
        private renderIntegracoesView;
        private renderGeralEditForm;
        private renderNotifEditForm;
        private renderLimitesEditForm;
        private renderIntegracoesEditForm;
        private renderActiveEditForm;
        private renderTabs;
        render(): any;
    }
}
declare module "_102053_/l2/testes/training-catalog" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-media';
    import '/_102040_/l2/molecules/groupviewdata/ml-card-grid';
    import '/_102040_/l2/molecules/groupplaymedia/ml-video-player';
    import '/_102040_/l2/molecules/groupplaymedia/ml-audio-player';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type FormatFilter = 'video' | 'audio' | 'reading';
    export class TrainingCatalog extends StateLitElement {
        lessonProgress: number;
        courseComplete: boolean;
        userRating: number;
        npsScore: number | null;
        formatFilter: FormatFilter;
        areaFilter: string;
        searchQuery: string;
        enrollmentStart: string;
        enrollmentEnd: string;
        toastVisible: boolean;
        toastMessage: string;
        private readonly course;
        private readonly recommendedCourses;
        private get filteredCourses();
        private showToast;
        private simulateProgress;
        private formatLabel;
        render(): any;
    }
}
declare module "_102053_/l2/testes/vehicle-registration" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class VehicleRegistration extends StateLitElement {
        codigo: string;
        dataInclusao: string;
        dataModificacao: string;
        placa: string;
        situacao: string;
        marca: string;
        modelo: string;
        anoFabricacao: number | null;
        anoModelo: number | null;
        quilometragem: number | null;
        errors: Record<string, string>;
        saved: boolean;
        private readonly currentYear;
        private readonly brands;
        private readonly modelsByBrand;
        private err;
        private getModelos;
        private validate;
        private handleSave;
        private handleCancel;
        render(): any;
        private renderControle;
        private renderIdentificacao;
        private renderDadosVeiculo;
        private renderEstadoAtual;
        private renderSectionHeader;
    }
}
